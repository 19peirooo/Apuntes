package com.utad.poo.proyectoFinal;

public enum Tipos {
	AGUA,FUEGO,PLANTA,AIRE,ROCA,ACERO,ELECTRICO,LUCHA,NORMAL,ETEREO;
}
