package com.utad.poo.proyectoFinal;

public enum Estados {
	NORMAL,QUEMADO,CONFUNDIDO,MUERTO;
}
