package spaceinvaders;

import java.io.*;
import java.util.*;

import Personajes.*;

public class InventoryLoader {

    private File archivo;

    public InventoryLoader() {
        try {
            File currentDir = new File(System.getProperty("user.dir"));
            this.archivo = new File(currentDir.getCanonicalPath() + "\\logs\\inventarios.txt");
            // Crear archivo si no existe
            if (!archivo.exists()) {
                archivo.getParentFile().mkdirs(); // Crea el directorio logs si no existe
                archivo.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Boolean comprobarNombreValido(String nombre) {
        String linea;
        try (BufferedReader reader = new BufferedReader(new FileReader(archivo))) {
            while ((linea = reader.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;
                String[] campos = linea.split(",");
                if (campos[0].equals(nombre)) {
                    return false;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    public void guardarInventario(List<NaveDecorator> items, String nombre) {
        Boolean nombreValido = this.comprobarNombreValido(nombre);
        
        
        if (nombreValido) {
        	String texto = nombre;

            for (NaveDecorator item : items) {
                texto += ",";
                if (item instanceof DmgBoosterDecorator) {
                    texto += "0";
                } else if (item instanceof DoubleStepDecorator) {
                    texto += "1";
                } else if (item instanceof HpBoosterDecorator) {
                    texto += "2";
                } else if (item instanceof ShieldDecorator) {
                	texto += "3";
                }
            }
            texto += "\n";

            try (FileWriter writer = new FileWriter(archivo, true)) {
                writer.write(texto.toString());
                writer.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
    }

    public List<NaveDecorator> cargarInventario(String nombre) {
        String linea;
        try (BufferedReader reader = new BufferedReader(new FileReader(this.archivo))) {
            while ((linea = reader.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;

                String[] campos = linea.split(",");
                if (campos.length > 0 && campos[0].trim().equals(nombre)) {
                    List<NaveDecorator> items = new ArrayList<>();
                    Nave naveBase = Nave.getInstance();

                    for (int i = 1; i < campos.length; i++) {
                        try {
                            int num = Integer.parseInt(campos[i].trim());
                            switch (num) {
                                case 0 -> items.add(new DmgBoosterDecorator(naveBase.getPropiedadesNave()));
                                case 1 -> items.add(new DoubleStepDecorator(naveBase.getPropiedadesNave()));
                                case 2 -> items.add(new HpBoosterDecorator(naveBase.getPropiedadesNave()));
                                case 3 -> items.add(new ShieldDecorator(naveBase.getPropiedadesNave()));
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Número inválido: " + campos[i]);
                        }
                    }
                    return items;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Inventario no encontrado");
        return new ArrayList<>();
    }
    
}
