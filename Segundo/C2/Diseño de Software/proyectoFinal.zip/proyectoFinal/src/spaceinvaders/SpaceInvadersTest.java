package spaceinvaders;

public class SpaceInvadersTest {
	
	public static void main(String[] args) {
		Partida partida = Partida.getInstance();
		partida.jugar();
	}
	
}
