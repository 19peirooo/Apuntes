package spaceinvaders;

import Personajes.*;
import spaceinvaders.Coordenada;

public class MainDecorators {
    public static void main(String[] args) {
        Nave nave = Nave.getInstance();

        // Reiniciar nave limpia
        nave.setPropiedadesNave(new NavePredeterminada(new Coordenada(0, 0)));
        System.out.println("Estado inicial de la nave:");
        printStats(nave);

        // Aplicar decorador de daño
        nave.setPropiedadesNave(new DmgBoosterDecorator(nave.getPropiedadesNave()));
        System.out.println("Después de aplicar DmgBoosterDecorator:");
        printStats(nave);

        // Aplicar decorador de vida
        nave.setPropiedadesNave(new HpBoosterDecorator(nave.getPropiedadesNave()));
        System.out.println("Después de aplicar HpBoosterDecorator:");
        printStats(nave);

        // Aplicar decorador de doble paso
        nave.setPropiedadesNave(new DoubleStepDecorator(nave.getPropiedadesNave()));
        System.out.println("Después de aplicar DoubleStepDecorator:");
        printStats(nave);

        // Aplicar decorador de escudo
        nave.setPropiedadesNave(new ShieldDecorator(nave.getPropiedadesNave()));
        System.out.println("Después de aplicar ShieldDecorator:");
        printStats(nave);

        // Simular primer golpe (debería bloquear el escudo)
        System.out.println("\n--- Primer golpe (debería bloquearlo el escudo) ---");
        nave.setHp(nave.getHP() - 50);
        System.out.println("HP después del golpe: " + nave.getHP());

        // Simular segundo golpe (ya sin escudo)
        System.out.println("\n--- Segundo golpe (ya sin escudo) ---");
        nave.setHp(nave.getHP() - 50);
        System.out.println("HP después del segundo golpe: " + nave.getHP());

        // Comprobar si el escudo sigue activo
        NaveDecorator shieldCheck = DecoratorUtils.findDecorator(nave.getPropiedadesNave(), ShieldDecorator.class);
        if (shieldCheck != null) {
            System.out.println("\nEl escudo sigue activo.");
        } else {
            System.out.println("\nEl escudo ha sido eliminado.");
        }
    }

    private static void printStats(Nave nave) {
        System.out.println("HP: " + nave.getHP());
        System.out.println("DMG: " + nave.getDmg());
        System.out.println("Posición: (" + nave.getCoordinate().getFila() + ", " + nave.getCoordinate().getColumna() + ")");
        System.out.println();
    }
}