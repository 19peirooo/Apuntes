package spaceinvaders;

import Personajes.NaveDecorator;

public interface TiendaInterface {
	public void comprarObjeto(NaveDecorator itemAComprar);
	public void mostrarTienda();
	public void mostrarDescripcionItem(NaveDecorator itemADescribir);
}
