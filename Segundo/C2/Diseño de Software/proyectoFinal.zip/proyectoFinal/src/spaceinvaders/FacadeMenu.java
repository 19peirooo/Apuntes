package spaceinvaders;

import java.util.Scanner;

import Personajes.NaveDecorator;
import enemy.W1AbstractFactory;
import enemy.W2AbstractFactory;
import enemy.World;

public class FacadeMenu implements InterfaceMenuFacade{
	
	private final Estadistica estadistica;
	private final Tienda tienda = Tienda.getInstance();
	private final Partida partida = Partida.getInstance();
	
	public FacadeMenu() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Nombre del Jugador: ");
		String nombre = scanner.nextLine();
		this.estadistica = new Estadistica(nombre);
	}

	@Override
	public void mostrarEstadisticas() {
		// mostrar estadisticas de jugador
		this.estadistica.setPuntos(this.partida.getPuntos());
		this.estadistica.mostrarEstadisticas();
	}

	@Override
	public void mostrarTienda() {
	    Scanner scanner = new Scanner(System.in);
	    boolean salir = false;

	    System.out.println("╔════════════════════════════════════════╗");
	    System.out.println("║       ¡Bienvenido a la Tienda!         ║");
	    System.out.println("╠════════════════════════════════════════╣");
	    System.out.println("║ Aquí puedes adquirir mejoras y objetos ║");
	    System.out.println("╚════════════════════════════════════════╝");

	    do {
	        System.out.println("\n╔════════════════════════════════════════╗");
	        System.out.println("║           Menú de la Tienda            ║");
	        System.out.println("╠════════════════════════════════════════╣");
	        System.out.println("║ 1. 🛒 Ver objetos disponibles          ║");
	        System.out.println("║ 2. 💰 Comprar objeto                   ║");
	        System.out.println("║ 3. 🚪 Salir de la tienda               ║");
	        System.out.println("╚════════════════════════════════════════╝");
	        System.out.print("Seleccione una opción: ");

	        Integer opcion = scanner.nextInt();
	        scanner.nextLine(); // Limpiar buffer

	        switch (opcion) {
	            case 1:
	                System.out.println("🔍 Mostrando objetos disponibles en la tienda...");
	                this.tienda.mostrarTienda();
	                break;
	            case 2:
	            	System.out.println("╔══════════════════════════════════════════════╗");
	            	System.out.println("║ ✨ Selecciona el número del objeto a comprar ║");
	            	System.out.println("╚══════════════════════════════════════════════╝");
	            	opcion = scanner.nextInt();
	            	scanner.nextLine();
	                this.tienda.comprarObjeto(this.tienda.getListaDeObjetos().get(opcion - 1));
	                System.out.println("💳 Procesando compra de objeto...");
	                break;
	            case 3:
	                System.out.println("👋 Saliendo de la tienda. ¡Vuelve pronto!");
	                salir = true;
	                break;
	            default:
	                System.out.println("❌ Opción no válida. Intente de nuevo.");
	                break;
	        }

	    } while (!salir);

	}
	
	@Override
	public void jugarPartida() {
		this.estadistica.setPartidasJugadas(this.estadistica.getPartidasJugadas() + 1);
	    Boolean partidaAcabada = false;
	    Integer enemigosExtra = (int) (8 * this.partida.getMundo().getMultiplier());

	    // Inicia en el Mundo 1
	    this.partida.reinciarPartida();
	    this.partida.setMundo(World.World1);
	    this.partida.setEnemyFactory(new W1AbstractFactory());

	    System.out.println("🕹️ Comienza la partida en el Mundo 1... ¡Buena suerte!");
	    System.out.println("=========================================");

	    while (!partidaAcabada) {
	        Integer enemigosRestantes = (int)(5 * this.partida.getMundo().getMultiplier()) - this.partida.getEnemigos().size();

	        if (enemigosExtra >= enemigosRestantes) {
	            enemigosExtra -= enemigosRestantes;
	        } else {
	            enemigosRestantes = enemigosExtra;
	            enemigosExtra = 0;
	        }

	        if (enemigosRestantes > 0) {
	            System.out.println("⚠️  Se han generado " + enemigosRestantes + " nuevos enemigos.");
	        }

	        this.partida.generarEnemigos(enemigosRestantes);
	        this.partida.getMapa().imprimirMapa();
	        this.partida.decisionNave();	      
	        
	        this.partida.turnoEnemigos();
	        
	        if (this.partida.getNave().estaMuerto()) {
	            System.out.println("\n💀 Has muerto. Fin de la partida.");
	            this.partida.notifyObservers(this.partida.getNave());
	            partidaAcabada = true;
	            this.partida.terminarPartida();
	            continue;
	        }
	        
	        if (this.partida.getEnemigos().isEmpty() && enemigosExtra.equals(0)) {
	            if (this.partida.getMundo().equals(World.World1)) {
	                System.out.println("\n🌍 ¡Has superado el Mundo 1!");
	                this.partida.setMundo(World.World2);
	                this.partida.setEnemyFactory(new W2AbstractFactory());
	                enemigosExtra = (int) (8 * this.partida.getMundo().getMultiplier()); // reset enemigos extra
	                System.out.println("🔄 Cambiando al Mundo 2...");
	            } else {
	                System.out.println("\n🎉 ¡Has ganado! Enhorabuena!!");
	                partidaAcabada = true;
	                this.partida.terminarPartida();
	            }
	        }
	    }
	}


	@Override
	public void imprimirMenu() {
	    System.out.println("\n===============================================");
	    System.out.println("        👾 WELCOME TO SPACE INVADERS 👾        ");
	    System.out.println("===============================================\n");
	    System.out.println("              ╔═══════════════════╗");
	    System.out.println("              ║     MAIN MENU     ║");
	    System.out.println("              ╚═══════════════════╝\n");
	    System.out.println("             [1] 🚀 Jugar Partida");
	    System.out.println("             [2] 📊 Ver Estadísticas");
	    System.out.println("             [3] 🛒 Entrar a la Tienda");
	    System.out.println("             [0] ❌ Salir\n");
	    System.out.print("     Por favor, selecciona una opción: ");
	}
	
	public void finalizarJuego() {
		System.out.println("Deseas guardar las estadisticas? ");
		System.out.println("1. Si");
		System.out.println("2. No");
		Integer opcion = Utils.pedirNumero(1, 2);
		switch (opcion) {
			case 1: {
				this.estadistica.escribirFichero();
			}break;
			case 2: {
				
			}break;
		}
	}
	
}
