package spaceinvaders;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import Personajes.NaveDecorator;
import enemy.World;

public class Estadistica {
	private String nombreJugador;
	private Integer puntos;
	private World mundoAlcanzado;
	private Integer partidasJugadas;


	public Estadistica(String nombreJugador) {
		this.nombreJugador = nombreJugador;
		this.puntos = 0;
		this.mundoAlcanzado = World.World1;
		this.partidasJugadas = 0;
	}
	
	public String getNombreJugador() {
		return this.nombreJugador;
	}
	public void setNombreJugador(String nombreJugador) {
		this.nombreJugador = nombreJugador;
	}
	public Integer getPuntos() {
		return this.puntos;
	}
	public void setPuntos(Integer puntos) {
		this.puntos = puntos;
	}
	public Integer getPartidasJugadas() {
		return this.partidasJugadas;
	}
	public void setPartidasJugadas(Integer partidasJugadas) {
		this.partidasJugadas = partidasJugadas;
	}
	
	public World getMundoAlcanzado() {
		return this.mundoAlcanzado;
	}

	public void setMundoAlcanzado(World mundoAlcanzado) {
		this.mundoAlcanzado = mundoAlcanzado;
	}
	
	public void escribirFichero() {
	    File currentDir = null;
	    File estadisticasJugador = null;
	    FileWriter fileWriter = null;
	    BufferedWriter bufferedWriter = null;
	    try {
	        currentDir = new File(System.getProperty("user.dir"));
	        estadisticasJugador = new File(currentDir.getCanonicalPath() + "\\files\\" + this.nombreJugador + ".txt");
	        fileWriter = new FileWriter(estadisticasJugador);
	        bufferedWriter = new BufferedWriter(fileWriter);

	        bufferedWriter.write("Estadísticas del jugador:");
	        bufferedWriter.newLine();
	        bufferedWriter.write(this.nombreJugador);
	        bufferedWriter.newLine();
	        bufferedWriter.write("Puntos del jugador:");
	        bufferedWriter.newLine();
	        bufferedWriter.write(String.valueOf(this.puntos)); // Conversión a String
	        bufferedWriter.newLine();
	        bufferedWriter.write("Curación total realizada: ");
	        bufferedWriter.newLine();
	        bufferedWriter.write(String.valueOf(this.mundoAlcanzado));
	        bufferedWriter.newLine();
	        bufferedWriter.write("Partidas jugadas:");
	        bufferedWriter.newLine();
	        bufferedWriter.write(String.valueOf(this.partidasJugadas));
	        bufferedWriter.newLine();


	        bufferedWriter.flush(); // Asegúrate de vaciar el buffer
	        bufferedWriter.close(); // Cierra el BufferedWriter

	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

		

	public void leerFichero() {
		File currentDir = null;
		File estadisticasJugador = null;
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		String lineaDeFichero = null;
		Integer contador = 0;
		try {
			currentDir =  new File(System.getProperty ("user.dir") );
			estadisticasJugador = new File(currentDir.getCanonicalPath()+"\\files\\" + this.nombreJugador + ".txt");
			fileReader = new FileReader(estadisticasJugador);
			bufferedReader = new BufferedReader(fileReader);
			while((lineaDeFichero = bufferedReader.readLine()) != null) {
				switch(contador) {
				case 1:
					this.nombreJugador = lineaDeFichero;
					break;
				case 3:
					this.puntos = Integer.valueOf(lineaDeFichero);
					break;	
				case 5:
					this.mundoAlcanzado = World.valueOf(lineaDeFichero);
					break;
				case 7:
					this.partidasJugadas = Integer.valueOf(lineaDeFichero);
					break;
				default:
					break;
				}
				contador ++;
			}

		}catch(IOException e){
			e.printStackTrace();
		}
	}


	@Override
	public String toString() {
	    StringBuilder stringBuilder = new StringBuilder();
	    stringBuilder.append("╔═══════════════════════════════════════╗\n");
	    stringBuilder.append("║       Estadísticas del Jugador        ║\n");
	    stringBuilder.append("╚═══════════════════════════════════════╝\n");
	    stringBuilder.append("Nombre:            ").append(nombreJugador).append("\n");
	    stringBuilder.append("Puntos:            ").append(puntos).append("\n");
	    stringBuilder.append("Mundo Alcanzado:   ").append(mundoAlcanzado).append("\n");
	    stringBuilder.append("Partidas Jugadas:  ").append(partidasJugadas).append("\n");
	    stringBuilder.append("═════════════════════════════════════════\n");
	    return stringBuilder.toString();
	}
	
	public void mostrarEstadisticas() {
		System.out.println(this.toString());
	}

}
