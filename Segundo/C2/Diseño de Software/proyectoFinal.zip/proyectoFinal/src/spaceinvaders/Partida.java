package spaceinvaders;

import java.util.ArrayList;
import java.util.List;

import Personajes.*;
import enemy.*;

public class Partida implements PullPushObservable {
	
	private static Partida partida = new Partida();
	
	private Nave nave;
	private List<Barrera> barreras;
	private List<Enemy> enemigos;
	private EnemyAbstractFactory enemyFactory;
	private List<PullPushObserver> listaObservadores;
	private Mapa mapa;
	private World mundo;
	private Integer puntos;
	
	public static Partida getInstance() {
		return partida;
	}
	
	private Partida() {
		this.nave = Nave.getInstance();
		this.mapa = Mapa.getInstance();
		this.barreras = new ArrayList<Barrera>();
		this.enemigos = new ArrayList<Enemy>();
		this.mundo = World.World1;
		this.enemyFactory = new W1AbstractFactory();
		this.puntos = 0;
		this.listaObservadores = new ArrayList<PullPushObserver>();
		Logs logs = new Logs();
		this.attach(logs);
		this.nuevoMapa();
	}
	
	private void nuevoMapa() {
		this.colocarNave();
		this.colocarBarreras(4);
	}
	
	public void reinciarPartida() {
		this.nave.setCoordinate(new Coordenada(Mapa.DEFAULT_ROW-1,Mapa.DEFAULT_COL/2));
		this.nuevoMapa();
	}
	
	private void colocarNave() {
		this.mapa.add(this.nave.getIcon(), this.nave.getCoordinate());
	}
	
	private void colocarBarreras(Integer numBarreras) {
	    for (int i = 1; i <= numBarreras; i++) {
	        Double fraccion = (double) i / (numBarreras + 1);
	        Integer columna = (int) (fraccion * Mapa.DEFAULT_COL); 

	        Barrera barrera = new Barrera(new Coordenada(17, columna));
	        this.addBarrier(barrera);
	    }
	}
	
	public List<PullPushObserver> getListaObservadores() {
		return this.listaObservadores;
	}

	public void setListaObservadores(List<PullPushObserver> listaObservadores) {
		this.listaObservadores = listaObservadores;
		this.notifyObservers(this.puntos);
	}

	public Nave getNave() {
		return this.nave;
	}

	public List<Barrera> getBarreras() {
		return this.barreras;
	}

	public void setBarreras(List<Barrera> barreras) {
		this.barreras = barreras;
	}

	public List<Enemy> getEnemigos() {
		return this.enemigos;
	}

	public void setEnemigos(List<Enemy> enemigos) {
		this.enemigos = enemigos;
	}

	public Mapa getMapa() {
		return this.mapa;
	}
	
	public World getMundo() {
		return this.mundo;
	}

	public void setMundo(World mundo) {
		this.mundo = mundo;
		this.notifyObservers(this.mundo);
	}

	public Integer getPuntos() {
		return this.puntos;
	}

	public void setPuntos(Integer puntos) {
		this.puntos = puntos;
		this.notifyObservers(this.puntos);
	}
	
	public EnemyAbstractFactory getEnemyFactory() {
		return this.enemyFactory;
	}

	public void setEnemyFactory(EnemyAbstractFactory enemyFactory) {
		this.enemyFactory = enemyFactory;
	}
	
	
	
	public Barrera getBarreraEnPosicion(Coordenada coordenada) {
	    for (Barrera barrera : this.barreras) {
	        if (barrera.getPosicion().equals(coordenada)) {
	            return barrera;
	        }
	    }
	    return null;
	}
	
	public void notifyObservers(Object object) {
		for (Enemy enemy : this.enemigos) {
			if (enemy.getHP().equals(0.0)) {
				for(PullPushObserver observador : this.listaObservadores) {
					observador.update(this, enemy);
				}
			}
		}
		
		if (object instanceof Nave) {
			if (this.nave.getHP().equals(0.0)) {
				this.update(getInstance(), object);
			}
		}
		
		if (object instanceof Integer) {
			this.update(getInstance(),(Integer) object);

		}
		
		if (object instanceof World) {
			this.update(getInstance(),(World) object);
		}
		
	}
	
	public void addEnemy(Enemy enemy) {
		this.enemigos.add(enemy);
		this.mapa.add(enemy.getIcon(), enemy.getCoordinate());
	}
	
	public void removeEnemy(Enemy enemy) {
		this.enemigos.remove(enemy);
		this.mapa.remove(enemy.getCoordinate());
	}
	
	public void addBarrier(Barrera barrera) {
		this.barreras.add(barrera);
		this.mapa.add(barrera.getIcon(), barrera.getPosicion());
	}
	
	public void removeBarrier(Barrera barrera) {
		this.barreras.remove(barrera);
		this.mapa.remove(barrera.getPosicion());
	}
	
	public void terminarPartida() {
		//vaciar mapa
		this.mapa.vaciarMapa();
		//vaciar listas
		this.barreras = new ArrayList<Barrera>();
		this.enemigos = new ArrayList<Enemy>();
		this.nave.setHp(NavePredeterminada.DEFAULT_HP);
		if (this.nave.getPropiedadesNave() instanceof HpBoosterDecorator) {
			this.nave.getPropiedadesNave().modificarEstadisticas();
		}
		
	}
	
	public void turnoEnemigos() {
		if (Utils.generarNumeroAleatorioEnRango(0, 4).equals(0)) { //Los enemigos tiene un 25% de atacar
			System.out.println("Los enemigos atacan");
        	for (Enemy enemy : this.enemigos) {
        		if (enemy instanceof AlienShooter) {
        			((AlienShooter)enemy).amplifyDmg();
        		} else if (enemy instanceof Ufo) {
        			((Ufo)enemy).regen();
        		} else {
        			if (((DeathStar)enemy).getShield().equals(0.0)) {
        				((DeathStar)enemy).regenShield();
        			}
        		}
        		enemy.ataca();
        		enemy.desplazarse();
        	}
        }
	}
	
	public void generarEnemigos(Integer numEnemigos) {
		Enemy enemy;
		for (int i = 0; i < numEnemigos; i++) {
			int numAleatorio = Utils.generarNumeroAleatorioEnRango(0, 10);
			if (numAleatorio <= 4) {
				enemy = this.enemyFactory.createAlienShooter();
				
			} else if (numAleatorio > 4 && numAleatorio <= 7) {
				enemy = this.enemyFactory.createUFO();
			} else {
				enemy = this.enemyFactory.createDeathStar();
			}
			this.addEnemy(enemy);
		}
	}
	
	public void decisionNave() {
		System.out.println("===================================");
		System.out.println("        🚀 TURNO DE LA NAVE        ");
		System.out.println("===================================");
		System.out.println("Vida: " + this.nave.getHP());
		System.out.println("DMG: " + this.nave.getDmg());
		System.out.println("Nave: " + this.nave.getCurrentState());
		System.out.println("Seleccione una acción:");
		System.out.println("  1️.  Atacar");
		System.out.println("  2️.  Moverse");
		System.out.println("===================================");
		System.out.println("Por favor, selecciona una opción: ");
		Integer opcion = Utils.pedirNumero(1, 2);
		
		switch (opcion) {
			case 1 : 
				this.nave.getCurrentState().ataca();
				break;
			case 2 :
				this.nave.getCurrentState().desplaza();
				break;
			default :
				break;
		}
		
	}
	
	public void jugar() {
		FacadeMenu menu = new FacadeMenu();

		Integer opcion = 0;
		
		while (opcion >= 0 && opcion <= 4) {
			menu.imprimirMenu();
			opcion = Utils.pedirNumero(0, 3);
			
			switch (opcion) {
				
				case 1:{
					menu.jugarPartida();
				}break;
				case 2:{
					menu.mostrarEstadisticas();
				}break;
				case 3:{
					menu.mostrarTienda();
				}break;
				default:{ //Caso 0. Siempre va a ser 0 porque pedir numero comprueba que este en el rango
					System.out.println("Fin de Juego.");
					menu.finalizarJuego();
					return;
				}
			}
			
		}
		
	}
	
	public void update(PullPushObservable observable, Object object) {
		for(PullPushObserver observador : this.listaObservadores) {
			observador.update(observable, object);
		}
	}
	
	public void addPuntos(Integer puntosAnyadir) {
		this.setPuntos(this.getPuntos() + puntosAnyadir);
	}

	@Override
	public void attach(PullPushObserver observador) {
		// TODO Auto-generated method stub
		this.listaObservadores.add(observador);
	}

	@Override
	public void detach(PullPushObserver observador) {
		// TODO Auto-generated method stub
		this.listaObservadores.remove(observador);
	}
}
