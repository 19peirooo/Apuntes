package spaceinvaders;

import java.util.InputMismatchException;
import java.util.Scanner;

//Funciones de Utilidad
public class Utils {
	public static Integer generarNumeroAleatorioEnRango(Integer min, Integer max) {
		return (int)(Math.random()*(max-min)) + min ;
	}
	
	public static Integer pedirNumero(int numMin, int numMax) {
		Integer numero = 0;
		Boolean entradaValida = false;
		Scanner entrada = new Scanner(System.in);
		
		while (!entradaValida) {
			try {
				numero = entrada.nextInt();
				if (numero >= numMin && numero <= numMax) {
					entradaValida = true;
				} else {
					System.out.println("ERROR: Numero ha de estar entre " + numMin + " y " + numMax);
				}
			} catch (InputMismatchException e){
				entradaValida = false;
				System.out.println("Entrada no es numerica");
				entrada.nextLine(); //Limpia en buffer de entrada
			}
		}
		return numero;
	}
	
}
