package spaceinvaders;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import Personajes.Nave;
import enemy.Enemy;
import enemy.World;

public class Logs implements PullPushObserver {
	
	public static final String DEFAULT_FILE_ROUTE = "logsSpaceInvaders.txt";
	
	private String rutaArchivoLogs;
	
	public Logs() {
		this(Logs.DEFAULT_FILE_ROUTE);
	}
	
	public Logs(String rutaArchivo) {
		this.rutaArchivoLogs = rutaArchivo;
	}
	
	public void escribirEnArchivo(String textoAEscribir) {
		try {
			File currentDir = new File(System.getProperty ("user.dir") );
			
			File logsDir = new File(currentDir.getCanonicalPath() + File.separator + "logs");

	        // Asegura que el directorio 'logs' existe
	        if (!logsDir.exists()) {
	            logsDir.mkdirs();
	        }
			
			File fileToWrite = new File(currentDir.getCanonicalPath()+"\\logs\\" + this.rutaArchivoLogs);
			FileWriter fileWriter = new FileWriter(fileToWrite, true); //Para no sobreescribir el fichero, utilizo el segundo parametro
			fileWriter.write(textoAEscribir);
			fileWriter.close();
		} catch (IOException e){
			e.printStackTrace();
		}
	}
	
	@Override
	public void update(PullPushObservable observable, Object object) {
		String texto = "";
		if (object instanceof Enemy) {
			Enemy personaje = (Enemy)object;
			texto =  "[Push Protocol] Enemigo: "+ personaje.toString() + " ha muerto \n";
		}
		
		if (object instanceof Nave) {
			texto = "[Push Protocol] Ha muerto la nave: " + ((Nave)object).toString();
		}
		
		if (object instanceof Integer) {
			texto = "[Push Protocol] Han cambiado los puntos. Nuevos puntos: " + (Integer)object;
		}
		
		if (object instanceof World) {
			texto = "[Push Protocol] Se ha cambiado el mundo. Mundo: " + (World)object;
		}
		
		System.out.println(texto);
		this.escribirEnArchivo(texto);
	}
	
}
