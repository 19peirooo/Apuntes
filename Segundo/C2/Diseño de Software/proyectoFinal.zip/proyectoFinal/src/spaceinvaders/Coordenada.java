package spaceinvaders;

public class Coordenada {
	
	public static final Integer DEFAULT_NUM = 0;
	
	private Integer fila;
	private Integer columna;
	
	public Coordenada() {
		this(Coordenada.DEFAULT_NUM, Coordenada.DEFAULT_NUM);
	}
	
	public Coordenada(Integer fila, Integer columna) {
		this.fila = fila;
		this.columna = columna;
	}

	public Integer getFila() {
		return this.fila;
	}

	public void setFila(Integer fila) {
		this.fila = fila;
	}

	public Integer getColumna() {
		return this.columna;
	}

	public void setColumna(Integer columna) {
		this.columna = columna;
	}
	
	@Override
	public boolean equals (Object object) {
		boolean iguales = false;
		
		if (object instanceof Coordenada) {
			Coordenada otraCoordenada = (Coordenada)object;
			iguales = this.fila.equals(otraCoordenada.fila) && this.columna.equals(otraCoordenada.columna);
		}
		return iguales;
	}
	
	@Override
	public String toString() {
		return "(" + this.fila + "," + this.columna + ")";
	}
	
	
	
}
