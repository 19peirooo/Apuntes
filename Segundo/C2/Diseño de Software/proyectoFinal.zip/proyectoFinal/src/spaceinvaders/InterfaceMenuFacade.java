package spaceinvaders;

public interface InterfaceMenuFacade {
	public void mostrarEstadisticas();
	public void mostrarTienda();
	public void jugarPartida();
	public void imprimirMenu();
}
