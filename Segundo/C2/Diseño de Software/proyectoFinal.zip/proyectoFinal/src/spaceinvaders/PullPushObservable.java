package spaceinvaders;

public interface PullPushObservable {
	public void notifyObservers(Object object);
	public void attach(PullPushObserver observador);
	public void detach(PullPushObserver observador);
	
}
