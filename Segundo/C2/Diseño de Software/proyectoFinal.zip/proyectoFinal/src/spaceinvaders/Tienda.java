package spaceinvaders;

import java.util.List;

import Personajes.*;;

public class Tienda implements TiendaInterface{
	private List<NaveDecorator> listaDeObjetos;
	private static Tienda tienda = new Tienda();
	
	private Tienda() {
		InventoryLoader loader = new InventoryLoader();
		this.listaDeObjetos = loader.cargarInventario("TiendaDefault");
	}
	
	public static Tienda getInstance() {
		return tienda;
	}
	
	
	public List<NaveDecorator> getListaDeObjetos(){
		return this.listaDeObjetos;
	}
	
	@Override
	public void comprarObjeto(NaveDecorator itemAComprar) {
		Nave nave = Nave.getInstance();
		if(Partida.getInstance().getPuntos() >= itemAComprar.getPrecio()) {
			this.listaDeObjetos.remove(itemAComprar);
			if (itemAComprar instanceof DmgBoosterDecorator) {
				nave.setPropiedadesNave(new DmgBoosterDecorator(nave.getPropiedadesNave())); 	
			} else if (itemAComprar instanceof HpBoosterDecorator) {
				nave.setPropiedadesNave(new HpBoosterDecorator(nave.getPropiedadesNave()));
				nave.getPropiedadesNave().modificarEstadisticas();
			} else if (itemAComprar instanceof DoubleStepDecorator) {
				nave.setPropiedadesNave(new DoubleStepDecorator(nave.getPropiedadesNave()));
			} else if (itemAComprar instanceof ShieldDecorator) {
				nave.setPropiedadesNave(new ShieldDecorator(nave.getPropiedadesNave()));
			}
			Partida.getInstance().setPuntos(Partida.getInstance().getPuntos() - itemAComprar.getPrecio());
		}else {
			System.out.println("Lo siento, no tienes puntos suficientes");
		}
	}

	@Override
	public void mostrarTienda() {
		System.out.println(" ");
		System.out.println("╔══════════════════════════════════╗");
		System.out.println("║         TIENDA DE OBJETOS        ║");
		System.out.println("╚══════════════════════════════════╝\n");
		if (listaDeObjetos == null || listaDeObjetos.isEmpty()) {
		    System.out.println("La tienda está vacía.");
		    return;
		}

		int contador = 1;
		for (NaveDecorator item : this.listaDeObjetos) {
		    System.out.println("[" + contador + "] ===============================");
		    System.out.println(item.toString());
		    System.out.println("===================================\n");
		    contador++;
		}

	}

	@Override
	public void mostrarDescripcionItem(NaveDecorator itemADescribir) {
		// TODO Auto-generated method stub
		itemADescribir.getDecoratorDescription();
	}

}