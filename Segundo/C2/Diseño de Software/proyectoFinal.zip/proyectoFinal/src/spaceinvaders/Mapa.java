package spaceinvaders;

public class Mapa {
	
	public static final Integer DEFAULT_ROW = 20;
	public static final Integer DEFAULT_COL = 10;
	
	private static Mapa mapa = new Mapa();
	private String[][] terreno;
	
	private Mapa() {
		this.terreno = new String[Mapa.DEFAULT_ROW][Mapa.DEFAULT_COL];
		for (int i = 0; i < terreno.length; i++) {
			for (int j = 0; j < terreno[i].length; j++) {
				terreno[i][j] = " ";
			}
		}
	}
	
	public void vaciarMapa() {
		for (int i = 0; i < terreno.length; i++) {
			for (int j = 0; j < terreno[i].length; j++) {
				terreno[i][j] = " ";
			}
		}
	}
	
	public static Mapa getInstance() {
		return mapa;
	}
	
	public void imprimirMapa() {
	    for (int i = 0; i < terreno.length; i++) {
	    	System.out.print("\t");
	        for (int j = 0; j < terreno[i].length; j++) {
	            System.out.print(terreno[i][j] + " ");
	        }
	        System.out.println();
	    }
	}
	
	public void add(String icono,Coordenada coordenada) {
		this.terreno[coordenada.getFila()][coordenada.getColumna()] = icono;
	}
	
	public String remove(Coordenada coordenada) {
		String icono = this.terreno[coordenada.getFila()][coordenada.getColumna()];
		this.terreno[coordenada.getFila()][coordenada.getColumna()] = " ";
		return icono;
	}
	
	public String getElementoEnPosicion(Coordenada coordenada) {
		return this.terreno[coordenada.getFila()][coordenada.getColumna()];
	}
	
	public Boolean coordenadaEnMapa(Coordenada coordenada) {
		return (coordenada.getFila() >= 0 && coordenada.getFila() < Mapa.DEFAULT_ROW) && (coordenada.getColumna() >= 0 && coordenada.getColumna() < Mapa.DEFAULT_COL);
	}
	
	public Coordenada generarCoordenadaAleatoria(Integer filaMin, Integer filaMax, Integer columnaMin, Integer columnaMax) {
		Integer randomColumna = Utils.generarNumeroAleatorioEnRango(columnaMin, columnaMax);
		Integer randomFila = Utils.generarNumeroAleatorioEnRango(filaMin, filaMax);
		Coordenada coordenada = new Coordenada(randomFila,randomColumna);
		return coordenada;
	}
	
}
