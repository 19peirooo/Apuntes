package enemy;

//Enemigo Nivel 1 --> Multiplicador de daño
public abstract class AlienShooter extends Enemy{
	
	public static final Double DEFAULT_DMG = 10.0;
	public static final Double DEFAULT_HP = 50.0;
	public static final String DEFAULT_ICON = "👾";
	public static final Double DEFAULT_DMGAMP = 1.2;
	public static final Integer DEFAULT_POINTS = 100;
	
	protected Double dmgAmplicification;
	
	public AlienShooter(Double hp, Double dmg, String icon, Double dmgAmplification) {
		super(hp, dmg, icon);
		this.dmgAmplicification = dmgAmplification;
	}
	
	public Double getDmgAmplification() {
		return this.dmgAmplicification;
	}
	
	public abstract void amplifyDmg();
}
