package enemy;

public class W1AbstractFactory implements EnemyAbstractFactory{

	@Override
	public AlienShooter createAlienShooter() {
		return new W1AlienShooter();
	}

	@Override
	public Ufo createUFO() {
		return new W1Ufo();
	}

	@Override
	public DeathStar createDeathStar() {
		return new W1DeathStar();
	}

}
