package enemy;

//Enemigo nivel 2 --> Se puede regenerar
public abstract class Ufo extends Enemy{
	
	public static final Double DEFAULT_DMG = 30.0;
	public static final Double DEFAULT_HP = 100.0;
	public static final String DEFAULT_ICON = "🛸";
	public static final Double DEFAULT_HP_REGEN_FACTOR = 0.1; 
	public static final Integer DEFAULT_POINTS = 200;

	protected Double hpRegenFactor;
	
	public Ufo(Double hp, Double dmg, String icon, Double hpRegenFactor) {
		super(hp, dmg, icon);
		this.hpRegenFactor = hpRegenFactor;
	}
	
	public Double getHPRegenFactor() {
		return this.hpRegenFactor;
	}
	
	public abstract void regen();
}
