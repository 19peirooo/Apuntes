package enemy;

import spaceinvaders.Utils;

public class W2DeathStar extends DeathStar{
	
	public W2DeathStar() {
		super(
				DeathStar.DEFAULT_HP*World.World2.getMultiplier(),
				DeathStar.DEFAULT_DMG*World.World2.getMultiplier(),
				DeathStar.DEFAULT_ICON,
				DeathStar.DEFAULT_SHIELD*World.World2.getMultiplier()
			);
	}

	@Override
	public void regenShield() {
		
		if (Utils.generarNumeroAleatorioEnRango(0, 2).equals(0)) { //50% de probabilidad de ponerse es escudo
			this.shield = DeathStar.DEFAULT_SHIELD*World.World2.getMultiplier();
			System.out.println(this.toString() + " Escudo regenerado.");
		}
		
	}

	@Override
	public String toString() {
		return "W2DeathStar [shield=" + this.shield + ", hp=" + this.hp + ", dmg=" + this.dmg + ", icon=" + this.icon + ", posicion="
				+ this.posicion + "]";
	}
	
	
	
}
