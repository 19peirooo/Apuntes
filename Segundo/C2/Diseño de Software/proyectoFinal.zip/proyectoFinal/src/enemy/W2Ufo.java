package enemy;

import spaceinvaders.Utils;

public class W2Ufo extends Ufo{
	
	public static final Double MAX_HP = Ufo.DEFAULT_HP*World.World2.getMultiplier();
	
	public W2Ufo() {
		super(
				Ufo.DEFAULT_HP*World.World2.getMultiplier(),
				Ufo.DEFAULT_DMG*World.World2.getMultiplier(),
				Ufo.DEFAULT_ICON,
				Ufo.DEFAULT_HP_REGEN_FACTOR
			);
	}

	@Override
	public void regen() {
		Double vidaRegenerada = 0.0;
		if (Utils.generarNumeroAleatorioEnRango(0, 20) < 7) { //35% de probabilidad de regenerar vida
			vidaRegenerada = W2Ufo.MAX_HP * this.getHPRegenFactor();
			if (this.hp + vidaRegenerada >= W2Ufo.MAX_HP) {
				this.hp = W2Ufo.MAX_HP;
			} else {
				this.hp += vidaRegenerada;
			}
			System.out.println(this.toString() + " se ha regenerado.");
		}
	}

	@Override
	public String toString() {
		return "W2Ufo [hpRegenFactor=" + this.hpRegenFactor + ", hp=" + this.hp + ", dmg=" + this.dmg + ", icon=" + this.icon
				+ ", posicion=" + this.posicion + "]";
	}
	
	

	
}
