package enemy;

import Personajes.Barrera;
import Personajes.Character;
import Personajes.HpBoosterDecorator;
import Personajes.Nave;
import spaceinvaders.Coordenada;
import spaceinvaders.Mapa;
import spaceinvaders.Partida;
import spaceinvaders.Utils;

public class Enemy implements Character {
	
	protected Double hp;
	protected Double dmg;
	protected String icon;
	protected Coordenada posicion;
	
	public Enemy(Double hp, Double dmg, String icon) {
		this.hp = hp;
		this.dmg = dmg;
		this.icon = icon;
		this.posicion = this.colocarEnemigo();
	}
	
	private Coordenada colocarEnemigo() {
		Boolean coordenadaValida = false;
		Coordenada coordenada = null;
		while (!coordenadaValida) {
			coordenada = Mapa.getInstance().generarCoordenadaAleatoria(0, 3*Mapa.DEFAULT_ROW/4, 0, Mapa.DEFAULT_COL);
			if (Mapa.getInstance().getElementoEnPosicion(coordenada).equals(" ")) {
				coordenadaValida = true;
			}
		}
		return coordenada;
	}
	
	public Double getHP() {
		return this.hp;
	}

	public void setHp(Double hp) {
		this.hp = hp;
		if (this.hp <= 0.0) {
			this.hp = 0.0;
		}
	}

	public Double getDmg() {
		return this.dmg;
	}

	public void setDmg(Double dmg) {
		this.dmg = dmg;
	}

	public Coordenada getCoordinate() {
		return this.posicion;
	}

	public void setPosicion(Coordenada posicion) {
		this.posicion = posicion;
	}
	
	public String getIcon() {
		return this.icon;
	}
	
	public void setIcon(String icon) {
		this.icon = icon;
	}

	public void ataca() {
		//Recorre toda la columna
		for (int i = this.getCoordinate().getFila(); i <  Mapa.DEFAULT_ROW; i++) {
			//Comprueba si es una barrera
			Coordenada coordenadaAtaque = new Coordenada(i,this.getCoordinate().getColumna());
			if (Mapa.getInstance().getElementoEnPosicion(coordenadaAtaque).equals("🛡️")) {
				//Veo a que barrera le he dado
				Barrera barrera = Partida.getInstance().getBarreraEnPosicion(coordenadaAtaque);
				System.out.println("Se ha atacado a una barrera");
				//Le quito una vida
				barrera.setVidas(barrera.getVidas()-1);
				if (barrera.getVidas().equals(0)) {
					Partida.getInstance().removeBarrier(barrera);
				}
				//Finalizo el bucle
				break;
			} else if (Mapa.getInstance().getElementoEnPosicion(coordenadaAtaque).equals("🚀")) { //Comprueba si es la nave
				//Le quito la vida
				Nave.getInstance().setHp(Nave.getInstance().getHP() - this.getDmg());
			}
		}	
	}
	
	public void desplazarse() {
		Boolean desplazamientoValido = false;
		Integer[] dy = {-1,0,1,1,1,0,-1,-1}; //Desplazamiento en fila
		Integer[] dx = {1,1,1,0,-1,-1,-1,0}; //Desplazamiento en columna
		
		while (!desplazamientoValido) {
			Integer movimientoAleatorio = Utils.generarNumeroAleatorioEnRango(0, 8);
			
			Integer nuevaFila = this.getCoordinate().getFila() + dy[movimientoAleatorio];
			Integer nuevaColumna = this.getCoordinate().getColumna() + dx[movimientoAleatorio];
			Coordenada nuevaCoordenada = new Coordenada(nuevaFila,nuevaColumna);
			if (Mapa.getInstance().coordenadaEnMapa(nuevaCoordenada)) {
				if (Mapa.getInstance().getElementoEnPosicion(nuevaCoordenada).equals(" ")) {
					Mapa.getInstance().remove(this.posicion);
					Mapa.getInstance().add(this.icon, nuevaCoordenada);
					this.posicion = nuevaCoordenada;
					desplazamientoValido = true;
				} else if (Mapa.getInstance().getElementoEnPosicion(nuevaCoordenada).equals("N")) {
					Nave.getInstance().setHp(0.0);
					this.setHp(0.0);
					Partida.getInstance().removeEnemy(this);
					desplazamientoValido = true;
				} else if (Mapa.getInstance().getElementoEnPosicion(nuevaCoordenada).equals("B")) {
					Barrera barrera = Partida.getInstance().getBarreraEnPosicion(nuevaCoordenada);
					barrera.setVidas(0);
					Partida.getInstance().removeBarrier(barrera);
					Partida.getInstance().removeEnemy(this);
					desplazamientoValido = true;
				}
			}	
		}	
	}
	
	public boolean estaMuerto() {
	    return this.getHP() <= 0;
	}
}