package enemy;

public interface EnemyAbstractFactory {
	public AlienShooter createAlienShooter();
	public Ufo createUFO();
	public DeathStar createDeathStar();
}
