package enemy;

import spaceinvaders.Utils;

public class W2AlienShooter extends AlienShooter{
	
	public W2AlienShooter() {
		super(
				AlienShooter.DEFAULT_HP*World.World2.getMultiplier(),
				AlienShooter.DEFAULT_DMG*World.World2.getMultiplier(),
				AlienShooter.DEFAULT_ICON,
				AlienShooter.DEFAULT_DMGAMP*World.World2.getMultiplier()
			); 
	}

	@Override
	public void amplifyDmg() {
		if (Utils.generarNumeroAleatorioEnRango(0, 20) < 3) { //15% de probabilidad de ponerse es escudo
			this.dmg *= AlienShooter.DEFAULT_DMGAMP*World.World2.getMultiplier();	
			System.out.println(this.toString() + " Daño Amplificado.");
		}
	}

	@Override
	public String toString() {
		return "W2AlienShooter [dmgAmplicification=" + this.dmgAmplicification + ", hp=" + this.hp + ", dmg=" + this.dmg + ", icon="
				+ this.icon + ", posicion=" + this.posicion + "]";
	}
	
	
	
}
