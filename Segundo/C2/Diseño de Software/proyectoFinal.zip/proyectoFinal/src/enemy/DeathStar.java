package enemy;

//Enemigo Nivel 3 --> Tiene un escudo
public abstract class DeathStar extends Enemy {
	
	
	public static final Double DEFAULT_DMG = 40.0;
	public static final Double DEFAULT_HP = 200.0;
	public static final String DEFAULT_ICON = "☠️";
	public static final Double DEFAULT_SHIELD = 50.0;
	public static final Integer DEFAULT_POINTS = 300;

	
	protected Double shield;
	
	public DeathStar(Double hp, Double dmg, String icon, Double shield) {
		super(hp, dmg, icon);
		this.shield = shield;
	}
	
	public Double getShield() {
		return this.shield;
	}
	
	public void setShield(Double shield) {
		this.shield = shield;
		if (this.shield <= 0.0) {
			this.shield = 0.0;
		}
	}
	
	public abstract void regenShield();
}
