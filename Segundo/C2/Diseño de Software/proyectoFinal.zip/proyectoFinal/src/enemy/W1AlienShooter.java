package enemy;

import spaceinvaders.Utils;

public class W1AlienShooter extends AlienShooter{
	
	public W1AlienShooter() {
		super(
				AlienShooter.DEFAULT_HP*World.World1.getMultiplier(),
				AlienShooter.DEFAULT_DMG*World.World1.getMultiplier(),
				AlienShooter.DEFAULT_ICON,
				AlienShooter.DEFAULT_DMGAMP*World.World1.getMultiplier()
			); 
	}

	@Override
	public void amplifyDmg() {
		if (Utils.generarNumeroAleatorioEnRango(0, 10).equals(0)) { //10% de probabilidad de ponerse es escudo
			this.dmg *= AlienShooter.DEFAULT_DMGAMP*World.World1.getMultiplier();
			System.out.println(this.toString() + " Daño Amplificado.");
		}
	}

	@Override
	public String toString() {
		return "W1AlienShooter [dmgAmplicification=" + this.dmgAmplicification + ", hp=" + this.hp + ", dmg=" + this.dmg + ", icon="
				+ this.icon + ", posicion=" + this.posicion + "]";
	}
	
	
	
}
