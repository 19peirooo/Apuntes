package enemy;

import spaceinvaders.Utils;

public class W1Ufo extends Ufo{
	
	public static final Double MAX_HP = Ufo.DEFAULT_HP*World.World1.getMultiplier();
	
	public W1Ufo() {
		super(
				Ufo.DEFAULT_HP*World.World1.getMultiplier(),
				Ufo.DEFAULT_DMG*World.World1.getMultiplier(),
				Ufo.DEFAULT_ICON,
				Ufo.DEFAULT_HP_REGEN_FACTOR
			);
	}

	@Override
	public void regen() {
		Double vidaRegenerada = 0.0;
		
		if (Utils.generarNumeroAleatorioEnRango(0, 10) < 2) { //20% de probabilidad de regenerar vida
			vidaRegenerada = W1Ufo.MAX_HP * this.getHPRegenFactor();
			if (this.hp + vidaRegenerada >= W1Ufo.MAX_HP) {
				this.hp = W1Ufo.MAX_HP;
			} else {
				this.hp += vidaRegenerada;
			}
			System.out.println(this.toString() + " se ha regenerado.");
		}
		
	}

	@Override
	public String toString() {
		return "W1Ufo [hpRegenFactor=" + this.hpRegenFactor + ", hp=" + this.hp + ", dmg=" + this.dmg + ", icon=" + this.icon
				+ ", posicion=" + this.posicion + "]";
	}
	
	
	
}
