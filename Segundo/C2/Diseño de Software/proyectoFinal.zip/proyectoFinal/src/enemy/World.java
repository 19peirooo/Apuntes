package enemy;

public enum World {
	
	World1(1.0),World2(1.5);
	
	private Double multiplier;
	
	private World(Double multiplier) {
		this.multiplier = multiplier;
	}
	
	public Double getMultiplier() {
		return this.multiplier;
	}
	
}
