package enemy;

import spaceinvaders.Utils;

public class W1DeathStar extends DeathStar{
	
	public W1DeathStar() {
		super(
				DeathStar.DEFAULT_HP*World.World1.getMultiplier(),
				DeathStar.DEFAULT_DMG*World.World1.getMultiplier(),
				DeathStar.DEFAULT_ICON,
				DeathStar.DEFAULT_SHIELD*World.World1.getMultiplier()
			);
	}

	@Override
	public void regenShield() {
		if (Utils.generarNumeroAleatorioEnRango(0, 4).equals(0)) { //25% de probabilidad de ponerse es escudo
			this.shield = DeathStar.DEFAULT_SHIELD*World.World1.getMultiplier();
			System.out.println(this.toString() + " Escudo regenerado.");
		}
	}

	@Override
	public String toString() {
		return "W1DeathStar [shield=" + this.shield + ", hp=" + this.hp + ", dmg=" + this.dmg + ", icon=" + this.icon + ", posicion="
				+ this.posicion + "]";
	}
	
	
	
}
