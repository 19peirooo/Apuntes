package enemy;

public class W2AbstractFactory implements EnemyAbstractFactory{

	@Override
	public AlienShooter createAlienShooter() {
		return new W2AlienShooter();
	}

	@Override
	public Ufo createUFO() {
		return new W2Ufo();
	}

	@Override
	public DeathStar createDeathStar() {
		return new W2DeathStar();
	}

}
