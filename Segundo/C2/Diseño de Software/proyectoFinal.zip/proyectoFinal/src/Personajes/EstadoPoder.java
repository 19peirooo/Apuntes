package Personajes;

public class EstadoPoder extends PowerUpsStatesTemporales {
	public static final Integer DEFAULT_TURNOS = 2;
	
	public EstadoPoder(Nave nave) {
		this(nave, EstadoPoder.DEFAULT_TURNOS);
	}
	
    public EstadoPoder(Nave nave, Integer duracionTurnos) {
		super(nave, duracionTurnos);
		}
    /*
    @Override
    public void removerMejora(Nave nave) {
        NaveDecorator decorator = DecoratorUtils.findDecorator(nave.getPropiedadesNave(), DmgBoosterDecorator.class);
        if (decorator != null) {
            nave.setPropiedadesNave(decorator.getWrapped());
            System.out.println("Poder desactivado.");
        }
    }
    */
    
	@Override
	public void ataca() {
		System.out.println("Podeeeer");
		// TODO Auto-generated method stub
		this.nave.getPropiedadesNave().atacar();
		this.nave.getPropiedadesNave().atacar();
		this.numeroTurnos++;
		if(this.checkTurnos()) {
			this.cambiarAEstadoNormal();
		}
	}

	@Override
	public void desplaza() {
		this.nave.desplazarse();
		this.numeroTurnos++;
		if(this.checkTurnos()) {
			this.cambiarAEstadoNormal();
		}
	}
}