package Personajes;

import spaceinvaders.Coordenada;

public interface PropiedadesNave{
	public void atacar();
	public Double getDmg();	
	public void setDmg(Double dmg);	
	public Double getHp();	
	public void setHp(Double hp);
	public void setPosicion(Coordenada posicion);
	public Coordenada getPosicion();	
	public String toString();
	public void modificarEstadisticas();
	public PropiedadesNave getWrapped();
}
