package Personajes;

public interface PowerUpsStates {
	public void ataca();
    public void desplaza();
}