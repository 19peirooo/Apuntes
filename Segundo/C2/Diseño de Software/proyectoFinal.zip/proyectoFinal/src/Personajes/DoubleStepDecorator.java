package Personajes;

import spaceinvaders.Coordenada;

public class DoubleStepDecorator extends NaveDecorator {
    public static final Integer DEFAULT_PRECIO = 500;

    public DoubleStepDecorator(PropiedadesNave naveADecorar) {
        super(naveADecorar, DoubleStepDecorator.DEFAULT_PRECIO);
    }

    @Override
    public void setPosicion(Coordenada posicion) {
        Coordenada actual = naveADecorar.getPosicion();
        int deltaColumna = posicion.getColumna() - actual.getColumna();

        int paso = Integer.signum(deltaColumna) * 2;
        int nuevaColumna = actual.getColumna() + paso;

        Coordenada nuevaPos = new Coordenada(actual.getFila(), nuevaColumna);
        naveADecorar.setPosicion(nuevaPos);
    }

    @Override
    public String getDecoratorDescription() {
    	return "La nave ahora se mueve de dos en dos bloques; ";
    }

	@Override
	public void atacar() {
		this.naveADecorar.atacar();
	}
	
	public String toString() {
		return "DoubleStep Precio: " + this.precio;
	}

	@Override
	public void modificarEstadisticas() {
		this.naveADecorar.modificarEstadisticas();
	}
}