package Personajes;

public class DobleDañoItem extends NaveDecorator{
    public static final Integer DEFAULT_PRECIO = 500;
	
	public DobleDañoItem(PropiedadesNave naveADecorar) {
		super(naveADecorar, DobleDañoItem.DEFAULT_PRECIO);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void atacar() {
		this.naveADecorar.atacar();
	}

	@Override
	public void modificarEstadisticas() {
		this.naveADecorar.setDmg(naveADecorar.getDmg()*2);		

	}

	@Override
	public String getDecoratorDescription() {
		// TODO Auto-generated method stub
		return null;
	}

}	
