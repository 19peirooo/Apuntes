package Personajes;

import spaceinvaders.Coordenada;
import spaceinvaders.Partida;
import enemy.*;

public class NavePredeterminada implements PropiedadesNave{

	public static final Double DEFAULT_HP = 100.0;
	public static final Double DEFAULT_DMG = 25.0;
	 
	private Double hp;
	private Double dmg;
	private Coordenada posicion;
	
	public NavePredeterminada(Coordenada posicion) {
		this.hp = NavePredeterminada.DEFAULT_HP;
		this.dmg = NavePredeterminada.DEFAULT_DMG;
		this.posicion = posicion;
	}
	
	public static boolean probabilidad15PorCien(){
		return Math.random() <= 0.15;
	}
	
	@Override
	public Double getDmg() {
		return this.dmg;
	}
	
	@Override
	public Double getHp() {
		return this.hp;
	}
	
	public void setHp(Double hp) {
		this.hp = hp;
		if (this.hp <= 0.0) {
			this.hp = 0.0;
		}
	}
	
	public void setDmg(Double dmg) {
		this.dmg = dmg;
	}
	
	public void setPosicion(Coordenada posicion) {
		this.posicion = posicion;
	}
	
	public Coordenada getPosicion() {
		return this.posicion;
	}
	@Override
	public void atacar() {
		Integer mayor = 0;
		Enemy enemigoAtacado = null;
		
		// recorro los enemigos
		for (Enemy enemigo : Partida.getInstance().getEnemigos()) {
			// compruebo que esté encima de la nave
			if(enemigo.getCoordinate().getColumna().equals(this.posicion.getColumna())) {
				// me quedo con el más cercano a la nave
				if (enemigo.getCoordinate().getFila() > mayor) {
					mayor = enemigo.getCoordinate().getFila();
					enemigoAtacado = enemigo;
				}
			}
			
		}
		// se ha encontrado algún enemigo
		if(enemigoAtacado != null) {
			// modifico la vida del primer enemigo
			if (enemigoAtacado instanceof DeathStar) {
				DeathStar deathStar = (DeathStar)enemigoAtacado;
				if (!(deathStar.getShield().equals(0.0))) {
					
					if (deathStar.getShield() - this.dmg < 0) {
						deathStar.setHp(deathStar.getHP()-((deathStar.getShield() - Nave.getInstance().getDmg())*-1));
					}
					deathStar.setShield(deathStar.getShield() - Nave.getInstance().getDmg());
				} else {
					enemigoAtacado.setHp(enemigoAtacado.getHP() - Nave.getInstance().getDmg());
				}
				
			} else {
				enemigoAtacado.setHp(enemigoAtacado.getHP() - Nave.getInstance().getDmg());
			}
			
		
			if (enemigoAtacado.estaMuerto()) {
				this.darPuntos(enemigoAtacado);
				Partida.getInstance().removeEnemy(enemigoAtacado);
				Partida.getInstance().update(Partida.getInstance(), enemigoAtacado);
			    if (probabilidad15PorCien() && Nave.getInstance().getCurrentState().equals(Nave.getInstance().getEstadoNormal())) {
			    	// aplicar un state aleatorio
			    	Integer eleccion = (int) (Math.random() * 3);
			        
			        switch (eleccion) {
			            case 0:
			            	Nave.getInstance().cambiarEstado(Nave.getInstance().getEstadoCuracion());
			            	break;
			            case 1:
			            	Nave.getInstance().cambiarEstado(Nave.getInstance().getEstadoTurbo());
			                break;
			            case 2:
			            default:
			            	Nave.getInstance().cambiarEstado(Nave.getInstance().getEstadoPoder());
			                break;
			        }
			    }
			}
			System.out.println("Se ha atacado a enemigo: " + enemigoAtacado.toString());
		}
	}
	public void darPuntos(Enemy enemigoAtacado) {
		if (enemigoAtacado instanceof Ufo) {
			Partida.getInstance().addPuntos(Ufo.DEFAULT_POINTS);
		}else if (enemigoAtacado instanceof DeathStar) {
			Partida.getInstance().addPuntos(DeathStar.DEFAULT_POINTS);
		}else if (enemigoAtacado instanceof AlienShooter) {
			Partida.getInstance().addPuntos(AlienShooter.DEFAULT_POINTS);
		}
	}
	public void modificarEstadisticas() {
	    System.out.println("Nave base; "); 
	}
	
	public PropiedadesNave getWrapped() {
	    return this;  // no envuelve nada más
	}
	
	@Override
	public String toString() {
	    return "NavePredeterminada {" +
	            "HP = " + hp +
	            ", DMG = " + dmg +
	            ", Posición = (" + posicion.getFila() + ", " + posicion.getColumna() + ")" +
	            '}';
	}
}