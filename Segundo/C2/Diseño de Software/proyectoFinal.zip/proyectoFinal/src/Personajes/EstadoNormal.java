package Personajes;

public class EstadoNormal implements PowerUpsStates {
	public static final Integer DEFAULT_TURNOS = 2;
	private Nave nave;
	
	public EstadoNormal(Nave nave) {
		this.nave = nave;
	}
	

    /*
    @Override
    public void removerMejora(Nave nave) {
        NaveDecorator decorator = DecoratorUtils.findDecorator(nave.getPropiedadesNave(), DmgBoosterDecorator.class);
        if (decorator != null) {
            nave.setPropiedadesNave(decorator.getWrapped());
            System.out.println("Poder desactivado.");
        }
    }
    */
    
	@Override
	public void ataca() {
		System.out.println(this.nave.getPropiedadesNave().getDmg());
		// TODO Auto-generated method stub
		this.nave.getPropiedadesNave().atacar();
	}

	@Override
	public void desplaza() {
		this.nave.desplazarse();
	}
}
