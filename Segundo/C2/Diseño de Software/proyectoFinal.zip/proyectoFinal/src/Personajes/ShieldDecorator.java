package Personajes;

public class ShieldDecorator extends NaveDecorator {
    private boolean escudoActivo;
    public static final Integer DEFAULT_PRECIO = 500;
    
    public ShieldDecorator(PropiedadesNave naveADecorar) {
        super(naveADecorar, ShieldDecorator.DEFAULT_PRECIO);
        this.escudoActivo = true;
    }

    @Override
    public void setHp(Double hp) {
        if (escudoActivo && hp < naveADecorar.getHp()) {
            System.out.println("¡El escudo ha bloqueado el daño!");
            escudoActivo = false;

            // Eliminar este decorador de la cadena
            Nave naveInstance = Nave.getInstance();
            NaveDecorator thisDecorator = DecoratorUtils.findDecorator(naveInstance.getPropiedadesNave(), ShieldDecorator.class);
            if (thisDecorator != null) {
                naveInstance.setPropiedadesNave(thisDecorator.getWrapped());
                System.out.println("Escudo eliminado de la nave.");
            }

        } else {
            naveADecorar.setHp(hp);
        }
    }

    @Override
    public String getDecoratorDescription() {
        return "La nave tiene un escudo activo; ";
    }

    @Override
    public void atacar() {
        naveADecorar.atacar();
    }

    @Override
    public String toString() {
        return "Shield Precio: " + this.precio;
    }

	@Override
	public void modificarEstadisticas() {
		// TODO Auto-generated method stub
		this.setHp(getHp());
		this.naveADecorar.modificarEstadisticas();
	}
}
