package Personajes;

import spaceinvaders.Coordenada;

public abstract class NaveDecorator implements PropiedadesNave{

	protected PropiedadesNave naveADecorar;
	protected Integer precio;
	
	
	public NaveDecorator(PropiedadesNave naveADecorar, Integer precio) {
		this.naveADecorar = naveADecorar;
		this.precio = precio;
	}
	
	@Override
	public Double getDmg() {
		return this.naveADecorar.getDmg();
	}

	@Override
	public Double getHp() {
		return this.naveADecorar.getHp();
	}

	@Override
	public void setHp(Double hp) {
		this.naveADecorar.setHp(hp);
		
	}

	@Override
	public void setPosicion(Coordenada posicion) {
	this.naveADecorar.setPosicion(posicion);
		
	}
	@Override
	public void setDmg(Double dmg) {
		this.naveADecorar.setDmg(dmg);
	}
	@Override
	public Coordenada getPosicion() {
		return this.naveADecorar.getPosicion();
	}
	
	public void setPrecio(Integer precio) {
		this.precio = precio;
	}
	
	public Integer getPrecio() {
		return this.precio;
	}

	public PropiedadesNave getWrapped() {
	    return this.naveADecorar;
	}
	
	public abstract String getDecoratorDescription();
	public abstract void modificarEstadisticas();
}
