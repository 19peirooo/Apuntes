package Personajes;

import spaceinvaders.Mapa;
import spaceinvaders.Utils;

import spaceinvaders.Coordenada;

public class Nave implements Character{
	
	public static final String DEFAULT_ICON = "🚀";
	
	private static Nave nave = new Nave();
	private String icon;
	private PropiedadesNave propiedadesNave;
	private PowerUpsStates currentState;
	private EstadoPoder estadoPoder;
	private EstadoNormal estadoNormal;
	private EstadoTurbo estadoTurbo;
	private EstadoCuracion estadoCuracion;

	private Nave() {
		this.icon = Nave.DEFAULT_ICON;
	    this.propiedadesNave = new NavePredeterminada(new Coordenada(Mapa.DEFAULT_ROW-1,Mapa.DEFAULT_COL/2)); // Strong composition
	    this.estadoPoder = new EstadoPoder(this);
	    this.estadoNormal = new EstadoNormal(this);
	    this.estadoTurbo = new EstadoTurbo(this);
	    this.estadoCuracion = new EstadoCuracion(this);
	    this.currentState = this.estadoNormal;
	}
	
	
	public static Nave getInstance() {
		return nave;
	}

	@Override
	public Coordenada getCoordinate() {
		return this.propiedadesNave.getPosicion();
	}
	
	public void setCoordinate(Coordenada coordenada) {
		this.propiedadesNave.setPosicion(coordenada);
	}
	
	@Override
	public String getIcon() {
		return this.icon;
	}

	public PowerUpsStates getCurrentState() {
        return this.currentState;
    }
	
	@Override
	public void ataca() {
		this.propiedadesNave.atacar();
	}

	@Override
	public void desplazarse() {
		Boolean coordenadaValida = false;
		Coordenada nuevaCoordenada = null;
		String direccion = "";
		while (!coordenadaValida) {
			System.out.println("===================================");
			System.out.println("   🚀 OPCIONES DE MOVIMIENTO 🚀");
			System.out.println("===================================");
			System.out.println("  1️.  Mover a la Derecha ");
			System.out.println("  2️.  Mover a la Izquierda ");
			System.out.println("===================================");

			Integer opcion = Utils.pedirNumero(1, 2);
			Integer nuevaColumna = this.getCoordinate().getColumna();
			switch (opcion) {
	        case 1:
	        	nuevaColumna = this.getCoordinate().getColumna() + 1;
	        	direccion = "derecha";
	            break;
	        case 2:
	        	nuevaColumna = this.getCoordinate().getColumna() - 1;
	        	direccion = "izquierda";
	            break;
			}
			nuevaCoordenada = new Coordenada(this.propiedadesNave.getPosicion().getFila(), nuevaColumna);
			coordenadaValida = Mapa.getInstance().coordenadaEnMapa(nuevaCoordenada);
			if (!coordenadaValida) {
				System.out.println("No te puedes mover a la " + direccion);
			}
		}
		
		Mapa.getInstance().remove(this.getCoordinate());
		this.propiedadesNave.setPosicion(nuevaCoordenada);
		Mapa.getInstance().add(this.icon, nuevaCoordenada);
	}

	public Double getDmg() {
		return this.propiedadesNave.getDmg();
	}
	public void setHp(Double hp) {
		this.propiedadesNave.setHp(hp);
	}

	@Override
	public Double getHP() {
		return this.propiedadesNave.getHp();
	}
	
	public PropiedadesNave getPropiedadesNave() {
	    return this.propiedadesNave;
	}

	public void setPropiedadesNave(PropiedadesNave propiedadesNave) {
	    this.propiedadesNave = propiedadesNave;
	}
	
	public boolean estaMuerto() {
	    return this.getHP() <= 0;
	}
	public EstadoPoder getEstadoPoder() {
		return this.estadoPoder;
	}
	public EstadoNormal getEstadoNormal() {
		return this.estadoNormal;
	}
	public EstadoTurbo getEstadoTurbo() {
		return this.estadoTurbo;
	}
	public EstadoCuracion getEstadoCuracion() {
		return this.estadoCuracion;
	}
	/*
    public void cambiarEstado(PowerUpsStates nuevoEstado) {
        this.currentState.removerMejora(this);
        this.currentState = nuevoEstado;
        this.currentState.aplicarMejora(this);
    }
    */


	public void cambiarEstado(PowerUpsStates nuevoEstado) {
		// TODO Auto-generated method stub
		this.currentState = nuevoEstado;
	}
	
}
