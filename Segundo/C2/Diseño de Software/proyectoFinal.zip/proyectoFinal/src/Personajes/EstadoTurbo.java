package Personajes;

public class EstadoTurbo extends PowerUpsStatesTemporales {
	public static final Integer DEFAULT_TURNOS = 2;
	
	public EstadoTurbo(Nave nave) {
		this(nave, EstadoTurbo.DEFAULT_TURNOS);
	}
	
    public EstadoTurbo(Nave nave, Integer duracionTurnos) {
		super(nave, duracionTurnos);
		}
    /*
    @Override
    public void removerMejora(Nave nave) {
        NaveDecorator decorator = DecoratorUtils.findDecorator(nave.getPropiedadesNave(), DmgBoosterDecorator.class);
        if (decorator != null) {
            nave.setPropiedadesNave(decorator.getWrapped());
            System.out.println("Poder desactivado.");
        }
    }
    */
    
	@Override
	public void ataca() {
		// TODO Auto-generated method stub
		System.out.println("Turbooooo");
		this.nave.getPropiedadesNave().atacar();
		this.numeroTurnos++;
		if(this.checkTurnos()) {
			this.cambiarAEstadoNormal();
		}
	}

	@Override
	public void desplaza() {
		this.nave.desplazarse();
		this.nave.desplazarse();
		this.numeroTurnos++;
		if(this.checkTurnos()) {
			this.cambiarAEstadoNormal();
		}
	}
}