package Personajes;

import spaceinvaders.Coordenada;

public interface Character {
	public Coordenada getCoordinate();
	public String getIcon();
	public Double getDmg();
	public Double getHP();
	public void ataca();
	public void desplazarse();
	public boolean estaMuerto();
}
