package Personajes;

public abstract class PowerUpsStatesTemporales implements PowerUpsStates{
	protected Nave nave;
	protected Integer duracionTurnos;
	protected Integer numeroTurnos;
	
	public PowerUpsStatesTemporales(Nave nave, Integer duracionTurnos) {
		this.duracionTurnos = duracionTurnos;
		this.numeroTurnos = 0;
		this.nave = nave;
		}
	public boolean checkTurnos() {
		return this.numeroTurnos.equals(this.duracionTurnos);
	}
	public void cambiarAEstadoNormal() {
		this.nave.cambiarEstado(this.nave.getEstadoNormal());
		this.numeroTurnos = 0;
	}
}