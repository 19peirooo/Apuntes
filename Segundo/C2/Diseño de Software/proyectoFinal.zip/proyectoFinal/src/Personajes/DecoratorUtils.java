package Personajes;

public class DecoratorUtils {
    public static NaveDecorator findDecorator(PropiedadesNave nave, Class<?> decoratorClass) {
        if (!(nave instanceof NaveDecorator)) {
            return null;
        }
        NaveDecorator current = (NaveDecorator) nave;
        if (current.getClass().equals(decoratorClass)) {
            return current;
        } else {
            return findDecorator(current.getWrapped(), decoratorClass);
        }
    }
}