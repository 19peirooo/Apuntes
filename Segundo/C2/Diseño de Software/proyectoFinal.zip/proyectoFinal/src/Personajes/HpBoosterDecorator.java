package Personajes;

public class HpBoosterDecorator extends NaveDecorator {
    public static final Integer DEFAULT_PRECIO = 500;

    public HpBoosterDecorator(PropiedadesNave naveADecorar) {
        super(naveADecorar, HpBoosterDecorator.DEFAULT_PRECIO);
    }

    public Double getHp() {
        return super.getHp();  // suma 50 de HP
    }

    @Override
    public String getDecoratorDescription() {
        return "Aplicado aumento de vida (+50 HP); ";
    }

	@Override
	public void atacar() {
		this.naveADecorar.atacar();
	}
	
	public String toString() {
		return "HpBooster Precio: " + this.precio;
	}

	@Override
	public void modificarEstadisticas() {
		// TODO Auto-generated method stub
		this.naveADecorar.setHp(this.naveADecorar.getHp() + 50.0);
	}
}
