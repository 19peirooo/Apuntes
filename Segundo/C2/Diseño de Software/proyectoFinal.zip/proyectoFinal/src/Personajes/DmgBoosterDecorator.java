package Personajes;

public class DmgBoosterDecorator extends NaveDecorator {
    public static final Integer DEFAULT_PRECIO = 500;
	
    public DmgBoosterDecorator(PropiedadesNave naveADecorar) {
        super(naveADecorar, DmgBoosterDecorator.DEFAULT_PRECIO);
        this.modificarEstadisticas();
    }

    @Override
    public Double getDmg() {
        return super.getDmg() * 1.5;  // aumenta el daño un 50%
    }

    @Override
    public String getDecoratorDescription() {
        return "Aplicado aumento de daño (50%); ";
    }

	@Override
	public void atacar() {
		this.naveADecorar.atacar();
	}
	
	public String toString() {
		return "DmgBooster Precio: " + this.precio;
	}

	@Override
	public void modificarEstadisticas() {
		// TODO Auto-generated method stub
		
	}
}
