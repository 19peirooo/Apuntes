package Personajes;

public class EstadoCuracion extends PowerUpsStatesTemporales {
	public static final Integer DEFAULT_TURNOS = 2;
	
	public EstadoCuracion(Nave nave) {
		this(nave, EstadoCuracion.DEFAULT_TURNOS);
	}
	
    public EstadoCuracion(Nave nave, Integer duracionTurnos) {
		super(nave, duracionTurnos);
	}
    
    public void curar() {
    	System.out.println("Curacion");
    	this.nave.getPropiedadesNave().setHp(this.nave.getPropiedadesNave().getHp() + 20);
    }
    /*
    @Override
    public void removerMejora(Nave nave) {
        NaveDecorator decorator = DecoratorUtils.findDecorator(nave.getPropiedadesNave(), DmgBoosterDecorator.class);
        if (decorator != null) {
            nave.setPropiedadesNave(decorator.getWrapped());
            System.out.println("Poder desactivado.");
        }
    }
    */
    
	@Override
	public void ataca() {
		// TODO Auto-generated method stub
		this.curar();
		this.nave.getPropiedadesNave().atacar();
		this.numeroTurnos++;
		if(this.checkTurnos()) {
			this.cambiarAEstadoNormal();
		}
	}

	@Override
	public void desplaza() {
		this.curar();
		this.nave.desplazarse();
		this.numeroTurnos++;
		if(this.checkTurnos()) {
			this.cambiarAEstadoNormal();
		}
	}
}