package Personajes;

import spaceinvaders.Coordenada;

public class Barrera {
	
	public static final Integer NUM_VIDAS = 3;
	private Integer vidas;
	private String icon;
	private Coordenada posicion;
	
	public Barrera(Coordenada posicion) {
		this.vidas = Barrera.NUM_VIDAS;
		this.icon = "🛡️";
		this.posicion = posicion;
	}

	public Integer getVidas() {
		return this.vidas;
	}

	public void setVidas(Integer vidas) {
		this.vidas = vidas;
	}

	public String getIcon() {
		return this.icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public Coordenada getPosicion() {
		return this.posicion;
	}

	public void setPosicion(Coordenada posicion) {
		this.posicion = posicion;
	}
	
}
