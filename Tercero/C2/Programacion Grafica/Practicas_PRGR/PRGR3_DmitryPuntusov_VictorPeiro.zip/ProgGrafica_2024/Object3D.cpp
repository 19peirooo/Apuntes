#include "Object3D.h"
#include "InputManager.h"
#include "Matrix4x4f.h"

unsigned int Object3D::contador = 0;

Object3D::Object3D()
{
	objId = contador;
	contador++;
}

void Object3D::createTriangle() {
	// el centro esta en (0, 0, 0):
	// entonces los vertices:
	// (-0.5, -0.5, 0, 0), (0, 0.5, 0, 0), (0.5, -0.5, 0, 0)
	this->position = make_vector4f(0, 0, 0, 1);
	this->rotation = make_vector4f(0, 0, 0, 0); 
	this->scale = make_vector4f(1, 1, 1, 0);
	
	updateModelMatrix();

	this->vertexList = {
		{-0.5, -0.5, 0, 1},
		{0, 0.5, 0, 1},
		{0.5, -0.5, 0, 1}
	};

	this->idList = {
		0,1,2
	};
}

void Object3D::move(double timeStep)
{
	float rotSpeed = 90.0f;
		if (InputManager::keysState[GLFW_KEY_A])
			rotation.v[1] -= rotSpeed * timeStep;
		if (InputManager::keysState[GLFW_KEY_D])
			rotation.v[1] += rotSpeed * timeStep;
	//rotation.v[0] += rotSpeed * timeStep;
	//rotation.v[2] += rotSpeed * timeStep;

	updateModelMatrix();
} 

void Object3D::updateModelMatrix() {
	// M = T*R*S
	Matrix4x4f T = make_translate(position.x, position.y, position.z);
	Matrix4x4f R = make_rotate(rotation.x, rotation.y, rotation.z); 
	Matrix4x4f S = make_scale(scale.x, scale.y, scale.z);

	modelMatrix = T * R * S;
}

void Object3D::loadFromFile(const char* fileName)
{

	string simbolo_comentario = "€"; //Como se interpreta � en consola

	std::ifstream file(fileName);

	if (!file.is_open())
	{
		std::cout << "ERROR: No se pudo abrir archivo\n";
		return;
	}

	string line;
	int numVertices = 0;
	int numCaras = 0;
	int count = 0;
	this->vertexList.clear();
	this->idList.clear();

	//leer numero de vertices
	while (std::getline(file, line)) {
		if (line.empty() || line.starts_with(simbolo_comentario)) continue; // Si la linea es un comentario o es una linea vacia. No hacer nada

		std::stringstream ss(line);
		ss >> numVertices;
		break;
	}

	//leer vertices
	while (std::getline(file, line) && count < numVertices) {

		if (line.empty() || line.starts_with(simbolo_comentario)) continue; // Si la linea es un comentario o es una linea vacia. No hacer nada

		vector<float> vertexes = splitString<float>(line, ' ');
		Vertex v;
		v.position = make_vector4f(vertexes[0], vertexes[1], vertexes[2], 1);
		v.color = make_vector4f(vertexes[3], vertexes[4], vertexes[5], vertexes[6]);
		this->vertexList.push_back(v);
		count++;
	}

	//leer caras
	while (std::getline(file, line)) {

		if (line.empty() || line.starts_with(simbolo_comentario)) continue; // Si la linea es un comentario o es una linea vacia. No hacer nada

		std::stringstream ss(line);
		ss >> numCaras;
		break;
	}

	//leer ids
	count = 0;
	while (std::getline(file, line) && count < numCaras) {

		if (line.empty() || line.starts_with(simbolo_comentario)) continue; // Si la linea es un comentario o es una linea vacia. No hacer nada

		vector<int> ids = splitString<int>(line, ' ');
		for (auto id : ids) this->idList.push_back(id);
		count++;
	}

	this->position = make_vector4f(0, 0, 0, 1);
	this->rotation = make_vector4f(0, 0, 0, 0);
	this->scale = make_vector4f(1, 1, 1, 0);

	updateModelMatrix();
	file.close();

}
