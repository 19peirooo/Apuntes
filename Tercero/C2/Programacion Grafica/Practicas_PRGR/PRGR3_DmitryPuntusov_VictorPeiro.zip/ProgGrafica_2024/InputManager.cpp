#include "InputManager.h"

std::map<int, bool> InputManager::keysState;
std::map<int, bool> InputManager::mouseState;
double InputManager::posMX = 0;
double InputManager::posMY = 0;

//Funcion Callback
void InputManager::keyboardManager(GLFWwindow* window, int key, int scancode, int action, int mods) {

	switch (action) {
	case GLFW_PRESS: {
		keysState[key] = true;
	}break;
	case GLFW_RELEASE: {
		keysState[key] = false;
	}break;
	}

}

void InputManager::mousePosManager(GLFWwindow* window, double xpos, double ypos)
{
	posMX = xpos;
	posMY = ypos;
}

void InputManager::mouseButtonManager(GLFWwindow* window, int button, int action, int mods)
{
	switch (action) {
	case GLFW_PRESS: {
		mouseState[button] = true;
	}break;
	case GLFW_RELEASE: {
		mouseState[button] = false;
	}
	}
}

void InputManager::init(GLFWwindow* window) {

	glfwSetKeyCallback(window, keyboardManager); //Callback de teclado --> Cada vez que haya un evento de teclado se ejecuta la funcion callback
	glfwSetCursorPosCallback(window, mousePosManager); //Callback de movimiento de raton --> Cada vez que se mueva el raton ejecuta la funcion callback
	glfwSetMouseButtonCallback(window, mouseButtonManager); //Callback de pulsado de raton --> Cada vez que haya un evento de raton se ejecuta la funcion callback

}

void InputManager::updateEvents() {
	glfwPollEvents(); // Actualizar resto de eventos de ventana
}