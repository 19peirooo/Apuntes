#pragma once
#include "vector4f.h"
#include "Matrix4x4f.h"
#include "vertex.h"

class Object3D
{

public:
	Vector4f position;
	Vector4f rotation;
	Vector4f scale;

	Matrix4x4f modelMatrix;
	
	static unsigned int contador;
	unsigned int objId;

	std::vector<Vertex> vertexList;
	// lista de vertices de objeto
	std::vector<int> idList;
	// lista con los indices que se usaran para dibujar
	// la lista de vertices

	Object3D(); //Constructor de la clase
	void createTriangle();
	// metodo que inicializa la lista de vertices con 3 vertices
	// formando un triangulo cuyo centro se encontrara en el origen(0,0,0)
	virtual void move(double timeStep);
	// metodo virtual que actualiza la posi/rot/scale del objeto.
	// debera consultar el estado del teclado, y si se pulsa la tecla "D" aumenara
	// el angulo de giro en el eje Y.
	void updateModelMatrix();
	// actualiza la matriz modelo en base a los datos de posi/rot/scale del objeto.
	void loadFromFile(const char* fileName); //Carga una figura de un archivo .frs
};

