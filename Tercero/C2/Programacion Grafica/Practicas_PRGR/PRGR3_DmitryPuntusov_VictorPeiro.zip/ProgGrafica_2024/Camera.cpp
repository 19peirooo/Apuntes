#include "Camera.h"

Camera::Camera(Vector4f pos, Vector4f rot, Vector4f lookAt, Vector4f Up, float fovy, float aspectRatio, float zNear, float Zfar)
{
	this->pos = pos;
	this->rot = rot;
	this->lookAt = lookAt;
	this->Up = Up;
	this->fovy = fovy * PI / 180.0f;
	this->aspectRatio = aspectRatio;
	this->zNear = zNear;
	this->Zfar = Zfar;
	this->lookAtPrime = lookAt - pos;
	this->lastMouseX = (float)InputManager::posMX;
	this->lastMouseY = (float)InputManager::posMY;
}

Matrix4x4f Camera::getMatrixLookAt()
{
	Matrix4x4f view = make_identityf();
	Vector4f forward = normalize(lookAt - pos);

	Vector4f right = normalize(forward ^ this->Up);
	Vector4f upCamera = normalize(right ^ forward);	// normal plano horizontal a la camera
	Vector4f position = make_vector4f(-1 * (right * this->pos), -(this->Up * this->pos), forward * this->pos, 1);

	view.t[0] = right;
	view.t[1] = upCamera;
	view.t[2] = forward * -1.0f;
	view.t[3] = { 0, 0, 0, 1 };
	view.matriz[0][3] = position.x;
	view.matriz[1][3] = position.y;
	view.matriz[2][3] = position.z;
	return view;
}

Matrix4x4f Camera::getMatrixperspective()
{
	Matrix4x4f projMatrix = make_identityf();
	projMatrix.matriz[0][0] = 1.0f / (aspectRatio * tan(fovy * 0.5f));
	projMatrix.matriz[1][1] = 1.0f / tan(fovy * 0.5f);
	projMatrix.matriz[2][2] = -(Zfar + zNear) / (Zfar - zNear);
	projMatrix.matriz[2][3] = 2.0f * Zfar * zNear / (Zfar - zNear);
	projMatrix.matriz[3][2] = -1.0f;


	return projMatrix;
}

void Camera::move(double timeStep)
{
	
	float speed = 2.0f;
	float angularSpeed = 50.0f;

	if (InputManager::keysState[GLFW_KEY_LEFT]) {
		this->pos.x -= speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_RIGHT]) {
		this->pos.x += speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_DOWN]) {
		this->pos.y -= speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_UP]) {
		this->pos.y += speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_F]) {
		this->rot.y -= angularSpeed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_H]) {
		this->rot.y += angularSpeed * timeStep;
	}
	
	Matrix4x4f rotMatrix = make_rotate(0, this->rot.y, 0);
	this->lookAt = rotMatrix * this->lookAtPrime;
	Matrix4x4f trasM = make_translate(this->pos.x, this->pos.y, this->pos.z);
	this->lookAt = trasM * this->lookAt;
}

void Camera::moveFPS(double timeStep)
{
	float dt = (float)timeStep;
	float speed = 2.0f;
	float angularSpeed = 50.0f;
	float mouseSensivity = 50.0f;
	// Mouse movement:
	float deltaX = (float)InputManager::posMX - lastMouseX;
	float deltaY = (float)InputManager::posMY - lastMouseY;
	lastMouseX = (float)InputManager::posMX;
	lastMouseY = (float)InputManager::posMY;
	this->rot.y -= deltaX * mouseSensivity * dt;	// Yaw left/right
	this->rot.x -= deltaY * mouseSensivity * dt;	// Pitch up/down
	// Clamp 
	if (this->rot.x > 89.0f) this->rot.x = 89.0f;
	if (this->rot.x < -89.0f) this->rot.x = -89.0f;
	// Create rotation matrices
	Matrix4x4f yRotationMatrix = make_rotate(0, this->rot.y, 0);
	Matrix4x4f xRotationMatrix = make_rotate(this->rot.x, 0, 0);
	Matrix4x4f combinedRotation = yRotationMatrix * xRotationMatrix;
	Vector4f defaultForward = make_vector4f(0, 0, -1, 0);
	lookAtPrime = combinedRotation * defaultForward;

	lookAt = pos + lookAtPrime;



	if (InputManager::keysState[GLFW_KEY_LEFT]) {
		//this->pos.x -= speed * dt;
		Vector4f forward = this->lookAt - pos;
		Vector4f right = normalize((this->Up ^ forward));	// Order of cross product matters to get (1, 0, 0)
		pos = pos + right * speed * dt;
	}
	if (InputManager::keysState[GLFW_KEY_RIGHT]) {
		//this->pos.x += speed * dt;
		Vector4f forward = this->lookAt - pos;
		Vector4f right = normalize((this->Up ^ forward));	// Order of cross product matters to get (1, 0, 0)
		pos = pos - right * speed * dt;
	}
	if (InputManager::keysState[GLFW_KEY_DOWN]) {
		//this->pos.y -= speed * dt;
		Vector4f backward = this->pos - this->lookAt;
		pos = pos + normalize(backward) * speed * dt;
	}
	if (InputManager::keysState[GLFW_KEY_UP]) {
		//this->pos.y += speed * dt;
		Vector4f forward = this->lookAt - pos;
		pos = pos + normalize(forward) * speed * dt;
	}
	if (InputManager::keysState[GLFW_KEY_F]) {
		this->rot.y -= angularSpeed * dt;
	}
	if (InputManager::keysState[GLFW_KEY_H]) {
		this->rot.y += angularSpeed * dt;
	}

	//Matrix4x4f rotMatrix = make_rotate(0, this->rot.y, 0);
	//this->lookAt = rotMatrix * this->lookAtPrime;
	//Matrix4x4f trasM = make_translate(this->pos.x, this->pos.y, this->pos.z);
	//this->lookAt = trasM * this->lookAt;
	this->lookAt = this->pos + this->lookAtPrime;
}
