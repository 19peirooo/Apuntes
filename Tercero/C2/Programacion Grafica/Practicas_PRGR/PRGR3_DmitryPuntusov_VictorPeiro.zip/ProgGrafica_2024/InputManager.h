#pragma once
#include "common.h"

class InputManager
{
	public:
		static std::map<int, bool> keysState; //Guarda el estado del teclado para ver si las teclas estan pulsadas
		static std::map<int, bool> mouseState; //Guarda el estado de los botones del raton 
		static double posMX, posMY; //Guarda la posicion del raton

		static void keyboardManager(GLFWwindow* window, int key, int scancode, int action, int mods); //Recibe eventos de teclado y actualiza el mapa de teclas
		static void mousePosManager(GLFWwindow* window, double xpos, double ypos); //Recibe eventos de movimiento de raton y actualiza su posicion
		static void mouseButtonManager(GLFWwindow* window, int button, int action, int mods); //Recibe eventos de pulsado de botones de raton
		static void init(GLFWwindow* window); //Recibe la ventana donde se generan los eventos de teclado y raton
		static void updateEvents();
};

