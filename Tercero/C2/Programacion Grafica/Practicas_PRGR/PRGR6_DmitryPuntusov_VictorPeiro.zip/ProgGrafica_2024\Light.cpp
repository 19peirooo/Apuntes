#include "Light.h"
#include "InputManager.h"

Light::Light(Vector4f dir,Vector4f pos, Vector4f color, float Ia, float Id, float Is)
	: direction(dir), position(pos), color(color), Ia(Ia), Id(Id), Is(Is)
{

}

void Light::moveObject(double timeStep)
{
    if (lifeTime > 0.0f)
    {
        lifeTime -= timeStep;

        if (lifeTime <= 0.0f)
        {
            active = false;
        }
    }

}