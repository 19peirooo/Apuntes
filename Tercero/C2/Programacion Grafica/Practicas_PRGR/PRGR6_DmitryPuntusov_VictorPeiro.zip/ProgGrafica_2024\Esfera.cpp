#include "Esfera.h"

Esfera::Esfera(const char* fileName) : Object3D(fileName)
{
}

void Esfera::move(double timeStep)
{
	float rotSpeed = 45.0f; // grados por segundo, rotacion sobre si misma
	rotation.v[1] += rotSpeed * timeStep;
	if (rotation.v[1] > 360.0f) rotation.v[1] -= 360.0f;

	updateModelMatrix();
}
