#pragma once
#include "vector4f.h"

class Light
{
public:
	Vector4f direction = { 1,0,0,0 };
	Vector4f position = { 0,0,0,1 };
	Vector4f color = { 1,1,1,1 };

	float Ia, Id, Is;

	bool active = true;
	double lifeTime = -1.0f;

	Light(Vector4f dir, Vector4f pos, Vector4f color = { 1,1,1,1 }, float Ia = 0.8, float Id = 0.8, float Is = 0.8);

	void moveObject(double timeStep);

};

