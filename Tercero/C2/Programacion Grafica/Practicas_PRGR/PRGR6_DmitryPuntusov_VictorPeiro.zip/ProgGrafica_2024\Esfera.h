#pragma once
#include "Object3D.h"

class Esfera : public Object3D
{
public:
	Esfera(const char* fileName);
	void move(double timeStep) override;
};
