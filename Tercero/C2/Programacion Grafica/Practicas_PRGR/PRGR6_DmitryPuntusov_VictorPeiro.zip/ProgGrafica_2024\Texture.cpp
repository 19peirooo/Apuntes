#define STB_IMAGE_IMPLEMENTATION


#include "Texture.h"
#include "stb_image.h"

Texture::Texture(string fileName)
{
	this->width = 0;
	this->height = 0;
	this->textureName = fileName;
	//inicar identificadores
	glGenTextures(1, &this->textureId);
	int numChannels = 0;
	//cargar datos en gpu
	unsigned char* pixels = stbi_load(fileName.c_str(), &width, &height, &numChannels, 4); //El numChannels se ignora porque se va a extender a 4 canales
	this->rawImage.resize(width * height);
	int counter = 0;

	std::memcpy(rawImage.data(), pixels, sizeof(pixel_t) * width * height); //Mas rapido que el for de arriba
	stbi_image_free(pixels);
	updateTexture();
}

void Texture::updateTexture()
{
	glBindTexture(GL_TEXTURE_2D, this->textureId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, rawImage.data());
}
