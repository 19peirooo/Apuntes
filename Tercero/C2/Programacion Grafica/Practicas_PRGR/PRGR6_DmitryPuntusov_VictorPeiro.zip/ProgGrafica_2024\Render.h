#pragma once

#include "Object3D.h"
#include "InputManager.h"
#include "Camera.h"
#include "Light.h"

typedef struct {
	unsigned int bufferId;
	unsigned int vertexBufferId;
	unsigned int indexBufferId;
} bufferObject_t;

class Render
{
	private:

		int width, height;
		vector<Object3D*> objectList;
		vector<Object3D*> nextObjectList;
		map<unsigned int, bufferObject_t> bufferObjectsList;
		Camera* cam;
		Light* luz;
		bool salir = false;

		Light* tempLuz;

	public:
		GLFWwindow* window = nullptr;
		Render(int w, int h);

		void putCamera(Camera* cam);

		void putLight(Light* luz);

		void initGL();

		void putObject(Object3D* obj);

		void removeObject(Object3D* obj);

		void drawGL();

		void mainLoop();

		void updateObjects(double deltaTime);

		vector<Object3D*> getCollisions(Object3D* obj, int objType);

		void deleteObject(Object3D* obj);
};