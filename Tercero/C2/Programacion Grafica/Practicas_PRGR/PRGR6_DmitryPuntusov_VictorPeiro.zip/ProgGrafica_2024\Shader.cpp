#include "Shader.h"

Shader::Shader(std::string fileName)
{
	this->fileName = fileName;
	this->idShader = 0;
	this->type = 0; // Initialize to 0 or some invalid value
	if (fileName.ends_with(".vertex"))
		type = GL_VERTEX_SHADER;
	else if (fileName.ends_with(".fragment"))
		type = GL_FRAGMENT_SHADER;

	std::cout << "Loading shader: " << fileName << std::endl;
	readSource();
	if (!source.empty()) {
		compileShader();
	}

}


void Shader::readSource()
{
	std::ifstream file(fileName);

	if (!file.is_open())
	{
		std::cout << "ERROR: No se pudo abrir archivo\n";
		return;
	}
	std::stringstream ss;
	ss << file.rdbuf();
	source = ss.str();
	file.close();

}

//3. void compileShader()
//This is where you tell the GPU to take your text and turn it into a compiled shader.
//- Step 1: Call glCreateShader(type).This OpenGL function returns an ID.Save this ID into your
//idShader attribute.
//- Step 2 : OpenGL expects raw C - strings, not C++ std::string.Extract the C - string from your
//source attribute(using.c_str()).
//- Step 3 : Call glShaderSource(...).Pass in your idShader and the C - string you just extracted.
//This links the text code to the shader ID.
//- Step 4 : Call glCompileShader(idShader).This tells the GPU to compile it.
//- Step 5 : Call checkErrors(); immediately after compiling to ensure it worked.
void Shader::compileShader()
{
	idShader = glCreateShader(type);
	const char* src = source.c_str();
	glShaderSource(idShader, 1, &src, nullptr);
	glCompileShader(idShader);
	checkErrors();
}


void Shader::checkErrors()
{
	GLint retCode;
	char errorLog[1024];
	GLint fragment_compiled;
	glGetShaderiv(this->idShader, GL_COMPILE_STATUS, &fragment_compiled);
	if (fragment_compiled != GL_TRUE)
	{
		GLsizei log_length = 0;
		GLchar message[1024];
		glGetShaderInfoLog(this->idShader, 1024, &log_length, message);
		std::cout << "ERROR " << fileName << "\n" << message << "\n\n";
	}
	else {
		this->compiled = true;
	}
}

void Shader::clean()
{
	glDeleteShader(idShader);
}
