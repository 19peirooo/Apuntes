#include "Object3D.h"

unsigned int Object3D::contador = 0;

Object3D::Object3D(const char* fileName)
{
	this->objId = contador;
	contador++;

    this->position = make_vector4f(0, 0, 0, 1);
    this->rotation = make_vector4f(0, 0, 0, 0);
    this->scale = make_vector4f(1, 1, 1, 1);
    this->modelMatrix = make_identityf();

    // Initialize collider hierarchy early to avoid crashes if loadFromFile fails
    coll->root = new colliderNode;
    coll->root->bv = new Sphere();
    coll->root->sons[0] = coll->root->sons[1] = nullptr;

    this->prg = new Program(); 
    loadFromFile(fileName);

    if (vertexList.empty()) {
        std::cerr << "ERROR: Object3D " << fileName << " has no vertices!" << std::endl;
        return;
    }

    // Calculate mesh boundaries (AABB)
    Vector4f maxV = this->vertexList[0].position;
    Vector4f minV = this->vertexList[0].position;

    for (auto& v : vertexList) {
        maxV.x = std::fmaxf(v.position.x, maxV.x);
        maxV.y = std::fmaxf(v.position.y, maxV.y);
        maxV.z = std::fmaxf(v.position.z, maxV.z);
        minV.x = std::fminf(v.position.x, minV.x);
        minV.y = std::fminf(v.position.y, minV.y);
        minV.z = std::fminf(v.position.z, minV.z);
    }

    // Calculate geometric center
    Vector4f center = (maxV + minV) * 0.5f;
    center.w = 1.0f;

    // Calculate bounding sphere radius
    float maxRadiusSq = 0;
    for (auto& v : vertexList) {
        float distSq = 
            pow(v.position.x - center.x, 2) + 
            pow(v.position.y - center.y, 2) + 
            pow(v.position.z - center.z, 2);
        if (distSq > maxRadiusSq) maxRadiusSq = distSq;
    }

    // Configure sphere properties
    Sphere* s = (Sphere*)coll->root->bv;
    s->center = s->centerPrime = center;
    s->radius = sqrt(maxRadiusSq);
    
    // Set internal boundaries for updateCollider() to work correctly
    s->max = maxV;
    s->min = minV;

    updateModelMatrix();
}

Object3D::Object3D(const char* fileName, Program* prg)
{
    this->objId = contador;
    contador++;

    this->position = make_vector4f(0, 0, 0, 1);
    this->rotation = make_vector4f(0, 0, 0, 0);
    this->scale = make_vector4f(1, 1, 1, 1);
    this->modelMatrix = make_identityf();

    coll->root = new colliderNode;
    coll->root->bv = new Sphere();
    coll->root->sons[0] = coll->root->sons[1] = nullptr;

    this->prg = prg; // Use shared program
    this->sharedProgram = true;
    loadFromFile(fileName);

    if (vertexList.empty()) return;

    Vector4f maxV = this->vertexList[0].position;
    Vector4f minV = this->vertexList[0].position;
    for (auto& v : vertexList) {
        maxV.x = std::fmaxf(v.position.x, maxV.x);
        maxV.y = std::fmaxf(v.position.y, maxV.y);
        maxV.z = std::fmaxf(v.position.z, maxV.z);
        minV.x = std::fminf(v.position.x, minV.x);
        minV.y = std::fminf(v.position.y, minV.y);
        minV.z = std::fminf(v.position.z, minV.z);
    }
    Vector4f center = (maxV + minV) * 0.5f;
    center.w = 1.0f;
    float maxRadiusSq = 0;
    for (auto& v : vertexList) {
        float distSq = pow(v.position.x - center.x, 2) + pow(v.position.y - center.y, 2) + pow(v.position.z - center.z, 2);
        if (distSq > maxRadiusSq) maxRadiusSq = distSq;
    }
    Sphere* s = (Sphere*)coll->root->bv;
    s->center = s->centerPrime = center;
    s->radius = sqrt(maxRadiusSq);
    s->max = maxV; s->min = minV;
    updateModelMatrix();
}

void Object3D::updateModelMatrix() {
	// M = T*R*S
	Matrix4x4f T = make_traslate(position.x, position.y, position.z);
	Matrix4x4f R = make_rotate(rotation.x, rotation.y, rotation.z); 
	Matrix4x4f S = make_scale(scale.x, scale.y, scale.z);

	modelMatrix = T * R * S;
}


void Object3D::loadFromFile(const char* fileName)
{
    typedef enum {
        vertices, faces, normals, colors,matProperties, textureCoords,varDescriptions, done
    }dataTypesReading;
    float ka=1, kd=1, ks=1;
    int count = 0;
    string textureFile;
    string vertexShader;
    string fragmentShader;

    istringstream lineReader;
    std::ifstream f(fileName);
    if (!f.is_open()) {
        std::cerr << "ERROR: No se pudo abrir el archivo .frs: " << fileName << std::endl;
        return;
    }
    dataTypesReading mode = vertices;
    string line = "";
    do {
        switch (mode)
        {
        case vertices: {
            //leer numVertices
            int numVertex = 0;
            skipComments();
            lineReader >> numVertex;
            vertexList.resize(numVertex);
            for (int i = 0;i < numVertex;i++) {
                skipComments();
                lineReader = istringstream(line);
                lineReader >> vertexList[i].position.x;
                lineReader >> vertexList[i].position.y;
                lineReader >> vertexList[i].position.z;
                vertexList[i].position.w = 1.0f;
            }
            mode = faces;
        }break;
        case faces: {
            //leer numVertices
            int numFaces = 0;
            skipComments();
            lineReader >> numFaces;
            idList.resize(numFaces * 3);
            for (int i = 0;i < numFaces;i++) {
                skipComments();
                lineReader = istringstream(line);
                lineReader >> idList[i * 3] >> idList[i * 3 + 1] >> idList[i * 3 + 2];
            }
            mode = colors;
        }break;

        case colors: {
            //leer numVertices
            int numColors = 0;
            skipComments();
            lineReader >> numColors;
            for (int i = 0;i < numColors;i++) {
                skipComments();
                readMultipleData();
                if (data.size() < 4) continue;
                int numVertexIds = data.size() - 4;
                Vector4f color = make_vector4f(
                    data[numVertexIds],
                    data[numVertexIds + 1],
                    data[numVertexIds + 2],
                    data[numVertexIds + 3]
                );
                for (int j = 0;j < numVertexIds;j++) {
                    int idx = (int)data[j];
                    if (idx >= 0 && idx < (int)vertexList.size())
                        vertexList[idx].color = color;
                }
            }
            mode = normals;
        }break;

        case normals: {
            //leer numVertices
            int numNormals = 0;
            skipComments();
            lineReader >> numNormals;

            for (int i = 0;i < numNormals;i++) {
                skipComments();
                readMultipleData();

                if (data.size() < 4) continue;
                int numVertexIds = data.size() - 4;
                Vector4f normal = make_vector4f(
                    data[numVertexIds],
                    data[numVertexIds + 1],
                    data[numVertexIds + 2],
                    data[numVertexIds + 3]
                );
                for (int j = 0;j < numVertexIds;j++) {
                    int idx = (int)data[j];
                    if (idx >= 0 && idx < (int)vertexList.size())
                        vertexList[idx].normal = normal;
                }
            }
            mode = matProperties;
        }break;

        case matProperties: {
            skipComments();
            lineReader = istringstream(line); 
            vector<float> data = splitString<float>(line, ' '); 
            if (data.size() != 3) {
                ka = 1;
                kd = 1;
                ks = 1;
            }
            else {
                ka = data[0]; 
                kd = data[1]; 
                ks = data[2]; 
            }
            
            mode = textureCoords;
        }break;

        case textureCoords: {
            //leer numVertices
            int numTC = 0;
            skipComments();
            lineReader >> numTC;
            for (int i = 0;i < numTC;i++) {
                skipComments();
                readMultipleData();
                if (data.size() < 2) continue;
                int numVertexIds = data.size() - 2;
                float textureCoord[2] = {
                    data[numVertexIds],
                    data[numVertexIds + 1] };
                for (int j = 0;j < numVertexIds;j++) {
                    int idx = (int)data[j];
                    if (idx >= 0 && idx < (int)vertexList.size()) {
                        vertexList[idx].textureCoords.x = textureCoord[0];
                        vertexList[idx].textureCoords.y = textureCoord[1];
                    }
                }
            }
            skipComments();
            lineReader >> textureFile;
            skipComments();
            lineReader >> vertexShader;
            skipComments();
            lineReader >> fragmentShader;

            mode = varDescriptions;
        }break;

        
        case varDescriptions: {
            //leer descripciones de variables
            int numVariablesDescritas;
            skipComments();
            lineReader >> numVariablesDescritas;
            count = 0;
            for (int i = 0; i < numVariablesDescritas; i++) {
                skipComments();
                lineReader = istringstream(line); 

                vector<string> parts = splitString<string>(line, '=');
                
                if (parts.size() != 2) continue;

                string key = parts[0];
                string val = parts[1];

                if (this->prg != nullptr) {
                    this->prg->setDescription(key, val);
                }
            }
            mode = done; 
        }break;
        };

    } while (!f.eof() && mode != done); //Saltar comentarios iniciales
    if (this->prg != nullptr && !this->prg->linked) {
        this->prg->addShader(vertexShader);
        this->prg->addShader(fragmentShader);
        this->prg->linkProgram();
    }
    if (textureFile != "notexture") {
        this->mat = new Material(textureFile, ka, kd, ks);
        this->mat->usaTextura = true;
    }
    else {
		this->mat = new Material("", ka, kd, ks);
		this->mat->usaTextura = false;
    }
    

}

Object3D::~Object3D()
{
    if (!sharedProgram) delete prg;
    delete mat;
    delete coll;
}

void Object3D::move(double timeStep)
{
	cout << "Object3D::move() should be overridden in derived classes!" << endl;
}
