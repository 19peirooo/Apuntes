#pragma once
#include "Object3D.h"

class Diana : public Object3D 
{
	
	public:
	
		Diana(const char* fileName) : Object3D(fileName) {
			this->objType = dianaType;
		};
		void move(double timeStep) override;
};

