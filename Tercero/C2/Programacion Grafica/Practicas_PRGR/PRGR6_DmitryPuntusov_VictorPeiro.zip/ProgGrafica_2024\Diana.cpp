#include "Diana.h"

void Diana::move(double timeStep){}
