#pragma once
#include "vector4f.h"
#include "Texture.h"

class Material
{
	public:

		float ka = 1, kd = 1, ks = 1;
		bool usaTextura = false;
		Vector4f color = { 1,1,1,1 };
		Texture* texture = nullptr;
		float alpha = 1.0f;
		int shiny = 50;

		Material(string textureName, float ka, float kd, float ks);
};

