#pragma once
#include "common.h"

typedef struct {
	unsigned char r;
	unsigned char g;
	unsigned char b;
	unsigned char a;
}pixel_t;

class Texture
{

	public:
		string textureName;
		unsigned int textureId;
		int width, height;
		vector<pixel_t> rawImage;
		
		Texture(string fileName);

		void updateTexture();

};

