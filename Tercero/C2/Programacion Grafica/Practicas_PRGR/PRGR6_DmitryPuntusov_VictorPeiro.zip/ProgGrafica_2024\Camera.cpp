#include "Camera.h"
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

Camera::Camera(Vector4f pos, Vector4f rot, Vector4f lookAt, Vector4f Up, float fovy, float aspectRatio, float zNear, float Zfar)
{
	this->pos = pos;
	this->rot = rot;
	this->Up = Up;
	this->fovy = fovy * (float)M_PI / 180.0f;
	this->aspectRatio = aspectRatio;
	this->zNear = zNear;
	this->Zfar = Zfar;
	this->lookAt = lookAt;
	this->lookAtPrime = lookAt - pos;
	this->lookAtPrime.w = 1.0f;
	this->forward = normalize(lookAt - pos);
	this->right = normalize(this->forward ^ this->Up);

	// Tareas 1 y 2: Inicializar el colisionador de la camara
	this->collTree = new ColliderTree<Sphere>(new colliderNode());
	this->collTree->root->bv = new Sphere();
	this->collTree->root->sons[0] = this->collTree->root->sons[1] = nullptr;

	// Añadir una particula para definir el tamaño (radio)
	particle3D* p = new particle3D();
	p->pos = make_vector4f(0, -2.2835f, 0, 1);
	p->size = make_vector4f(0.25f, 0.25f, 0.25f, 0);
	this->collTree->root->bv->addParticle(p);

	// Sincronizar posicion inicial
	this->collTree->updateTree(this->collTree->root, make_traslate(this->pos.x, this->pos.y, this->pos.z));
}

Matrix4x4f Camera::getMatrixLookAt()
{
	Matrix4x4f view = make_identityf();
	// El forward se mantiene actualizado en move(), pero lo normalizamos por seguridad
	this->forward = normalize(lookAt - pos);

	this->right = normalize(this->forward ^ this->Up);
	Vector4f upCamera = normalize(right ^ forward);	// normal plano horizontal a la camera
	Vector4f position = make_vector4f(-1 * (right * this->pos), -(upCamera * this->pos), forward * this->pos, 1);

	view.t[0] = right;
	view.t[1] = upCamera;
	view.t[2] = forward * -1.0f;
	view.t[3] = { 0, 0, 0, 1 };
	view.matriz[0][3] = position.x;
	view.matriz[1][3] = position.y;
	view.matriz[2][3] = position.z;
	return view;
}

Matrix4x4f Camera::getMatrixperspective()
{
	Matrix4x4f projMatrix = make_identityf();
	projMatrix.matriz[0][0] = 1.0f / (aspectRatio * tan(fovy * 0.5f));
	projMatrix.matriz[1][1] = 1.0f / tan(fovy * 0.5f);
	projMatrix.matriz[2][2] = -(Zfar + zNear) / (Zfar - zNear);
	projMatrix.matriz[2][3] = 2.0f * Zfar * zNear / (Zfar - zNear);
	projMatrix.matriz[3][2] = -1.0f;


	return projMatrix;
}

void Camera::move(double timeStep)
{
	// This method should be overridden by specialized camera types (like CamaraFPS).
	// No default implementation to avoid logic conflicts.
}

void Camera::updateLookAt()
{
	Matrix4x4f rotMatrix = make_rotateX(rot.x) * make_rotateY(rot.y);
	this->lookAt = rotMatrix * this->lookAtPrime;

	Matrix4x4f trasM = make_traslate(this->pos.x, this->pos.y, this->pos.z);
	this->lookAt = trasM * this->lookAt;
	this->lookAt.w = 1.0f;
}
