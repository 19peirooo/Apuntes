#pragma once
#include "Matrix4x4f.h"
#include "InputManager.h"
#include "Collider.h"
#include "ColliderTree.h"

class Camera
{

	public:

		Vector4f pos, rot;
		Vector4f lookAt, Up;
		Vector4f lookAtPrime;
		Vector4f forward, right;

		float fovy, aspectRatio, zNear, Zfar;
		float velY = 0;
		bool isGrounded = false;

		ColliderTree<Sphere>* collTree;

		Camera(Vector4f pos, Vector4f rot, Vector4f lookAt, Vector4f Up, float fovy, float aspectRatio, float zNear, float Zfar);

		Matrix4x4f getMatrixLookAt(); //Matriz Vista

		Matrix4x4f getMatrixperspective(); //Matriz Perspectiva

		virtual void move(double timeStep);

		void updateLookAt();


};

