#include "Render.h"
#include "dataType.h"

Render::Render(int w, int h)
{
	this->width = w;
	this->height = h;
	initGL();
}

void Render::putCamera(Camera* cam)
{
	this->cam = cam;
}

void Render::putLight(Light* luz)
{
	this->luz = luz;
}

void Render::initGL() {

	//Inicializar GLFW
	if (glfwInit() != GLFW_TRUE) {
		cout << "ERROR: No se pudo inicializar GLFW" << endl;
	}
	else {
		//Creamos ventana para contexto

		this->window = glfwCreateWindow(this->width, this->height, "Practicas PRGR 2026", nullptr, nullptr);

		//Informacion de OpenGL para la ventana
		glfwMakeContextCurrent(window);
		glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
		gladLoadGL(glfwGetProcAddress); //Obtiene y carga todas la funciones de OpenGL

		glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

		glEnable(GL_DEPTH_TEST);
		glEnable(GL_BLEND); 
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); 
		
		//Inicializar Eventos de Teclado
		InputManager::init(this->window);

	}

}

void Render::putObject(Object3D* obj) {
	//buffer objects
	bufferObject_t bo = { -1,-1,-1 };
	glGenVertexArrays(1, &bo.bufferId); //Generar lista de buffers
	glGenBuffers(1, &bo.vertexBufferId); //Generar buffer de vertices
	glGenBuffers(1, &bo.indexBufferId); //Generar buffer de indices

	//copiar datos a gpu
	glBindVertexArray(bo.bufferId); //activar lista de buffer
	glBindBuffer(GL_ARRAY_BUFFER, bo.vertexBufferId); //activar buffer de vertices
	glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex) * obj->vertexList.size(), obj->vertexList.data(), GL_STATIC_DRAW); //copiar datos a buffer
	//STATIC_DRAW --> Los datos se cargan en memoria de video

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bo.indexBufferId); //activar buffer de indices
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * obj->idList.size(), obj->idList.data(), GL_STATIC_DRAW); //copiar datos a buffer

	//guardar identificadores
	bufferObjectsList[obj->objId] = bo;
	nextObjectList.push_back(obj);

}


void Render::removeObject(Object3D* obj) {
	if (bufferObjectsList.count(obj->objId)) {
		bufferObject_t bo = bufferObjectsList[obj->objId];
		glDeleteVertexArrays(1, &bo.bufferId);
		glDeleteBuffers(1, &bo.vertexBufferId);
		glDeleteBuffers(1, &bo.indexBufferId);
		bufferObjectsList.erase(obj->objId);
	}
	objectList.erase(std::remove(objectList.begin(), objectList.end(), obj), objectList.end());
	nextObjectList.erase(std::remove(nextObjectList.begin(), nextObjectList.end(), obj), nextObjectList.end());
}

void Render::drawGL() {
	//Por cada objeto
	for (auto& obj : objectList) {
		if (!obj->active) continue; // Skip inactive objects (like pooled bullets)

		//setear buffers
		auto bo = bufferObjectsList[obj->objId];
		glBindVertexArray(bo.bufferId); //Activa el VBO
		glBindBuffer(GL_ARRAY_BUFFER, bo.vertexBufferId); //activar buffer de vertices
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bo.indexBufferId); //activar buffer de indices

		obj->updateModelMatrix();

		obj->prg->use();

		//setear matrix modelo
		Matrix4x4f mvp = transpose(cam->getMatrixperspective() * cam->getMatrixLookAt() * obj->modelMatrix);
		obj->prg->setUniformData(type_mat4,&mvp,obj->prg->mvpName);
		obj->prg->setUniformData(type_mat4, &obj->modelMatrix, obj->prg->mName);
		obj->prg->setUniformData(type_camera,this->cam, obj->prg->cameraName);

		Light* currentLight = tempLuz && tempLuz->active ? tempLuz : luz;
		obj->prg->setUniformData(type_luz,currentLight, obj->prg->lightName);
		obj->prg->setUniformData(type_material,obj->mat, obj->prg->materialName);
		// describir datos
		obj->prg->setAttributeData(obj->prg->vertexPosName, 4, GL_FLOAT,GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, position));
		obj->prg->setAttributeData(obj->prg->vertexColorName, 4, GL_FLOAT,GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, color));
		obj->prg->setAttributeData(obj->prg->vertexNormalName, 4, GL_FLOAT,GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, normal));
		obj->prg->setAttributeData(obj->prg->vertexTextureCoordsName, 4, GL_FLOAT,GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, textureCoords)); 

		//dibujar
		glDrawElements(GL_TRIANGLES, obj->idList.size(), GL_UNSIGNED_INT, nullptr);
	}
}

void Render::mainLoop() {
	double lastTime = 0;
	double newTime = (glfwGetTime());
	double deltaTime = newTime - lastTime;

	while (!salir) {

		// poll de eventos
		InputManager::updateEvents();

		newTime = (glfwGetTime());
		deltaTime = newTime - lastTime;
		lastTime = newTime;

		// Evitar picos de deltaTime (max 10 FPS equivalent) para estabilidad
		if (deltaTime > 0.1) deltaTime = 0.1;

		// hacer cosas
		if (InputManager::keysState[GLFW_KEY_ESCAPE] || glfwWindowShouldClose(window)) {
			salir = true;
		}

		updateObjects(deltaTime);

		// limpiar buffers
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// colores y profundidad
		// dibujar
		drawGL();
		// intercambiar buffer
		glfwSwapBuffers(window);
	}

	glfwTerminate(); // �ltima funci�n, libera memoria GLFW
}

void Render::updateObjects(double deltaTime) {
	Vector4f oldPos = cam->pos;
	cam->move(deltaTime);
	luz->moveObject(deltaTime);
	if (tempLuz) tempLuz->moveObject(deltaTime);

	for (auto& obj : objectList)
	{
		obj->move(deltaTime);//actualizo posiciones
		obj->updateModelMatrix(); // Asegurar que la matriz modelo esté al día (ej. para objetos estáticos que no se mueven)
		//actualizo collider
		obj->coll->updateTree(obj->coll->root, obj->modelMatrix);
	}

	cam->isGrounded = false; // Resetear estado grounded antes de la detección de colisiones del frame actual

	// Detección de colisiones para la cámara
	for (auto& obj : objectList) {
		if (ColliderTree<Sphere>::collisionTest(cam->collTree->root, obj->coll->root)) {
			
			bool isFloor = false;
			// Si colisionamos con algo desde arriba, podría ser el suelo
			if (obj->objType == backgroundType) {
				// Heurística: es suelo si estamos por encima de su centro 
				// Y nos movemos hacia abajo o estamos quietos en Y
				if (cam->pos.y > (obj->position.y + 0.1f) && cam->velY <= 0) {
					isFloor = true;
				}
			}

			if (isFloor) {
				cam->isGrounded = true;
				cam->velY = 0;
				
				// SNAP: Ajustar la posición Y de la cámara exactamente sobre el suelo
				if (obj->coll->root->bv->type == collider_box) {
					BoxCollider* floor = (BoxCollider*)obj->coll->root->bv;
					Sphere* camSphere = (Sphere*)cam->collTree->root->bv;
					cam->pos.y = floor->boxMax.y - camSphere->centerPrime.y + camSphere->radius;
				}
			}
			
			// Revertir posición si es un obstáculo (pared o diana) o si no es el suelo
			if (!isFloor) {
				cam->pos = oldPos;
			}
			
			// Actualizamos el collider de la cámara para reflejar cualquier cambio/reversión
			cam->collTree->updateTree(cam->collTree->root, make_traslate(cam->pos.x, cam->pos.y, cam->pos.z));
			
			// Si ya estamos bloqueados por una pared o apoyados en el suelo, salimos del bucle
			if (!isFloor) break; 
		}
	}

	// Sincronización final: Después de todas las correcciones de colisión, 
	// actualizamos el LookAt para evitar el temblor de cámara.
	cam->updateLookAt();

	// Detección de colisiones para proyectiles vs dianas (cubos)
	for (auto& bullet : objectList) {
		if (bullet->active && bullet->objType == projectileType) {
			for (auto& target : objectList) {
				if (target->active && target->objType == dianaType) {
					if (ColliderTree<Sphere>::collisionTest(bullet->coll->root, target->coll->root)) {
						bullet->active = false;
						target->active = false;
						std::cout << "Target Destroyed!" << std::endl;
						tempLuz = new Light(
							make_vector4f(0, 1, 0, 0),
							target->position,
							make_vector4f(1, 0.6, 0.2, 1), // Color de explosion (naranja/amarillo)
							1.0f, 1.0f, 1.0f
						);

						tempLuz->lifeTime = 3.0f;
						break; // Bullet is spent
					}
				}
			}
		}
	}

	// Desactiva la luz temporal si ha expirado
	if (tempLuz) {
		if (!tempLuz->active) {
			delete tempLuz;
			tempLuz = nullptr;
		}
	}

	//eliminar objetos desactivados
	map<float, vector<Object3D*>> aux;
	vector<Object3D*> toDelete;
	for (auto& obj : objectList)
	{
		if (obj->active)
		{
			float dist = 0;
			dist = distance(cam->pos, obj->position);
			aux[dist].push_back(obj);

		}
		else {
			// SOLO borrar si NO es un proyectil (o si queremos manejar proyectiles fuera del pool)
			// En nuestro caso, los proyectiles viven en el bulletPool y no deben borrarse.
			if (obj->objType != projectileType) {
				toDelete.push_back(obj);
			}
			else {
				// Si es un proyectil del pool, lo mantenemos en la lista pero inactivo
				// (se saltará en el drawGL y update de posición)
				float dist = 0;
				dist = distance(cam->pos, obj->position);
				aux[dist].push_back(obj);
			}
		}
	}
	//añadir objetos nuevos a lista activa
	for (auto& obj : nextObjectList)
	{
		float dist = 0;
		dist = distance(cam->pos, obj->position);
		aux[dist].push_back(obj);
	}

	// Limpiar objetos desactivados antes de reconstruir la lista
	for (auto& obj : toDelete) {
		removeObject(obj);
		delete obj;
	}

	//intercambiar listas
	objectList.clear();
	for (auto l = aux.rbegin(); l != aux.rend(); ++l)
	{
		for (auto& obj : l->second) {
			objectList.push_back(obj);
		}
	}
	nextObjectList.clear();

}

vector<Object3D*> Render::getCollisions(Object3D* obj, int objType)
{
	vector<Object3D*> res;

	for (auto& o : objectList)
	{
		//si no es el mismo, es tipo correcto y colisionan
		if (obj != o && o->objType == objType &&
			ColliderTree<Sphere>::collisionTest(o->coll->root, obj->coll->root))

			res.push_back(o);
	}

	return res;
}

void Render::deleteObject(Object3D* obj)
{
	removeObject(obj);

	delete obj;
}
