#include "Material.h"

Material::Material(string textureName, float ka, float kd, float ks)
{
	this->texture = new Texture(textureName);
	this->ka = ka;
	this->kd = kd;
	this->ks = ks;
}