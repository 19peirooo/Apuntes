#include "Program.h"

Program::Program()
{
	this->idProgram = glCreateProgram();
}

void Program::addShader(string fileName)
{
	Shader* shader = new Shader(fileName);
	this->shaderList.push_back(shader);
}

void Program::linkProgram()
{
	bool anyShader = false;
	for (auto shader : this->shaderList) {
		if (shader->compiled) {
			glAttachShader(this->idProgram, shader->idShader);
			anyShader = true;
		}
	}

	if (!anyShader) {
		std::cerr << "WARNING: No compiled shaders to link!" << std::endl;
	}

	glLinkProgram(this->idProgram);

	this->checkErrors();
	this->readVarList();
	this->clean();
}

void Program::checkErrors()
{
	GLint program_linked;
	glGetProgramiv(this->idProgram, GL_LINK_STATUS, &program_linked);
	if (program_linked != GL_TRUE)
	{
		GLsizei log_length = 0;
		GLchar message[1024];
		glGetProgramInfoLog(this->idProgram, 1024, &log_length, message);
		std::cout << "ERROR Linking Program\n" << message << "\n\n";
	}
	else {
		this->linked = true;
	}
}

void Program::clean()
{
	for (auto& shader : this->shaderList) {
		if (shader->compiled) {
			glDetachShader(this->idProgram, shader->idShader);
		}
		shader->clean();
		delete shader;
	}
}

static std::string trim(const std::string& s) {
	size_t first = s.find_first_not_of(" \n\r\t");
	if (first == std::string::npos) return "";
	size_t last = s.find_last_not_of(" \n\r\t");
	return s.substr(first, (last - first + 1));
}

void Program::readVarList()
{
	int numAttributes = 0;
	int numUniforms = 0;
	glGetProgramiv(this->idProgram, GL_ACTIVE_ATTRIBUTES, &numAttributes);
	for (int i = 0; i < numAttributes; i++)
	{
		char varName[128];
		int bufSize = 128, length = 0, size = 0;
		GLenum type = -1;
		glGetActiveAttrib(this->idProgram, (GLuint)i, bufSize, &length, &size, &type, varName);
		std::string sVarName = trim(std::string(varName));
		if (!sVarName.empty()) {
			varList[sVarName] = glGetAttribLocation(this->idProgram, sVarName.c_str());
			std::cout << "Attribute found: " << sVarName << " at location " << varList[sVarName] << std::endl;
		}
	}
	glGetProgramiv(this->idProgram, GL_ACTIVE_UNIFORMS, &numUniforms);
	for (int i = 0; i < numUniforms; i++)
	{
		char varName[128];
		int bufSize = 128, length = 0, size = 0;
		GLenum type = -1;
		glGetActiveUniform(this->idProgram, (GLuint)i, bufSize, &length, &size, &type, varName);
		std::string sVarName = trim(std::string(varName));
		if (!sVarName.empty()) {
			if (sVarName.back() == ']') {//si es de tipo array
				std::string arrName = sVarName.substr(0, sVarName.find('['));
				for (int j = 0; j < size; j++) //coneguir la lista completa de nombres
				{
					std::string arrNameIdx = arrName + "[" + std::to_string(j) + "]";
					varList[arrNameIdx] = glGetUniformLocation(this->idProgram, arrNameIdx.c_str());
					std::cout << "Uniform found: " << arrNameIdx << " at location " << varList[arrNameIdx] << std::endl;
				}
			}
			else {
				varList[sVarName] = glGetUniformLocation(this->idProgram, sVarName.c_str());
				std::cout << "Uniform found: " << sVarName << " at location " << varList[sVarName] << std::endl;
			}
		}
	}
}

void Program::use()
{
	glUseProgram(this->idProgram);
}

void Program::setUniformData(dataType_e tipo, void* dato, string nombre)
{
	if (nombre.empty()) return;

	switch (tipo) {
		case type_mat4: {
			auto var = this->varList.find(nombre);
			if (var != this->varList.end()) {
				Matrix4x4f* m = (Matrix4x4f*)dato;
				glUniformMatrix4fv(var->second, 1, GL_FALSE, (float*)m);
			}
			else {
				cout << "Variable mat4 (" << nombre << ") no encontrada" << endl;
			}
		}break;

		case type_luz: {
			if (this->findLight(nombre))
			{
				Light* luz = (Light*)dato;
				glUniform4f(varList[nombre + ".dir"], luz->direction.x, luz->direction.y, luz->direction.z, luz->direction.w);
				glUniform4f(varList[nombre + ".pos"], luz->position.x, luz->position.y, luz->position.z, luz->position.w);
				glUniform4f(varList[nombre + ".color"], luz->color.r, luz->color.g, luz->color.b, luz->color.a);
				glUniform1f(varList[nombre + ".Ia"], luz->Ia);
				glUniform1f(varList[nombre + ".Id"], luz->Id);
				glUniform1f(varList[nombre + ".Is"], luz->Is);
				glUniform1i(varList[nombre + ".activa"], luz->active ? 1 : 0);
			}
			else {
				cout << "Variable struct luz (" << nombre << ") no encontrada" << endl;
			}
		}break;

		case type_material: {
			
			if (this->findMaterial(nombre))
			{
				Material* mat = (Material*)dato;
				glUniform4f(varList[nombre + ".color"], mat->color.r, mat->color.g, mat->color.b, mat->color.a);
				glUniform1f(varList[nombre + ".ka"], mat->ka);
				glUniform1f(varList[nombre + ".kd"], mat->kd);
				glUniform1f(varList[nombre + ".ks"], mat->ks);
				glUniform1f(varList[nombre + ".alpha"], mat->alpha);
				glUniform1f(varList[nombre + ".usaTextura"], mat->usaTextura);
				glUniform1f(varList[nombre + ".shiny"], mat->shiny);

				if (mat->usaTextura) {
					glActiveTexture(GL_TEXTURE1);
					glBindTexture(GL_TEXTURE_2D, mat->texture->textureId);
				}
				glUniform1i(varList["colorTexture"], 1);
			}
			else {
				cout << "Variable struct material (" << nombre << ") no encontrada" << endl;
			}

		}break;

		case type_camera: {
			if (this->findCamera(nombre)) {
				Camera* cam = (Camera*)dato;
				glUniform4f(varList[nombre+".posicion"], cam->pos.x, cam->pos.y, cam->pos.z, cam->pos.w);
			}
			else {
				cout << "Variable struct camara (" << nombre << ") no encontrada" << endl;
			}
			
		}break;

		default: {
			cout << "Tipo " << tipo << " no habilitado" << endl;
		}break;
				
	}
}

void Program::setAttributeData(string nombre, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const GLvoid* pointer)
{
	if (nombre.empty()) return;
	auto var = this->varList.find(nombre); 
	if (var != this->varList.end()) { 
		//setear datos
		glEnableVertexAttribArray(var->second);
		glVertexAttribPointer(var->second, size, type, normalized, stride, pointer);
	}
	//sino
	else {
		//error
		cout << "Variable attribute " << nombre << " no encontrada" << endl;
	}
}


void Program::setDescription(string key, string val)
{
	key = trim(key);
	val = trim(val);

	if (key == "attributeVertexPos")
	{
		this->vertexPosName = val;
	}

	else if (key == "attributeVertexColor")
	{
		this->vertexColorName = val;
	}

	else if (key == "attributeVertexNormal")
	{
		this->vertexNormalName = val;
	}

	else if (key == "attributeVertexTextureCoords")
	{
		this->vertexTextureCoordsName = val;
	}

	else if (key == "uniformMVP")
	{
		this->mvpName = val;
	}

	else if (key == "uniformM") 
	{
		this->mName = val;
	}

	else if (key == "uniformCamera") 
	{
		this->cameraName = val;
	}

	else if (key == "uniformLight") 
	{
		this->lightName = val;
	}

	else if (key == "uniformMaterial") 
	{
		this->materialName = val;
	}
}

bool Program::findLight(string nombre)
{
	return this->varList.find(nombre+".pos") != this->varList.end();
}

bool Program::findCamera(string nombre)
{
	return this->varList.find(nombre + ".posicion") != this->varList.end();
}

bool Program::findMaterial(string nombre)
{
	return this->varList.find(nombre + ".color") != this->varList.end();
}
