#pragma once
#include "Camera.h"

class CamaraFPS : public Camera
{
public:
    CamaraFPS(Vector4f pos, Vector4f rot, Vector4f lookAt, Vector4f Up, float fovy, float aspectRatio, float zNear, float Zfar):
        Camera(pos, rot, lookAt, Up, fovy, aspectRatio, zNear, Zfar) {};
    void move(double timeStep);
};

