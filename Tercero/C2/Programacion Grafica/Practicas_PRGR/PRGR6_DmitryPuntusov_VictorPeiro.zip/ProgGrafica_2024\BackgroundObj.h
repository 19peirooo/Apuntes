#pragma once
#include "Object3D.h"

class BackgroundObj : public Object3D
{
	public:
		BackgroundObj(const char* fileName) : Object3D(fileName) {
			this->objType = backgroundType;
			// Cambiar el volumen envolvente a Caja (Box)
			delete this->coll->root->bv;
			this->coll->root->bv = new BoxCollider();
			
			// Recalcular el colisionador con la lógica de Box
			for (auto& v : vertexList) {
				particle3D* p = new particle3D();
				p->pos = v.position;
				p->size = make_vector4f(0, 0, 0, 0);
				this->coll->root->bv->addParticle(p);
			}
		}
		virtual void move(double timeStep) override {}
};


