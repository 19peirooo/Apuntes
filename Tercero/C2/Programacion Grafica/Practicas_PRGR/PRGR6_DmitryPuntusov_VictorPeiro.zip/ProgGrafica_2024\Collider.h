#pragma once
#include "vector4f.h"
#include "Matrix4x4f.h"
#include "common.h"

typedef struct
{
    Vector4f pos;
    Vector4f size;
}particle3D;

typedef enum {
    collider_sphere,
    collider_box
}colliderType_e;

class Collider
{
public:
    vector<particle3D*> particleList;
    Vector4f max = { -1000000,-1000000,-1000000,0 };
    Vector4f min = { 1000000,1000000,1000000,0 };
    colliderType_e type;

    Collider() {};
    virtual bool collisionTest(Collider* coll) = 0;
    virtual void addParticle(particle3D* particle) = 0;
    virtual void updateCollider(Matrix4x4f mat) = 0;
};


class Sphere :public Collider {
public:
    float radius = 0;
    Vector4f center = { 0,0,0,1 };
    Vector4f centerPrime = { 0,0,0,1 };

    Sphere() { type = collider_sphere; }
    virtual bool collisionTest(Collider* coll) override;
    virtual void addParticle(particle3D* particle) override;
    virtual void updateCollider(Matrix4x4f mat) override;

};

class BoxCollider : public Collider {
public:
    Vector4f boxMin; // Espacio mundo
    Vector4f boxMax; // Espacio mundo
    Vector4f boxMinPrime; // Espacio local
    Vector4f boxMaxPrime; // Espacio local

    BoxCollider() { type = collider_box; }
    virtual bool collisionTest(Collider* coll) override;
    virtual void addParticle(particle3D* particle) override;
    virtual void updateCollider(Matrix4x4f mat) override;
};


