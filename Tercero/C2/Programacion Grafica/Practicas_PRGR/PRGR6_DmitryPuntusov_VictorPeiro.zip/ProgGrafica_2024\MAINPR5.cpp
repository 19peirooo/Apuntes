//#define GLAD_BIN
//#include "common.h"
//#include "Render.h"
//#include "Esfera.h"
//#include "Cubo.h"
//#include <iostream>
//
//int main(int argc, char** argv)
//{
//	int w = 640;
//	int h = 480;
//
//	auto r = new Render(w, h);
//
//	// Esfera: posicion (0,0,0), tamanio ~1 unidad
//	auto esfera = new Esfera("data/sphere.frs");
//	esfera->position = make_vector4f(0, 0, 0, 1);
//	esfera->scale = make_vector4f(0.5f, 0.5f, 0.5f, 1);
//	esfera->updateModelMatrix();
//	// Hack: como la luz esta en el centro (0,0,0), el exterior de la esfera es oscuro.
//	// Aumentamos el coeficiente ambiental para que se vea brillante.
//	if (esfera->mat) esfera->mat->ka = 5.0f;
//
//	// Cubo texturado: hereda de Object3D, orbita alrededor del origen a 45/s
//	auto cubo = new Cubo("data/cubo.frs");
//	cubo->position = make_vector4f(3, 0, 0, 1);
//	cubo->scale = make_vector4f(0.5f, 0.5f, 0.5f, 1);    // escalar a ~1 unidad de lado
//	cubo->updateModelMatrix();
//
//	// Camara en (0,0,6) mirando a (0,0,0), 90 grados, zNear=0.01, zFar=100
//	Camera* cam = new Camera(
//		make_vector4f(0, 0, 6, 1),   // posicion
//		make_vector4f(0, 0, 0, 0),   // rotacion
//		make_vector4f(0, 0, 0, 1),   // lookAt
//		make_vector4f(0, 1, 0, 0),   // up
//		90.0f,                        // fovy
//		640.0f / 480.0f,             // aspectRatio
//		0.01f,                        // zNear
//		100.0f);                      // Zfar
//
//	// Luz blanca puntual en (0,0,0), activa por defecto
//	Light* luz = new Light(
//		make_vector4f(0, 0, -1, 0),   // direction (no usada para luz puntual pero requerida)
//		make_vector4f(0, 0, 0, 1),    // position
//		make_vector4f(1, 1, 1, 1),    // color blanco
//		0.2f,                          // ka (ambiental)
//		1.0f,                          // kd (difusa)
//		0.8f                           // ks (especular)
//	);
//	luz->active = true;  // activar la luz desde el inicio
//
//	r->putObject(esfera);
//	r->putObject(cubo);
//	r->putCamera(cam);
//	r->putLight(luz);
//
//	r->mainLoop();
//
//	return 0;
//}