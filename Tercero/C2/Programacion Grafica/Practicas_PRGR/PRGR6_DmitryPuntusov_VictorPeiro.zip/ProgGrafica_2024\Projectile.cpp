#include "Projectile.h"

Program* Projectile::sharedProgram = nullptr;

Projectile::Projectile(Vector4f startPos, Vector4f direction) 
	: Object3D("data/sphere.frs", (sharedProgram ? sharedProgram : (sharedProgram = new Program()))) {
	
	this->objType = projectileType;
	this->position = startPos;
	this->velocity = direction * speed;
	this->scale = make_vector4f(0.2f, 0.2f, 0.2f, 1.0f);
	
	if (this->mat) {
		this->mat->color = make_vector4f(0.5f, 0.5f, 0.5f, 1.0f); // Gris
		this->mat->usaTextura = false;
	}
}

void Projectile::move(double dt) {
	// Actualizar posición
	this->position = this->position + this->velocity * (float)dt;
	// Reducir tiempo de vida
	this->lifetime -= (float)dt;
	// Desactivar el proyectil si su tiempo de vida ha expirado
	if (this->lifetime <= 0.0f) {
		this->active = false;
	}
	updateModelMatrix();
}
