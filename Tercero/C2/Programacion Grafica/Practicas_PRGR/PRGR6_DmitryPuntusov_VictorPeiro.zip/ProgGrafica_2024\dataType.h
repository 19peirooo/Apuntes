#pragma once

typedef enum {
	type_mat4,
	type_luz,
	type_material,
	type_camera
}dataType_e;