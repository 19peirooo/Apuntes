#include "Cubo.h"
#include <cmath>

Cubo::Cubo(const char* fileName) : Object3D(fileName)
{
	this->objType = dianaType;
}

void Cubo::move(double timeStep)
{
	float orbitSpeed = 45.0f; // grados por segundo
	angleOrbit += orbitSpeed * timeStep;
	if (angleOrbit > 360.0f) angleOrbit -= 360.0f;

	float selfRotSpeed = 90.0f; // grados por segundo rotacion sobre si mismo
	rotation.v[1] += selfRotSpeed * timeStep;
	if (rotation.v[1] > 360.0f) rotation.v[1] -= 360.0f;
	
	float radians = angleOrbit * 3.14159265f / 180.0f;
	position.x = 3.0f * cos(radians);
	position.z = 3.0f * sin(radians);
	position.y = 0.0f;
	
	updateModelMatrix();
}
