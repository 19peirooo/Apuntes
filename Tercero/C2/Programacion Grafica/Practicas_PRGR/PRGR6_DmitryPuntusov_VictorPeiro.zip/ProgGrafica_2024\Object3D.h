#pragma once
#include "vector4f.h"
#include "Matrix4x4f.h"
#include "vertex.h"
#include "Program.h"
#include "Material.h"
#include "InputManager.h"
#include "Collider.h"
#include "ColliderTree.h"

#define skipComments()\
{\
    bool foundData = false;\
    while (!foundData && std::getline(f >> std::ws, line)) {\
        /* Skip UTF-8 BOM if present */\
        size_t start = 0;\
        if (line.size() >= 3 && (unsigned char)line[0] == 0xEF && (unsigned char)line[1] == 0xBB && (unsigned char)line[2] == 0xBF) start = 3;\
        if (line.empty()) continue;\
        if ((unsigned char)line[start] == 0xE2 || line[start] == '#') continue;\
        if (start > 0) line = line.substr(start);\
        if (!line.empty()) foundData = true;\
    }\
    lineReader = istringstream(line);\
}

#define readMultipleData()\
vector<float> data;\
{\
    float d = 0;\
    while (lineReader >> d)\
    {\
        data.push_back(d);\
    }\
}

typedef enum {
	objectType=0,
	backgroundType=1,
	dianaType = 2,
	projectileType = 3
}objTypes;

class Object3D
{

public:

	Program* prg = nullptr;
	Material* mat = nullptr;
	ColliderTree<Sphere>* coll = new ColliderTree<Sphere>(nullptr); 

	Vector4f position;
	Vector4f rotation;
	Vector4f scale;

	Matrix4x4f modelMatrix;
	
	static unsigned int contador;
	unsigned int objId;
	objTypes objType = objectType;

	bool active = true;
	bool sharedProgram = false;

	std::vector<Vertex> vertexList;
	// lista de vertices de objeto
	std::vector<int> idList;
	// lista con los indices que se usaran para dibujar
	// la lista de vertices

	Object3D(const char* fileName); //Constructor de la clase
	Object3D(const char* fileName, Program* prg); // Constructor con programa compartido
	~Object3D();

	virtual void move(double timeStep);
	// metodo virtual que actualiza la posi/rot/scale del objeto.
	// debera consultar el estado del teclado, y si se pulsa la tecla "D" aumenara
	// el angulo de giro en el eje Y.
	void updateModelMatrix();
	// actualiza la matriz modelo en base a los datos de posi/rot/scale del objeto.
	void loadFromFile(const char* fileName); //Carga una figura de un archivo .frs

};

