#pragma once
#include "Render.h"
#include "BackgroundObj.h"
#include "Diana.h"
#include "ProjectilePool.h"

class System
{
public:
    inline static Render* render = nullptr;
    inline static ProjectilePool* bulletPool = nullptr;
    
    static void init(int w, int h) {
        render = new Render(w, h);
        bulletPool = new ProjectilePool(50); // Pool for 50 bullets

        // Register pool objects into render
        for (auto p : bulletPool->getPool()) {
            render->putObject(p);
        }
    }
    
    static void generateBackground() {
		float size = 100.0f; // Total width/depth will be 200
		float height = 50.0f;

		auto suelo = new BackgroundObj("data/suelo.frs");
		suelo->position = make_vector4f(0, 0, 0, 1);
		suelo->scale = make_vector4f(size, 0.5f, size, 1);

		auto pared1 = new BackgroundObj("data/pared.frs");
		pared1->position = make_vector4f(0, height, size, 1);
		pared1->scale = make_vector4f(size, height, 0.5f, 1);

		auto pared2 = new BackgroundObj("data/pared.frs");
		pared2->position = make_vector4f(0, height, -size, 1);
		pared2->scale = make_vector4f(size, height, 0.5f, 1);

		auto pared3 = new BackgroundObj("data/pared.frs");
		pared3->position = make_vector4f(size, height, 0, 1);
		pared3->scale = make_vector4f(0.5f, height, size, 1);

		auto pared4 = new BackgroundObj("data/pared.frs");
		pared4->position = make_vector4f(-size, height, 0, 1);
		pared4->scale = make_vector4f(0.5f, height, size, 1);

		auto techo = new BackgroundObj("data/techo.frs");
		techo->position = make_vector4f(0, height * 2, 0, 1);
		techo->scale = make_vector4f(size, 0.5f, size, 1);

		render->putObject(suelo);
		render->putObject(pared1);
		render->putObject(pared2);
		render->putObject(pared3);
		render->putObject(pared4);
		render->putObject(techo);
    }

	static void generateTargets() {
		// Three cubes in a line at Z = 15
		for (int i = -1; i <= 1; i++) {
			auto target = new Diana("data/cubo.frs");
			target->objType = dianaType;
			target->position = make_vector4f(i * 5.0f, 2.0f, 15.0f, 1);
			target->updateModelMatrix();
			render->putObject(target);
		}
	}
};

