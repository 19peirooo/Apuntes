#pragma once
#include "common.h"
#include "Shader.h"
#include "Matrix4x4f.h"
#include "Light.h"
#include "Material.h"
#include "Camera.h"
#include "dataType.h"

class Program
{

	public:

		bool linked = false;
		unsigned int idProgram;
		vector<Shader*> shaderList;
		map<string, unsigned int> varList;

		string vertexPosName,vertexColorName,vertexNormalName,vertexTextureCoordsName, 
			mvpName, mName, cameraName, lightName, materialName;

		Program();

		void addShader(string fileName);

		void linkProgram();

		void checkErrors();

		void clean();

		void readVarList();

		void use();

		void setUniformData(dataType_e tipo, void* dato, string nombre);

		void setAttributeData(string nombre, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const GLvoid* pointer);

		void setDescription(string key, string val);

		bool findLight(string nombre);
		bool findCamera(string nombre);
		bool findMaterial(string nombre);
};

