#include "CamaraFPS.h"
#include "Projectile.h"
#include "System.h"

void CamaraFPS::move(double timeStep)
{
	float speed = 20.0f;
	float angularSpeed = 100.0f; 
	float angularSpeedY = InputManager::mouseState.accumMX * angularSpeed;
	float angularSpeedX = InputManager::mouseState.accumMY * angularSpeed;

	rot.y += angularSpeedY * (float)timeStep;
	rot.x -= angularSpeedX * (float)timeStep; // Cambiado a -= para corregir inversion

	// Limitar el cabeceo (pitch) para evitar que la cámara de la vuelta completa
	if (rot.x > 89.0f) rot.x = 89.0f;
	if (rot.x < -89.0f) rot.x = -89.0f;

	// Recalcular vectores directores basados en la nueva rotación
	float yawRad = rot.y * (float)M_PI / 180.0f;
	float pitchRad = rot.x * (float)M_PI / 180.0f;

	this->forward.x = sin(yawRad) * cos(pitchRad);
	this->forward.y = sin(-pitchRad);
	this->forward.z = cos(yawRad) * cos(pitchRad);
	this->forward.w = 0;
	this->forward = normalize(this->forward);

	this->right = normalize(this->forward ^ make_vector4f(0, 1, 0, 0));
	this->right.w = 0;


	// 3. Movimiento WASD usando el mapa de teclas
	if (InputManager::keysState[GLFW_KEY_W]) {
		this->pos = this->pos + this->forward * speed * (float)timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_S]) {
		this->pos = this->pos - this->forward * speed * (float)timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_D]) {
		this->pos = this->pos + this->right * speed * (float)timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_A]) {
		this->pos = this->pos - this->right * speed * (float)timeStep;
	}

	// 4. Gravedad y Salto
	float gravity = -30.0f;
	float jumpForce = 12.0f;

	if (InputManager::keysState[GLFW_KEY_SPACE] && isGrounded) {
		velY = jumpForce;
		isGrounded = false;
	}

	if (!isGrounded) {
		velY += gravity * (float)timeStep;
	}
	else {
		if (velY < 0) velY = 0;
	}

	this->pos.y += velY * (float)timeStep;

	// 5. Disparar
	if (InputManager::mouseState.buttonsState[GLFW_MOUSE_BUTTON_LEFT]) {
		static double lastFireTime = 0;
		double currentTime = glfwGetTime();
		if (currentTime - lastFireTime > 0.2) { 
			lastFireTime = currentTime;
			Vector4f projectileStartPos = this->pos + this->forward * 1.5f;
			System::bulletPool->getProjectile(projectileStartPos, this->forward);
		}
	}

	// 5. Sincronizar LookAt y Collider
	updateLookAt();

	this->collTree->updateTree(this->collTree->root, make_traslate(this->pos.x, this->pos.y, this->pos.z));

	// Limpiar deltas de entrada al FINAL del frame para asegurar que todo se consumió
	InputManager::resetDeltas();
}
