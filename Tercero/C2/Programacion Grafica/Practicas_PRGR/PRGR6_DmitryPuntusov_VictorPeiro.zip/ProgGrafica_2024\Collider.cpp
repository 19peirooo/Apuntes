#include "Collider.h"

bool Sphere::collisionTest(Collider* coll)
{
    if (coll->type == collider_sphere) {
        Sphere* other = (Sphere*)coll;
        return distance(this->center, other->center) < (this->radius + other->radius);
    }
    else if (coll->type == collider_box) {
        BoxCollider* box = (BoxCollider*)coll;
        // Lógica sugerida: Encontrar punto más cercano en AABB
        float closestX = std::fmaxf(box->boxMin.x, std::fminf(this->center.x, box->boxMax.x));
        float closestY = std::fmaxf(box->boxMin.y, std::fminf(this->center.y, box->boxMax.y));
        float closestZ = std::fmaxf(box->boxMin.z, std::fminf(this->center.z, box->boxMax.z));

        float dx = this->center.x - closestX;
        float dy = this->center.y - closestY;
        float dz = this->center.z - closestZ;

        float distSq = dx * dx + dy * dy + dz * dz;
        return distSq <= (this->radius * this->radius);
    }
    return false;
}

void Sphere::addParticle(particle3D* p)
{
    this->particleList.push_back(p);
    Vector4f newSize = { 0,0,0,0 };
    //calcular tamao con todas las partculas
    max.x = ((p->pos.x + p->size.x / 2) > max.x) ?
        (p->pos.x + p->size.x / 2) :
        max.x;
    max.y = ((p->pos.y + p->size.y / 2) > max.y) ?
        (p->pos.y + p->size.y / 2) :
        max.y;
    max.z = ((p->pos.z + p->size.z / 2) > max.z) ?
        (p->pos.z + p->size.z / 2) :
        max.z;

    min.x = ((p->pos.x - p->size.x / 2) < min.x) ?
        (p->pos.x - p->size.x / 2) :
        min.x;
    min.y = ((p->pos.y - p->size.y / 2) < min.y) ?
        (p->pos.y - p->size.y / 2) :
        min.y;
    min.z = ((p->pos.z - p->size.z / 2) < min.z) ?
        (p->pos.z - p->size.z / 2) :
        min.z;

    newSize = (max - min);
    float newRadious = length(newSize) / 2;
    Vector4f newCenter = min + (newSize / 2);

    newCenter.w = 1;
    radius = newRadious;
    center = centerPrime = newCenter;

}

void Sphere::updateCollider(Matrix4x4f mat)
{
    this->center = mat * centerPrime;
    auto newMax = mat * max;
    auto newMin = mat * min;
    radius = length(newMax - newMin) / 2;

}

bool BoxCollider::collisionTest(Collider* coll)
{
    if (coll->type == collider_box) {
        BoxCollider* other = (BoxCollider*)coll;
        return (this->boxMin.x <= other->boxMax.x && this->boxMax.x >= other->boxMin.x) &&
               (this->boxMin.y <= other->boxMax.y && this->boxMax.y >= other->boxMin.y) &&
               (this->boxMin.z <= other->boxMax.z && this->boxMax.z >= other->boxMin.z);
    }
    else if (coll->type == collider_sphere) {
        // Reutilizar lógica de Sphere
        return coll->collisionTest(this);
    }
    return false;
}

void BoxCollider::addParticle(particle3D* p)
{
    this->particleList.push_back(p);
    max.x = std::fmaxf(p->pos.x + p->size.x / 2, max.x);
    max.y = std::fmaxf(p->pos.y + p->size.y / 2, max.y);
    max.z = std::fmaxf(p->pos.z + p->size.z / 2, max.z);
    min.x = std::fminf(p->pos.x - p->size.x / 2, min.x);
    min.y = std::fminf(p->pos.y - p->size.y / 2, min.y);
    min.z = std::fminf(p->pos.z - p->size.z / 2, min.z);

    boxMinPrime = min;
    boxMinPrime.w = 1.0f;
    boxMaxPrime = max;
    boxMaxPrime.w = 1.0f;
    boxMin = min;
    boxMin.w = 1.0f;
    boxMax = max;
    boxMax.w = 1.0f;
}

void BoxCollider::updateCollider(Matrix4x4f mat)
{
    // Transformar los límites locales al espacio mundo
    this->boxMin = mat * boxMinPrime;
    this->boxMax = mat * boxMaxPrime;

    // Ajustar min/max para manejar escalas negativas
    Vector4f realMin = {
        std::fminf(boxMin.x, boxMax.x),
        std::fminf(boxMin.y, boxMax.y),
        std::fminf(boxMin.z, boxMax.z),
        1.0f
    };
    Vector4f realMax = {
        std::fmaxf(boxMin.x, boxMax.x),
        std::fmaxf(boxMin.y, boxMax.y),
        std::fmaxf(boxMin.z, boxMax.z),
        1.0f
    };
    boxMin = realMin;
    boxMax = realMax;
}


