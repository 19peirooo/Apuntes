#pragma once
#include "Object3D.h"

class Projectile : public Object3D {
public:
	static Program* sharedProgram;
	Vector4f velocity;
	float speed = 50.0f;
	float lifetime = 5.0f;

	Projectile(Vector4f startPos, Vector4f direction);
	void move(double dt) override;
};
