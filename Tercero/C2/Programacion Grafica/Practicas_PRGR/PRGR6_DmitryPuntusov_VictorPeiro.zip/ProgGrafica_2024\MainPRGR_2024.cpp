#define GLAD_BIN
#include "common.h"
#include "System.h"

#include "CamaraFPS.h"
#include <iostream>

int main(int argc, char** argv)
{
	int w = 1280;
	int h = 960;

	System::init(w, h);
	System::generateBackground();
	System::generateTargets();

	CamaraFPS* cam = new CamaraFPS(
		make_vector4f(0, 3, -40, 1),   // posicion
		make_vector4f(0, 0, 0, 0),   // rotacion
		make_vector4f(0, 3, 0, 1),   // lookAt
		make_vector4f(0, 1, 0, 0),   // up
		90.0f,                        // fovy
		1280.0f / 960.0f,             // aspectRatio
		0.01f,                        // zNear
		100.0f);                      // Zfar

	Light* luz = new Light(
		make_vector4f(0, 0, -1, 0),   // direction (no usada para luz puntual pero requerida)
		make_vector4f(0, 0, 0, 1),    // position
		make_vector4f(1, 1, 1, 1),    // color blanca
		1.0f,                          // ka (ambiental)
		0.0f,                          // kd (difusa)
		0.0f                           // ks (especular)
	);


	System::render->putCamera(cam);
	System::render->putLight(luz);

	System::render->mainLoop();

	return 0;
}