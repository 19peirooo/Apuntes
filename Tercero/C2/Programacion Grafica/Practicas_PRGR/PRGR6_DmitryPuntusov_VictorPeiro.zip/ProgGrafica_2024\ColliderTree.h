﻿#pragma once
#include "Collider.h"
#include "Matrix4x4f.h"

typedef struct colliderNode {
    Collider* bv; //volumen envolvente de este nivel
    struct colliderNode* sons[2]; //dos hijos 
}colliderNode;


template <class TypeCollider>
class ColliderTree
{
public:
    colliderNode* root;

    ColliderTree(colliderNode* root) :root(root) {};

    static bool collisionTest(colliderNode* coll, colliderNode* otherColl)
    {

        //si raiz de uno y raiz otro colisiona
        if (coll->bv->collisionTest(otherColl->bv)) {
            // 
            if (coll->sons[0] || coll->sons[1]
                || otherColl->sons[0] || otherColl->sons[1]) {//alguno tiene hijos
                bool colisionDetected = false;
                if (coll->sons[0] && otherColl->sons[0])//ambos son sub�rboles, hay hijos
                    for (int i = 0;i < 2;i++)
                    {
                        if (coll->sons[i])//si el hijo no es nulo
                        {
                            for (int j = 0;j < 2;j++)
                            {
                                if (otherColl->sons[j])
                                {
                                    colisionDetected |= collisionTest(coll->sons[i], otherColl->sons[j]);
                                }
                            }
                        }
                    }
                else if (!coll->sons[0])//el izquierdo no tiene hijos
                {
                    for (int j = 0;j < 2;j++)//
                    {
                        if (otherColl->sons[j])
                            colisionDetected |= collisionTest(coll, otherColl->sons[j]);
                    }
                }
                else //el derecho no tiene hijos
                {
                    for (int j = 0;j < 2;j++)//
                    {
                        if (coll->sons[j])
                            colisionDetected |= collisionTest(coll->sons[j], otherColl);
                    }
                }
                return colisionDetected;
            }
            else //ninguno tiene hijos, ambos son hojas
                return true;
        }
        else
            return false;
    }


    static void subdivide(colliderNode* node) {
        //crear dos hijos
        colliderNode* n1 = new colliderNode;
        colliderNode* n2 = new colliderNode;
        n1->bv = new TypeCollider(); //s�lo esferas
        n2->bv = new TypeCollider();

        //repartir particulas
        Vector4f center = ((TypeCollider*)node->bv)->center;
        //izquierda a hijo1, derecha a hijo2
        for (auto& p : node->bv->particleList) {//por cada particula
            //calcular centro particula
            Vector4f centerParticle = p->pos;

            if (p->size.x > p->size.y && p->size.x > p->size.z) //ejeX mas largo
            {
                if (p->pos.x < center.x) //falta calcular eje m�s largo
                    n1->bv->addParticle(p);
                else
                    n2->bv->addParticle(p);
            }
            else if (p->size.y > p->size.x && p->size.y > p->size.z) //ejeX mas largo
            {
                if (p->pos.y < center.y) //falta calcular eje m�s largo
                    n1->bv->addParticle(p);
                else
                    n2->bv->addParticle(p);
            }
            else //eje z m�s largo
            {
                if (p->pos.z < center.z) //falta calcular eje m�s largo
                    n1->bv->addParticle(p);
                else
                    n2->bv->addParticle(p);
            }
        }
        //si hijos distintos
        if (n1->bv->particleList.size() > 0 &&
            n2->bv->particleList.size() > 0)
        {
            node->sons[0] = n1;
            node->sons[1] = n2;
            //subdividir hijos
            subdivide(n1);
            subdivide(n2);

        }
        else { //acabar, limpiar memoria
            delete n1;
            delete n2;
            node->sons[0] = node->sons[1] = nullptr;
        }


    }

    static void updateTree(colliderNode* root, Matrix4x4f mat) {

        root->bv->updateCollider(mat);
        //si tiene hijos
        if (root->sons[0])
        {
            updateTree(root->sons[0], mat);
            updateTree(root->sons[1], mat);
        }

    }


};


