#pragma once
#include "Projectile.h"
#include <vector>

class ProjectilePool {
private:
    std::vector<Projectile*> pool;
    size_t poolSize;
    size_t nextAvailable = 0;

public:
    ProjectilePool(size_t size) : poolSize(size) {
        for (size_t i = 0; i < size; ++i) {
            // We create them but they start as active = false
            Projectile* p = new Projectile(make_vector4f(0,0,0,1), make_vector4f(0,0,1,0));
            p->active = false;
            pool.push_back(p);
        }
    }

    Projectile* getProjectile(Vector4f pos, Vector4f dir) {
        // Search for an inactive projectile
        for (size_t i = 0; i < poolSize; ++i) {
            size_t idx = (nextAvailable + i) % poolSize;
            if (!pool[idx]->active) {
                Projectile* p = pool[idx];
                p->position = pos;
                p->velocity = dir * p->speed;
                p->lifetime = 5.0f;
                p->active = true;
                p->updateModelMatrix();
                nextAvailable = (idx + 1) % poolSize;
                return p;
            }
        }
        return nullptr; // Pool exhausted
    }

    const std::vector<Projectile*>& getPool() const { return pool; }

    ~ProjectilePool() {
        for (auto p : pool) delete p;
    }
};
