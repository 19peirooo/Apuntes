#pragma once
#include "Object3D.h"

class Cubo : public Object3D
{
public:
	float angleOrbit = 0.0f;
	Cubo(const char* fileName);
	void move(double timeStep) override;
};
