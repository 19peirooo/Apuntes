#include "Object3D.h"
#include "InputManager.h"
#include "Matrix4x4f.h"


void Object3D::createTriangle() {
	// el centro esta en (0, 0, 0):
	// entonces los vertices:
	// (-0.5, -0.5, 0, 0), (0, 0.5, 0, 0), (0.5, -0.5, 0, 0)
	this->position = make_vector4f(0, 0, 0, 1);
	this->rotation = make_vector4f(0, 0, 0, 0);
	this->scale = make_vector4f(1, 1, 1, 0);
	
	updateModelMatrix();

	this->vertexList = {
		{-0.5, -0.5, 0, 1},
		{0, 0.5, 0, 1},
		{0.5, -0.5, 0, 1}
	};

	this->idList = {
		0,1,2
	};
}

void Object3D::move(double timeStep)
{
	float rotSpeed = 90.0f;
		if (InputManager::keysState[GLFW_KEY_A])
			rotation.v[1] -= rotSpeed * timeStep;
		else if (InputManager::keysState[GLFW_KEY_D])
			rotation.v[1] += rotSpeed * timeStep;

		updateModelMatrix();
} 

void Object3D::updateModelMatrix() {
	// M = T*R*S
	Matrix4x4f T = make_translate(position.x, position.y, position.z);
	Matrix4x4f R = make_rotate(rotation.x, rotation.y, rotation.z);
	Matrix4x4f S = make_scale(scale.x, scale.y, scale.z);

	modelMatrix = T * R * S;
}