#pragma once
#include <cmath>

typedef struct {
	union {
		struct {
			float x;
			float y;
			float z;
			float w;
		};
		float v[4];
	};

} Vector4f; //Defincion de un vector, se puede definir como 4 floats o como array de 4 elementos

Vector4f make_vector4f(float x, float y, float z, float w); //Creacion de vector con sus componentes
Vector4f normalize(Vector4f v); //Normalizacion de un vector
Vector4f operator+(Vector4f v1, Vector4f v2); //Suma de dos vectores
Vector4f operator-(Vector4f v1, Vector4f v2); //Resta de dos vectores
float operator*(Vector4f v1, Vector4f v2); //Producto escalar de dos vectores
Vector4f operator^(Vector4f v1, Vector4f v2); //Producto vectorial de dos vectores
Vector4f make_quaternion(float x, float y, float z, float angle);


