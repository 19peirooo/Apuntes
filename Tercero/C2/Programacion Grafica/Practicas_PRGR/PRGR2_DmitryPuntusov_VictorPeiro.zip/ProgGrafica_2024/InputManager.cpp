#include "InputManager.h"

std::map<int, bool> InputManager::keysState;

void InputManager::keyboardManager(GLFWwindow* window, int key, int scancode, int action, int mods) {

	switch (action) {
	case GLFW_PRESS: {
		keysState[key] = true;
	}break;
	case GLFW_RELEASE: {
		keysState[key] = false;
	}break;
	}

}

void InputManager::init(GLFWwindow* window) {

	glfwSetKeyCallback(window, keyboardManager);

}

void InputManager::updateEvents() {
	glfwPollEvents(); // Actualizar resto de eventos de ventana
}