#include "Render.h"

Render::Render(int w, int h)
{
	this->width = w;
	this->height = h;
	initGL();
}

void Render::initGL() {

	//Inicializar GLFW
	if (glfwInit() != GLFW_TRUE) {
		cout << "ERROR: No se pudo inicializar GLFW" << endl;
	}
	else {
		//Creamos ventana para contexto
		this->window = glfwCreateWindow(this->width, this->height, "Practicas PRGR 2026", nullptr, nullptr);

		//Informacion de OpenGL para la ventana
		glfwMakeContextCurrent(window);
		glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
		gladLoadGL(glfwGetProcAddress);

		//Inicializar Eventos de Teclado
		InputManager::init(this->window);

	}

}

void Render::putObject(Object3D* obj) {
	//buffer objects
	bufferObject_t bo = { -1,-1,-1 };
	glGenVertexArrays(1, &bo.bufferId); //Generar lista de buffers
	glGenBuffers(1, &bo.vertexBufferId); //Generar buffer de vertices
	glGenBuffers(1, &bo.indexBufferId); //Generar buffer de indices

	//copiar datos a gpu
	glBindVertexArray(bo.bufferId); //activar lista de buffer
	glBindBuffer(GL_ARRAY_BUFFER, bo.vertexBufferId); //activar buffer de vertices
	glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex) * obj->vertexList.size(), obj->vertexList.data(), GL_STATIC_DRAW); //copiar datos a buffer

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bo.indexBufferId); //activar buffer de indices
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * obj->idList.size(), obj->idList.data(), GL_STATIC_DRAW); //copiar datos a buffer

	//guardar identificadores
	bufferObjectsList[obj->objId] = bo;
	objectList.push_back(obj);

}


void Render::removeObject(Object3D* obj) {
	if (bufferObjectsList.count(obj->objId)) {
		bufferObject_t bo = bufferObjectsList[obj->objId];
		glDeleteVertexArrays(1, &bo.bufferId);
		glDeleteBuffers(1, &bo.vertexBufferId);
		glDeleteBuffers(1, &bo.indexBufferId);
		bufferObjectsList.erase(obj->objId);
	}
	objectList.erase(remove(objectList.begin(), objectList.end(), obj), objectList.end());
}

void Render::drawGL() {
	//Por cada objeto
	for (auto& obj : objectList) {
		//setear buffers
		auto bo = bufferObjectsList[obj->objId];
		glBindVertexArray(bo.bufferId);
		glBindBuffer(GL_ARRAY_BUFFER, bo.vertexBufferId); //activar buffer de vertices
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bo.indexBufferId); //activar buffer de indices

		obj->updateModelMatrix();

		//setear matrix modelo
		Matrix4x4f model = transpose(obj->modelMatrix);
		glPushMatrix(); //crear una matrix gpu
		glLoadIdentity(); //cargar identidad
		glMultMatrixf(model.m); //Aplica la transformaci�n

		// decribir datos
		glEnableClientState(GL_VERTEX_ARRAY);

		//descrbimos array de posiciones
		glVertexPointer(4, GL_FLOAT, sizeof(Vertex), (void*)offsetof(Vertex, position));

		//dibujar
		glDrawElements(GL_TRIANGLES, obj->idList.size(), GL_UNSIGNED_INT, nullptr);
		glPopMatrix();
		glDisableClientState(GL_VERTEX_ARRAY);
	}
}

void Render::mainLoop() {
	double lastTime = 0;
	double newTime = (glfwGetTime());
	double deltaTime = newTime - lastTime;

	while (!salir) {

		newTime = (glfwGetTime());
		deltaTime = newTime - lastTime;
		lastTime = newTime;

		// hacer cosas
		if (InputManager::keysState[GLFW_KEY_ESCAPE] || glfwWindowShouldClose(window)) {
			salir = true;
		}

		updateObjects(deltaTime);

		// limpiar buffers
		glClear(GL_COLOR_BUFFER_BIT);
		// dibujar
		drawGL();
		// intercambiar buffer
		glfwSwapBuffers(window);
		// poll de eventos
		InputManager::updateEvents();
	}

	glfwTerminate(); // �ltima funci�n, libera memoria GLFW
}

void Render::updateObjects(double deltaTime) {

	for (auto& obj : objectList) {
		obj->move(deltaTime);
	}

}