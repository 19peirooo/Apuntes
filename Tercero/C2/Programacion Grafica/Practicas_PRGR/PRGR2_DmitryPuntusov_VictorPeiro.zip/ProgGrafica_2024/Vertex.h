#pragma once
#include "vector4f.h"
#include "common.h"

typedef struct {
	Vector4f position;
} Vertex;
