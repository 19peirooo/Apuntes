#include "vector4f.h"

#ifndef PI
#define PI 3.14159265358979323846f
#endif

Vector4f make_vector4f(float x, float y, float z, float w) {
	Vector4f vec;
	vec.x = x;
	vec.y = y;
	vec.z = z;
	vec.w = w;
	return vec;
}

Vector4f normalize(Vector4f v) {

	float mod = std::sqrt((v.x * v.x) + (v.y * v.y) + (v.z * v.z));

	if (mod == 0) return v;

	return make_vector4f(v.x / mod, v.y / mod, v.z / mod, v.w);

}

Vector4f operator+(Vector4f v1, Vector4f v2) {
	return make_vector4f(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z, v1.w + v2.w);
}

Vector4f operator-(Vector4f v1, Vector4f v2) {
	return make_vector4f(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z, v1.w - v2.w);
}

float operator*(Vector4f v1, Vector4f v2) {
	return (v1.x * v2.x) + (v1.y * v2.y) + (v1.z * v2.z) + (v1.w * v2.w);
}

Vector4f operator^(Vector4f v1, Vector4f v2) {
	return make_vector4f((v1.y * v2.z) - (v1.z * v2.y), (v1.z * v2.x) - (v1.x * v2.z), (v1.x * v2.y) - (v1.y * v2.x), 0.0f);
}

Vector4f make_quaternion(float x, float y, float z, float angle)
{
	float angleRad = angle / 180.0f * PI;
	float halfAngle = angleRad / 2.0f;
	float sinHalf = sin(halfAngle);

	Vector4f q;
	q.x = x * sinHalf;
	q.y = y * sinHalf;
	q.z = z * sinHalf;
	q.w = cos(halfAngle);

	return q;
}
