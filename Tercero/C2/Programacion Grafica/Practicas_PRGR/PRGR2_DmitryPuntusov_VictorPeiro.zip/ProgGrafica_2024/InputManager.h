#pragma once
#include "common.h"

class InputManager
{
	public:
		static std::map<int, bool> keysState; //Guarda el estado del teclado para ver si las teclas estan pulsadas
		static void keyboardManager(GLFWwindow* window, int key, int scancode, int action, int mods); //Recibe eventos de teclados y actualiza el mapa de teclas
		static void init(GLFWwindow* window); //Recibe la ventana donde se generan los eventos usando keyboardManager
		static void updateEvents();
};

