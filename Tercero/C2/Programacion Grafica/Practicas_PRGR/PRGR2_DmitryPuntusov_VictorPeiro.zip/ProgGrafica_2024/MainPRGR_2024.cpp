#define GLAD_BIN
#include "common.h"
#include "Render.h"
#include "Object3D.h"
#include <iostream>

int main(int argc, char** argv)
{
	
	auto r = new Render(640,480);
	auto obj = new Object3D();
	obj->createTriangle();

	r->putObject(obj);
	r->mainLoop();

	return 0;
}