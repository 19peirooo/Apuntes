#include "Matrix4x4f.h"

Matrix4x4f make_identityf() {
	Matrix4x4f m = { 0 };
	m.m[0] = m.m[5] = m.m[10] = m.m[15] = 1.0f;
	return m;
}

Matrix4x4f make_traslate(float x, float y, float z) {
	Matrix4x4f m = make_identityf();
	m.m[3] = x;
	m.m[7] = y;
	m.m[11] = z;
	return m;
}

Matrix4x4f make_rotate(float angleX, float angleY, float angleZ) {
	Matrix4x4f m = make_identityf();

	Matrix4x4f rotX = make_rotateX(angleX);

	Matrix4x4f rotY = make_rotateY(angleY);

	Matrix4x4f rotZ = make_rotateZ(angleZ);

	m = rotZ * rotY * rotX;

	return m;
}

Matrix4x4f make_rotateX(float angleX)
{
	Matrix4x4f rotX = make_identityf();
	float angleX_rad = angleX * PI / 180.0f;

	float cosX = cos(angleX_rad);
	float sinX = sin(angleX_rad);

	rotX.m[5] = cosX;
	rotX.m[6] = -sinX;
	rotX.m[9] = sinX;
	rotX.m[10] = cosX;

	return rotX;
}

Matrix4x4f make_rotateY(float angleY)
{
	Matrix4x4f rotY = make_identityf();
	float angleY_rad = angleY * PI / 180.0f;

	float cosY = cos(angleY_rad);
	float sinY = sin(angleY_rad);

	rotY.m[0] = cosY;
	rotY.m[2] = sinY;
	rotY.m[8] = -sinY;
	rotY.m[10] = cosY;

	return rotY;
}

Matrix4x4f make_rotateZ(float angleZ)
{
	Matrix4x4f rotZ = make_identityf();
	float angleZ_rad = angleZ * PI / 180.0f;

	float cosZ = cos(angleZ_rad);
	float sinZ = sin(angleZ_rad);

	rotZ.m[0] = cosZ; 
	rotZ.m[1] = -sinZ; 
	rotZ.m[4] = sinZ; 
	rotZ.m[5] = cosZ; 

	return rotZ;
}

Matrix4x4f make_scale(float x, float y, float z) {
	Matrix4x4f m = make_identityf();
	m.m[0] = x;
	m.m[5] = y;
	m.m[10] = z;
	return m;
}

Matrix4x4f operator*(Matrix4x4f m1, Matrix4x4f m2) {
	Matrix4x4f res = { 0 };

	for (int i = 0; i < DIM_MATRIX; i++) {

		Vector4f row = m1.t[i];

		for (int j = 0; j < DIM_MATRIX; j++) {
			Vector4f col = getColumnVector(m2, j);
			res.t[i].v[j] = row * col;
		}

	}

	return res;
}

Vector4f operator*(Matrix4x4f m, Vector4f v) {
	return make_vector4f(m.t[0] * v, m.t[1] * v, m.t[2] * v, m.t[3] * v);
}

Matrix4x4f operator*(Matrix4x4f m, float f) {
	Matrix4x4f res = { 0 };
	for (int i = 0; i < DIM_MATRIX; i++) {
		for (int j = 0; j < DIM_MATRIX; j++) {
			res.t[i].v[j] = m.t[i].v[j] * f;
		}
	}
	return res;
}

Matrix4x4f operator+(Matrix4x4f m1, Matrix4x4f m2) {
	Matrix4x4f res = { 0 };
	for (int i = 0; i < DIM_MATRIX; i++) {
		res.t[i] = m1.t[i] + m2.t[i];
	}
	return res;
}

Matrix4x4f operator-(Matrix4x4f m1, Matrix4x4f m2) {
	Matrix4x4f res = { 0 };
	for (int i = 0; i < DIM_MATRIX; i++) {
		res.t[i] = m1.t[i] - m2.t[i];
	}
	return res;
}

Matrix4x4f transpose(Matrix4x4f m) {
	Matrix4x4f res = { 0 };
	for (int i = 0; i < DIM_MATRIX; i++) {
		Vector4f col = getColumnVector(m, i);
		res.t[i] = make_vector4f(col.x, col.y, col.z, col.w);
	}
	return res;
}

float determinant(Matrix4x4f m) {
	float det = 0.0f;
	for (int col = 0; col < 4; col++) {
		float sub[3][3];
		int subi = 0;
		for (int i = 1; i < 4; i++) {
			int subj = 0;
			for (int j = 0; j < 4; j++) {
				if (j == col) continue;
				sub[subi][subj] = m.t[i].v[j];
				subj++;
			}
			subi++;
		}
		float sign = (col % 2 == 0) ? 1.0f : -1.0f;
		det += sign * m.t[0].v[col] * det3x3(sub);
	}
	return det;
}

Matrix4x4f make_rotate(Vector4f q) {
	Matrix4x4f m;
	// Asumiendo que q est� normalizado (x*x + y*y + z*z + w*w = 1)

	float x = q.x; float y = q.y; float z = q.z; float w = q.w;

	// Fila 1 (�ndices 0, 1, 2, 3)
	m.m[0] = 1 - 2 * y * y - 2 * z * z;
	m.m[1] = 2 * x * y - 2 * w * z;
	m.m[2] = 2 * x * z + 2 * w * y;
	m.m[3] = 0;

	// Fila 2 (�ndices 4, 5, 6, 7)
	m.m[4] = 2 * x * y + 2 * w * z;
	m.m[5] = 1 - 2 * x * x - 2 * z * z;
	m.m[6] = 2 * y * z - 2 * w * x;
	m.m[7] = 0;

	// Fila 3 (�ndices 8, 9, 10, 11)
	m.m[8] = 2 * x * z - 2 * w * y;
	m.m[9] = 2 * y * z + 2 * w * x;
	m.m[10] = 1 - 2 * x * x - 2 * y * y;
	m.m[11] = 0;

	// Fila 4 (Identidad al final)
	m.m[12] = 0; m.m[13] = 0; m.m[14] = 0; m.m[15] = 1;

	return m;
}

Matrix4x4f adjoint(Matrix4x4f m) {
	Matrix4x4f res = { 0 };
	for (int i = 0; i < DIM_MATRIX; i++) {
		for (int j = 0; j < DIM_MATRIX; j++) {
			float sub[3][3];
			int subi = 0;
			for (int x = 0; x < DIM_MATRIX; x++) {
				if (x == i) continue;
				int subj = 0;
				for (int y = 0; y < DIM_MATRIX; y++) {
					if (y == j) continue;
					sub[subi][subj] = m.t[x].v[y];
					subj++;
				}
				subi++;
			}
			float sign = ((i + j) % 2 == 0) ? 1.0f : -1.0f;
			res.t[i].v[j] = sign * det3x3(sub);
		}
	}
	return res;
}

Matrix4x4f inverse(Matrix4x4f m) {
	float det = determinant(m);
	if (det == 0) return make_identityf(); // No es invertible, devuelve identidad
	Matrix4x4f adj = adjoint(m);
	Matrix4x4f transposed_adj = transpose(adj);
	return transposed_adj * (1.0f / det);
}

Vector4f getColumnVector(Matrix4x4f m, int num_col) {
	return make_vector4f(m.t[0].v[num_col], m.t[1].v[num_col], m.t[2].v[num_col], m.t[3].v[num_col]);
}

float det3x3(float m[3][3]) {
	return m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
		- m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
		+ m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
}