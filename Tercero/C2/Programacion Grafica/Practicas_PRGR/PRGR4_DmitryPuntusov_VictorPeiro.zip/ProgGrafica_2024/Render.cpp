#include "Render.h"
#include "dataType.h"

Render::Render(int w, int h)
{
	this->width = w;
	this->height = h;
	initGL();
}

void Render::putCamera(Camera* cam)
{
	this->cam = cam;
}

void Render::initGL() {

	//Inicializar GLFW
	if (glfwInit() != GLFW_TRUE) {
		cout << "ERROR: No se pudo inicializar GLFW" << endl;
	}
	else {
		//Creamos ventana para contexto

		this->window = glfwCreateWindow(this->width, this->height, "Practicas PRGR 2026", nullptr, nullptr);

		//Informacion de OpenGL para la ventana
		glfwMakeContextCurrent(window);
		glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
		gladLoadGL(glfwGetProcAddress); //Obtiene y carga todas la funciones de OpenGL
		glEnable(GL_DEPTH_TEST);	// Activar depth buffer para que vea las caras bien


		//Inicializar Eventos de Teclado
		InputManager::init(this->window);

	}

}

void Render::putObject(Object3D* obj) {
	//buffer objects
	bufferObject_t bo = { -1,-1,-1 };
	glGenVertexArrays(1, &bo.bufferId); //Generar lista de buffers
	glGenBuffers(1, &bo.vertexBufferId); //Generar buffer de vertices
	glGenBuffers(1, &bo.indexBufferId); //Generar buffer de indices

	//copiar datos a gpu
	glBindVertexArray(bo.bufferId); //activar lista de buffer
	glBindBuffer(GL_ARRAY_BUFFER, bo.vertexBufferId); //activar buffer de vertices
	glBufferData(GL_ARRAY_BUFFER, sizeof(Vertex) * obj->vertexList.size(), obj->vertexList.data(), GL_STATIC_DRAW); //copiar datos a buffer
	//STATIC_DRAW --> Los datos se cargan en memoria de video

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bo.indexBufferId); //activar buffer de indices
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * obj->idList.size(), obj->idList.data(), GL_STATIC_DRAW); //copiar datos a buffer

	//guardar identificadores
	bufferObjectsList[obj->objId] = bo;
	objectList.push_back(obj);

}


void Render::removeObject(Object3D* obj) {
	if (bufferObjectsList.count(obj->objId)) {
		bufferObject_t bo = bufferObjectsList[obj->objId];
		glDeleteVertexArrays(1, &bo.bufferId);
		glDeleteBuffers(1, &bo.vertexBufferId);
		glDeleteBuffers(1, &bo.indexBufferId);
		bufferObjectsList.erase(obj->objId);
	}
	objectList.erase(remove(objectList.begin(), objectList.end(), obj), objectList.end());
}

void Render::drawGL() {
	//Por cada objeto
	for (auto& obj : objectList) {
		//setear buffers
		auto bo = bufferObjectsList[obj->objId];
		glBindVertexArray(bo.bufferId); //Activa el VBO
		glBindBuffer(GL_ARRAY_BUFFER, bo.vertexBufferId); //activar buffer de vertices
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bo.indexBufferId); //activar buffer de indices

		obj->updateModelMatrix();

		obj->prg->use();

		//setear matrix modelo
		Matrix4x4f mvp = transpose(cam->getMatrixperspective() * cam->getMatrixLookAt() * obj->modelMatrix);
		obj->prg->setUniformData(type_mat4,&mvp,"MVP");
		// describir datos
		obj->prg->setAttributeData("vPos", 4, GL_FLOAT,GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, position));
		obj->prg->setAttributeData("vColor", 4, GL_FLOAT,GL_FALSE, sizeof(Vertex), (void*)offsetof(Vertex, color));

		//dibujar
		glDrawElements(GL_TRIANGLES, obj->idList.size(), GL_UNSIGNED_INT, nullptr);
	}
}

void Render::mainLoop() {
	double lastTime = 0;
	double newTime = (glfwGetTime());
	double deltaTime = newTime - lastTime;

	while (!salir) {

		newTime = (glfwGetTime());
		deltaTime = newTime - lastTime;
		lastTime = newTime;

		// hacer cosas
		if (InputManager::keysState[GLFW_KEY_ESCAPE] || glfwWindowShouldClose(window)) {
			salir = true;
		}

		updateObjects(deltaTime);

		// limpiar buffers
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// colores y profundidad
		// dibujar
		drawGL();
		// intercambiar buffer
		glfwSwapBuffers(window);
		// poll de eventos
		InputManager::updateEvents();
	}

	glfwTerminate(); // �ltima funci�n, libera memoria GLFW
}

void Render::updateObjects(double deltaTime) {
	//Para movimiento sin raton --> cambiar moveFPS a move
	cam->moveFPS(deltaTime);
	for (auto& obj : objectList) {
		obj->move(deltaTime);
	}

}