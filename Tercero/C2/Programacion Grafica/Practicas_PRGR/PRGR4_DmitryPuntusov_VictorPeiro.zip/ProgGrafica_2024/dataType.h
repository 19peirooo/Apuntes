#pragma once

typedef enum {
	type_mat4
}dataType_e;