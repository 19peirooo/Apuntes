#include "InputManager.h"

std::map<int, bool> InputManager::keysState;
mouse_t InputManager::mouseState;

//Funcion Callback
void InputManager::keyboardManager(GLFWwindow* window, int key, int scancode, int action, int mods) {

	switch (action) {
	case GLFW_PRESS: {
		keysState[key] = true;
	}break;
	case GLFW_RELEASE: {
		keysState[key] = false;
	}break;
	}

}

void InputManager::mousePosManager(GLFWwindow* window, double xpos, double ypos)
{
	InputManager::mouseState.velMX = InputManager::mouseState.posMX - xpos;
	InputManager::mouseState.velMY = InputManager::mouseState.posMY - ypos;

	if (fabs(InputManager::mouseState.velMX) > 320) InputManager::mouseState.velMX = 0;
	if (fabs(InputManager::mouseState.velMY) > 240) InputManager::mouseState.velMY = 0;
	
	InputManager::mouseState.posMX = xpos; 
	InputManager::mouseState.posMY = ypos; 
}

void InputManager::mouseButtonManager(GLFWwindow* window, int button, int action, int mods)
{
	switch (action) {
	case GLFW_PRESS: {
		InputManager::mouseState.buttonsState[button] = true;
	}break;
	case GLFW_RELEASE: {
		InputManager::mouseState.buttonsState[button] = false;
	}
	}
}

void InputManager::init(GLFWwindow* window) {

	glfwSetKeyCallback(window, keyboardManager); //Callback de teclado --> Cada vez que haya un evento de teclado se ejecuta la funcion callback
	glfwSetCursorPosCallback(window, mousePosManager); //Callback de movimiento de raton --> Cada vez que se mueva el raton ejecuta la funcion callback
	glfwSetMouseButtonCallback(window, mouseButtonManager); //Callback de pulsado de raton --> Cada vez que haya un evento de raton se ejecuta la funcion callback
	int w, h;
	glfwGetWindowSize(window, &w, &h);
	InputManager::mouseState.posMX = w / 2;
	InputManager::mouseState.posMY = h / 2;

	glfwSetCursorPos(window, w / 2, h / 2);
}

void InputManager::updateEvents() {
	glfwPollEvents(); // Actualizar resto de eventos de ventana
}