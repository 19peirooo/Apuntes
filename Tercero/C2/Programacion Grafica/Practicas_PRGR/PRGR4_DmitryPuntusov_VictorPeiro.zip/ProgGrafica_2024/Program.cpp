#include "Program.h"

Program::Program()
{
	this->idProgram = glCreateProgram();
}

void Program::addShader(string fileName)
{
	Shader* shader = new Shader(fileName);
	this->shaderList.push_back(shader);
}

void Program::linkProgram()
{
	for (auto shader : this->shaderList) {
		glAttachShader(this->idProgram, shader->idShader);
	}

	glLinkProgram(this->idProgram);

	this->checkErrors();
	this->readVarList();
	this->clean();
}

void Program::checkErrors()
{
	GLint program_linked;
	glGetProgramiv(this->idProgram, GL_LINK_STATUS, &program_linked);
	if (program_linked != GL_TRUE)
	{
		GLsizei log_length = 0;
		GLchar message[1024];
		glGetProgramInfoLog(this->idProgram, 1024, &log_length, message);
		std::cout << "ERROR \n" << message << "\n\n";
	}
	else {
		this->linked = true;
	}
}

void Program::clean()
{
	for (auto& shader : this->shaderList) {
		glDetachShader(this->idProgram, shader->idShader);
		shader->clean();
		delete shader;
	}
}

void Program::readVarList()
{
	int numAttributes = 0;
	int numUniforms = 0;
	glGetProgramiv(this->idProgram, GL_ACTIVE_ATTRIBUTES, &numAttributes);
	for (int i = 0; i < numAttributes; i++)
	{
		char varName[100];
		int bufSize = 100, length = 0, size = 0;
		GLenum type = -1;
		glGetActiveAttrib(this->idProgram, (GLuint)i, bufSize, &length, &size, &type, varName);
		varList[std::string(varName)] = glGetAttribLocation(this->idProgram, varName);
	}
	glGetProgramiv(this->idProgram, GL_ACTIVE_UNIFORMS, &numUniforms);
	for (int i = 0; i < numUniforms; i++)
	{
		string varName; varName.resize(100);
		int bufSize = 100, length = 0, size = 0;
		GLenum type = -1;
		glGetActiveUniform(this->idProgram, (GLuint)i, bufSize, &length, &size, &type, varName.data());
		varName = std::string(varName.c_str()); //interrogar con nombre
		if (varName[varName.length() - 1] == ']') {//si es de tipo array
			std::string arrName = varName.substr(0, varName.find('['));
			for (int i = 0; i < size; i++) //coneguir la lista completa de nombres
			{
				std::string arrNameIdx = arrName + "[" + std::to_string(i) + "]";
				varList[arrNameIdx] = glGetUniformLocation(this->idProgram, arrNameIdx.c_str());
			}
		}
		else
			varList[varName] = glGetUniformLocation(this->idProgram, varName.c_str());
	}
}

void Program::use()
{
	glUseProgram(this->idProgram);
}

void Program::setUniformData(dataType_e tipo, void* dato, string nombre)
{
	auto var = this->varList.find(nombre);

	if (var != this->varList.end()) {
		switch (tipo) {
			case type_mat4: {
				Matrix4x4f* m = (Matrix4x4f*)dato;
				glUniformMatrix4fv(var->second, 1, GL_FALSE, (float*)m);
			}break;

			default: {
				cout << "Tipo " << tipo << " no habilitado" << endl;
			}break;
				
		}
	}
	else {
		cout << "Variable " << nombre << " no encontrada" << endl;
	}
}

void Program::setAttributeData(string nombre, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const GLvoid* pointer)
{
	auto var = this->varList.find(nombre); 
	if (var != this->varList.end()) { 
		//setear datos
		glEnableVertexAttribArray(var->second);
		glVertexAttribPointer(var->second, size, type, normalized, stride, pointer);
	}
	//sino
	else {
		//error
		cout << "Variable " << nombre << " no encontrada" << endl;
	}
}
