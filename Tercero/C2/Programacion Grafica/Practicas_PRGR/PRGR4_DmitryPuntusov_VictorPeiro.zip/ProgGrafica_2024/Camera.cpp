#include "Camera.h"

Camera::Camera(Vector4f pos, Vector4f rot, Vector4f lookAt, Vector4f Up, float fovy, float aspectRatio, float zNear, float Zfar)
{
	this->pos = pos;
	this->rot = rot;
	this->lookAt = lookAt;
	this->Up = Up;
	this->fovy = fovy * PI / 180.0f;
	this->aspectRatio = aspectRatio;
	this->zNear = zNear;
	this->Zfar = Zfar;
	this->lookAtPrime = lookAt - pos;
	this->forward = normalize(lookAt - pos);
	this->right = normalize(this->forward ^ this->Up);
}

Matrix4x4f Camera::getMatrixLookAt()
{
	Matrix4x4f view = make_identityf();
	this->forward = normalize(lookAt - pos);

	this->right = normalize(this->forward ^ this->Up);
	Vector4f upCamera = normalize(right ^ forward);	// normal plano horizontal a la camera
	Vector4f position = make_vector4f(-1 * (right * this->pos), -(upCamera * this->pos), forward * this->pos, 1);

	view.t[0] = right;
	view.t[1] = upCamera;
	view.t[2] = forward * -1.0f;
	view.t[3] = { 0, 0, 0, 1 };
	view.matriz[0][3] = position.x;
	view.matriz[1][3] = position.y;
	view.matriz[2][3] = position.z;
	return view;
}

Matrix4x4f Camera::getMatrixperspective()
{
	Matrix4x4f projMatrix = make_identityf();
	projMatrix.matriz[0][0] = 1.0f / (aspectRatio * tan(fovy * 0.5f));
	projMatrix.matriz[1][1] = 1.0f / tan(fovy * 0.5f);
	projMatrix.matriz[2][2] = -(Zfar + zNear) / (Zfar - zNear);
	projMatrix.matriz[2][3] = 2.0f * Zfar * zNear / (Zfar - zNear);
	projMatrix.matriz[3][2] = -1.0f;


	return projMatrix;
}

void Camera::move(double timeStep)
{
	
	float speed = 2.0f;
	float angularSpeed = 50.0f;

	if (InputManager::keysState[GLFW_KEY_LEFT]) {
		this->pos.x -= speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_RIGHT]) {
		this->pos.x += speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_DOWN]) {
		this->pos.y -= speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_UP]) {
		this->pos.y += speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_F]) {
		this->rot.y -= angularSpeed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_H]) {
		this->rot.y += angularSpeed * timeStep;
	}
	
	Matrix4x4f rotMatrix = make_rotate(0, this->rot.y, 0);
	this->lookAt = rotMatrix * this->lookAtPrime;
	Matrix4x4f trasM = make_traslate(this->pos.x, this->pos.y, this->pos.z);
	this->lookAt = trasM * this->lookAt;
}

void Camera::moveFPS(double timeStep)
{
	float speed = 0.5f;
	float angularSpeed = 90.0f;
	float angularSpeedY = InputManager::mouseState.velMX * angularSpeed;
	float angularSpeedX = InputManager::mouseState.velMY * angularSpeed;

	if (InputManager::keysState[GLFW_KEY_UP]) {
		this->pos = pos + forward * speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_DOWN]) {
		this->pos = pos - forward * speed * timeStep;
	}
	if (InputManager::keysState[GLFW_KEY_RIGHT]) {
		this->pos = pos + right * speed * timeStep;
	}
	if ((InputManager::keysState[GLFW_KEY_LEFT])) {
		this->pos = pos - right * speed * timeStep;
	}

	rot.y += angularSpeedY * timeStep;
	rot.x += angularSpeedX * timeStep;

	Matrix4x4f rotMatrix = make_rotateY(rot.y) * make_rotateX(rot.x);
	this->lookAt = rotMatrix * this->lookAtPrime;

	Matrix4x4f trasM = make_traslate(this->pos.x, this->pos.y, this->pos.z);
	this->lookAt = trasM * this->lookAt;

	InputManager::mouseState.velMX = 0;
	InputManager::mouseState.velMY = 0;
}
