#pragma once
#include "common.h"
#include "Shader.h"
#include "Matrix4x4f.h"
#include "dataType.h"

class Program
{

	public:

		bool linked = false;
		unsigned int idProgram;
		vector<Shader*> shaderList;
		map<string, unsigned int> varList;

		Program();

		void addShader(string fileName);

		void linkProgram();

		void checkErrors();

		void clean();

		void readVarList();

		void use();

		void setUniformData(dataType_e tipo, void* dato, string nombre);

		void setAttributeData(string nombre, GLint size, GLenum type, GLboolean normalized, GLsizei stride, const GLvoid* pointer);
};

