#pragma once
#include <iostream>
#include "common.h"
class Shader
{

public:

	bool compiled = false;
	unsigned int idShader;	// id de OpenGL para este shader
	std::string fileName;	// fichero con codigo de shader
	GLenum type;			// GL_VERTEX_SHADER ó GL_FRAGMENT_SHADER
	std::string source;		// codigo de shader

	Shader(std::string fileName);	// recibe fileName, lo cargará y compilará llamando
									// al resto de métodos de clase

	void readSource();	// abre el fichero, lee y almacena el codigo dentro source
	
	void compileShader();

	void checkErrors();	// muestra si hay cualquier error tras compilar el shader

	void clean();		// libera datos de compilación y codigo de shader. 
						// Es invocado desde la clase "Program" una vez se han linkado 
						// los datos de shader
};

