#define GLAD_BIN
#include "common.h"
#include "Render.h"
#include "Object3D.h"
#include <iostream>

int main(int argc, char** argv)
{
	
	int w = 640;
	int h = 480;
	
	auto r = new Render(w,h);
	auto cubo = new Object3D();
	cubo->loadFromFile("data/cubo.frs");
	
	Camera* cam = new Camera(
		make_vector4f(0 ,0, 3, 1),  //posicion
		make_vector4f(0, 0, 0, 0),  //rotacion
		make_vector4f(0, 0, 0, 1),  //lookAt
		make_vector4f(0, 1, 0, 0),  //up
		90.0f,						//fovy
		640.0f/480.0f,				//aspectRatio
		0.01,						//zNear
		100.0f);					//Zfar

	r->putObject(cubo);
	r->putCamera(cam);

	r->mainLoop();

	return 0;
}