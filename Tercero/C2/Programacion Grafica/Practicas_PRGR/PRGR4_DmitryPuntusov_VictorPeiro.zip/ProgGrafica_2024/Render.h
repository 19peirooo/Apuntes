#pragma once

#include "Object3D.h"
#include "InputManager.h"
#include "Camera.h"

typedef struct {
	unsigned int bufferId;
	unsigned int vertexBufferId;
	unsigned int indexBufferId;
} bufferObject_t;

class Render
{
	private:

		int width, height;
		vector<Object3D*> objectList;
		map<unsigned int, bufferObject_t> bufferObjectsList;
		GLFWwindow* window = nullptr;
		Camera* cam;
		bool salir = false;

	public:

		Render(int w, int h);

		void putCamera(Camera* cam);

		void initGL();

		void putObject(Object3D* obj);

		void removeObject(Object3D* obj);

		void drawGL();

		void mainLoop();

		void updateObjects(double deltaTime);

};