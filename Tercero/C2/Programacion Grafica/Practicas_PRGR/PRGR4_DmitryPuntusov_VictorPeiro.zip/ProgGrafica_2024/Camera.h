#pragma once
#include "Matrix4x4f.h"
#include "InputManager.h"

class Camera
{

	public:

		Vector4f pos, rot;
		Vector4f lookAt, Up;
		Vector4f lookAtPrime;
		Vector4f forward, right;

		float fovy, aspectRatio, zNear, Zfar;

		Camera(Vector4f pos, Vector4f rot, Vector4f lookAt, Vector4f Up, float fovy, float aspectRatio, float zNear, float Zfar);

		Matrix4x4f getMatrixLookAt(); //Matriz Vista

		Matrix4x4f getMatrixperspective(); //Matriz Perspectiva

		void move(double timeStep);

		void moveFPS(double timeStep);


};

