#pragma once
#ifndef RENDER_H
#define RENDER_H

#include <vector>
#include <iostream>
class Render
{
private:
	int width, height;
	std::vector<std::vector<char>> buffer;

public:
	Render(int w, int h);

	int PutPixel(int x, int y);

	void resetBuffer();

	void Draw();
};

#endif