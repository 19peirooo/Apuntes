#include "Render.h"
#include "Matrix4x4f.h"


Render::Render(int w, int h)
{
	width = w;
	height = h;
	// redimensionar los vectores internos(row/height) y externos(col/width)
	buffer.resize(height, std::vector<char>(width, '0'));
} 


int Render::PutPixel(int x, int y) {
	// calcular offset
	int halfWidth = width / 2;
	int halfHeight = height / 2;
	// convertir x, y a los indices de array
	x = x + halfWidth;
	y = y + halfHeight;
	// verificar los limites
	if (x < 0 || x >= width || y < 0 || y >= height)
		return -1;
	// poner el pixel
	buffer[y][x] = '1';
	return 0;
}

void Render::resetBuffer()
{
	for (size_t col = 0; col < height; col++)
	{
		for (size_t row= 0; row < width; row++)
		{
			buffer[col][row] = '0';
		}
	}
}

void Render::Draw() {
	for (int col = height - 1; col >= 0; col--)
	{
		for (size_t row = 0; row < width; row++)
		{
			buffer[col][row] == '0' ? std::cout << "  " : std::cout << ". ";
		}
		std::cout << std::endl;
	}
}