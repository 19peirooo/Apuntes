﻿#include <iostream>
#include <iomanip>

#include "vector4f.h"
#include "Matrix4x4f.h"
#include "Render.h"
using namespace std;

/* ===================== UTILIDADES DE IMPRESION ===================== */

void printVector(const Vector4f& v) {
    cout << fixed << setprecision(3);
    cout << "(" << v.x << ", " << v.y << ", " << v.z << ", " << v.w << ")";
}

void printMatrix(const Matrix4x4f& M) {
    cout << fixed << setprecision(3);
    for (int i = 0; i < 4; i++) {
        cout << "| ";
        for (int j = 0; j < 4; j++) {
            cout << setw(7) << M.t[i].v[j] << " ";
        }
        cout << "|" << endl;
    }
}

void tests() {
    cout << "================ VECTOR4F TESTS ================\n";

    Vector4f v1 = make_vector4f(1, 2, 3, 1);
    Vector4f v2 = make_vector4f(4, -1, 2, 0);

    cout << "v1 = "; printVector(v1); cout << endl;
    cout << "v2 = "; printVector(v2); cout << endl;

    cout << "\nv1 + v2 = ";
    printVector(v1 + v2); cout << endl;

    cout << "v1 - v2 = ";
    printVector(v1 - v2); cout << endl;

    cout << "v1 � v2 = " << (v1 * v2) << endl;

    cout << "normalize(v1) = ";
    printVector(normalize(v1)); cout << endl;

    cout << "v1 x v2 = ";
    printVector(v1 ^ v2); cout << endl;

    /* ===================== MATRICES ===================== */

    cout << "\n================ MATRIX4X4F TESTS ================\n";

    Matrix4x4f I = make_identityf();
    cout << "\nMatriz identidad:\n";
    printMatrix(I);

    Matrix4x4f T = make_translate(3, 4, 5);
    cout << "\nMatriz traslacion (3,4,5):\n";
    printMatrix(T);

    Matrix4x4f S = make_scale(2, 2, 2);
    cout << "\nMatriz escalado (2,2,2):\n";
    printMatrix(S);

    Matrix4x4f R = make_rotate(180.0f, 0.0f, 0.0f);
    cout << "\nMatriz rotacion X (180.0�):\n";
    printMatrix(R);

    /* ===================== OPERACIONES ENTRE MATRICES ===================== */

    Matrix4x4f M = T * R * S;
    cout << "\nM = T * R * S:\n";
    printMatrix(M);

    cout << "\nTranspuesta de M:\n";
    printMatrix(transpose(M));

    cout << "\nM + I:\n";
    printMatrix(M + I);

    cout << "\nM - I:\n";
    printMatrix(M - I);

    cout << "\nM * 0.5:\n";
    printMatrix(M * 0.5f);

    /* ===================== MATRIZ * VECTOR ===================== */

    cout << "\n================ MATRIX * VECTOR =====================\n";

    Vector4f p = make_vector4f(1, 1, 1, 1);
    cout << "Punto original p = ";
    printVector(p); cout << endl;

    Vector4f p2 = M * p;
    cout << "p' = M * p = ";
    printVector(p2); cout << endl;

    cout << "\n==================== RENDER ARTÍSTICO =======================\n";

    // Creamos un lienzo un poco más grande para tener espacio, por ejemplo 11x11
    Render art(11, 11);
    art.resetBuffer();

    // Dibujamos un "Corazón" pixelado usando coordenadas relativas al centro (0,0)
    // Parte superior del corazón
    art.PutPixel(-1, 3); art.PutPixel(1, 3);
    art.PutPixel(-2, 2); art.PutPixel(-1, 2); art.PutPixel(0, 2); art.PutPixel(1, 2); art.PutPixel(2, 2);

    // Parte media
    art.PutPixel(-2, 1); art.PutPixel(-1, 1); art.PutPixel(0, 1); art.PutPixel(1, 1); art.PutPixel(2, 1);
    art.PutPixel(-2, 0); art.PutPixel(-1, 0); art.PutPixel(0, 0); art.PutPixel(1, 0); art.PutPixel(2, 0);

    // Parte inferior (punta)
    art.PutPixel(-1, -1); art.PutPixel(0, -1); art.PutPixel(1, -1);
    art.PutPixel(0, -2);

    // Mostramos el resultado por terminal
    cout << "Dibujando un corazon en el centro (0,0):" << endl;
    art.Draw();
   
}