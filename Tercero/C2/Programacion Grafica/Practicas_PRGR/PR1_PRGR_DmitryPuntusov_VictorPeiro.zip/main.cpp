#include <iostream>
#include <iomanip>

#include "vector4f.h"
#include "Matrix4x4f.h"
#include "Render.h"

using namespace std;

/* ===================== MAIN DE PRUEBAS ===================== */

int main() {

    cout << "\n==================== INICIANDO TESTS =======================\n";

    cout << "Creando Render de 11x11 y Punto (3,3,0)" << endl;
    Render render(11, 11);
    Vector4f punto = { 3, 3, 0, 1 };
    cout << "Insertando Punto en Render" << endl;
    render.PutPixel(punto.x, punto.y);
    render.Draw();

    cout << "Moviendo Punto 6 unidades a la izquierda" << endl;
    Matrix4x4f T = make_translate(-6, 0, 0);
    punto = T * punto;
    render.resetBuffer();
    render.PutPixel(punto.x, punto.y);
    render.Draw();

    cout << "Rotando punto 45º grados respecto al eje Z" << endl;
    Matrix4x4f R = make_rotate(0,0,90);
    punto = R * punto;
    render.resetBuffer();
    render.PutPixel(punto.x, punto.y);
    render.Draw();

    cout << "\n====================== PRUEBA DE CUATERNIONES =====================\n";

    // 1. Creamos la rotación de la forma estándar (usando matrices de Euler)
    // Queremos girar 90 grados en el eje Z
    Matrix4x4f rotMat = make_rotate(0, 0, 45);

    // 2. Creamos la misma rotación pero usando Cuaterniones 
    // Pasamos el eje Z (0,0,1) y el ángulo de 90 grados
    Vector4f q = make_quaternion(0, 0, 1, 90);
    Matrix4x4f rotQuat = make_rotate(q);

    // 3. Vamos a probar ambas rotaciones con el vector unitario (1, 0, 0)
    // Si giras (1, 0) 90 grados a la izquierda, debería terminar en (0, 1)
    Vector4f testVec = make_vector4f(1, 0, 0, 1);
    Vector4f resMat = rotMat * testVec;
    Vector4f resQuat = rotQuat * testVec;

    cout << "Rotando el vector (1,0,0) 90 grados en Z:\n";
    cout << "Resultado con Matriz:     (" << resMat.x << ", " << resMat.y << ")\n";
    cout << "Resultado con Cuaternion: (" << resQuat.x << ", " << resQuat.y << ")\n";

    // Comprobamos si ambos resultados son iguales
    if (abs(resMat.x - resQuat.x) < 0.01 && abs(resMat.y - resQuat.y) < 0.01) {
        cout << ">> EXITO: ¡La rotacion por cuaterniones funciona igual que la de matrices!\n";
    }
    else {
        cout << ">> ERROR: Los resultados no coinciden. Revisa la conversion a radianes.\n";
    }

    cout << "\n================ TEST FINALIZADO =====================\n";

    return 0;
}
