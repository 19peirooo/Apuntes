#pragma once
#include "vector4f.h"
#define PI 3.1416f
#define DIM_MATRIX 4

typedef struct {
	union {
		Vector4f t[4];
		float m[16];
	};
} Matrix4x4f; //Definicion de una matriz, se puede definir como 4 vectores o como array de 16 elementos

Matrix4x4f make_identityf(); //Creacion de la matriz identidad
Matrix4x4f make_translate(float x, float y, float z); //Creacion de la matriz de traslacion
Matrix4x4f make_rotate(float angleX, float angleY, float angleZ); //Creacion de la matriz de rotacion
Matrix4x4f make_scale(float x, float y, float z); //Creacion de la matriz de escalado
Matrix4x4f operator*(Matrix4x4f m1, Matrix4x4f m2); //Multiplicacion de dos matrices
Vector4f operator*(Matrix4x4f m, Vector4f v); //Multiplicacion de una matriz por un vector
Matrix4x4f operator*(Matrix4x4f m, float f); //Multiplicacion de una matriz por un escalar
Matrix4x4f operator+(Matrix4x4f m1, Matrix4x4f m2); //Suma de dos matrices
Matrix4x4f operator-(Matrix4x4f m1, Matrix4x4f m2); //Resta de dos matrices
Matrix4x4f transpose(Matrix4x4f m); //Transpuesta de una matriz
Matrix4x4f inverse(Matrix4x4f m); //Inversa de una matriz
Matrix4x4f adjoint(Matrix4x4f m); //Adjunta de una matriz
float determinant(Matrix4x4f m); //Determinante de una matriz
Matrix4x4f make_rotate(Vector4f quaternion);

// Funciones auxiliares
Vector4f getColumnVector(Matrix4x4f m, int num_col);
float det3x3(float m[3][3]);

