using UnityEngine;

public class Ejercicio1_6 : MonoBehaviour
{
    public GameObject esferaA;
    public GameObject esferaB;

    private float dirA = 1f;  // Esfera A avanza en X
    private float dirB = -1f; // Esfera B retrocede en X

    private MeshRenderer rendererA;
    private MeshRenderer rendererB;

    void Start()
    {
        esferaA.transform.position = Vector3.zero;
        esferaB.transform.position = Vector3.zero;

        rendererA = esferaA.GetComponent<MeshRenderer>();
        rendererB = esferaB.GetComponent<MeshRenderer>();
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            // Mover esferas
            esferaA.transform.position += new Vector3(0.001f * dirA, 0f, 0f);
            esferaB.transform.position += new Vector3(0.001f * dirB, 0f, 0f);

            // Comprobar límites y cambiar dirección
            if (esferaA.transform.position.x >= 10f || esferaA.transform.position.x <= -10f)
                dirA *= -1f;

            if (esferaB.transform.position.x >= 10f || esferaB.transform.position.x <= -10f)
                dirB *= -1f;
        }

        // Visibilidad esfera A
        float xA = esferaA.transform.position.x;
        bool ocultarA = (xA >= 5f && xA <= 7f) || (xA >= -7f && xA <= -5f);
        rendererA.enabled = !ocultarA;

        // Visibilidad esfera B
        float xB = esferaB.transform.position.x;
        bool ocultarB = (xB >= 5f && xB <= 7f) || (xB >= -7f && xB <= -5f);
        rendererB.enabled = !ocultarB;
    }
}
