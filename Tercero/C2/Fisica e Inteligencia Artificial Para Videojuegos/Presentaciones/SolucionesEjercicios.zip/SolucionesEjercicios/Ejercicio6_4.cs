using UnityEngine;

// ¿Qué diferencia ves respecto al Trigger del ejercicio anterior?
//
// Con Rigidbody DINÁMICO y OnCollisionEnter:
// - La esfera RESPETA la física: al chocar con los cubos, rebota, los empuja o se detiene.
//   La destrucción ocurre, pero DESPUÉS de que el motor de física haya resuelto el contacto.
// - La esfera NO atraviesa los objetos; hay respuesta física real (fuerzas de reacción).
// - El evento se lanza en el momento del primer contacto superficial.
//
// Con Trigger y esfera CINEMÁTICA:
// - La esfera atraviesa los objetos completamente, sin ninguna respuesta física.
// - El evento se lanza cuando los colliders se superponen (overlap), no al tocarse.
// - No hay rebotes ni empujes; solo detección de zona.
//
// En resumen: Collision = física real + detección de contacto.
//             Trigger   = solo detección de zona, sin física.

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio6_4 : MonoBehaviour
{
    private Rigidbody rb;
    private float fuerza = 20f;

    private float h, v;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = false;
    }

    void Update()
    {
        h = Input.GetAxisRaw("Horizontal");
        v = Input.GetAxisRaw("Vertical");
    }

    void FixedUpdate()
    {
        Vector3 direccion = new Vector3(h, 0f, v).normalized;
        rb.AddForce(direccion * fuerza, ForceMode.Force);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Cubo"))
        {
            Destroy(collision.gameObject);
        }
    }
}
