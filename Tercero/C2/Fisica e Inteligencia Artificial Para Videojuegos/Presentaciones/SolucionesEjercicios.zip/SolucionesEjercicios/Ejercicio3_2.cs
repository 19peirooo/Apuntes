using UnityEngine;

public class Ejercicio3_2 : MonoBehaviour
{
    private int capacidadMaxima = 7;
    private int balasActuales = 7;

    void Start()
    {
        Debug.Log("Revólver listo. Balas: " + balasActuales + "/" + capacidadMaxima);
    }

    void Update()
    {
        // Disparo - click izquierdo
        if (Input.GetMouseButtonDown(0))
        {
            if (balasActuales > 0)
            {
                balasActuales--;
                Debug.Log("¡Disparo! Balas restantes: " + balasActuales + "/" + capacidadMaxima);
            }
            else
            {
                Debug.Log("Sin balas. ¡Recarga!");
            }
        }

        // Recarga - click derecho
        if (Input.GetMouseButtonDown(1))
        {
            if (balasActuales < capacidadMaxima)
            {
                balasActuales = capacidadMaxima;
                Debug.Log("Recargando... Balas: " + balasActuales + "/" + capacidadMaxima);
            }
            else
            {
                Debug.Log("El revólver ya está lleno. No necesitas recargar.");
            }
        }
    }
}
