using UnityEngine;

// INSTRUCCIONES DE ESCENA:
// - Esfera con Rigidbody CINEMÁTICO. Este script va en la ESFERA.
// - Muros: cubos alargados SIN MeshRenderer, con Collider marcado como "Is Trigger".
//   Colócalos en (2,0,0), (4,0,0), (6,0,0)... con Tag "Muro" (créalo en Tag Manager).
// - La esfera parte en (0,0,0) y se mueve sola en X positivo.

public class Ejercicio6_7 : MonoBehaviour
{
    private float velocidad = 3f;
    private MeshRenderer meshRenderer;

    void Start()
    {
        meshRenderer = GetComponent<MeshRenderer>();
        transform.position = Vector3.zero;
    }

    void Update()
    {
        // Movimiento automático en eje X global positivo
        transform.position += Vector3.right * velocidad * Time.deltaTime;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Muro"))
        {
            meshRenderer.enabled = false;
            Debug.Log("Esfera entra en muro — MeshRenderer deshabilitado.");
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Muro"))
        {
            meshRenderer.enabled = true;
            Debug.Log("Esfera sale del muro — MeshRenderer habilitado.");
        }
    }
}
