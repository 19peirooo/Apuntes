using UnityEngine;

// INSTRUCCIONES DE ESCENA:
// - Cubo con Rigidbody dinámico apoyado sobre una superficie. Este script va en el CUBO.
// - Superficie: cubo estático con collider normal.
// - Zona de muerte: cubo invisible (sin MeshRenderer) colocado DEBAJO de la superficie,
//   con Collider marcado como "Is Trigger" y Tag "ZonaMuerte" (créalo en Tag Manager).
//   Si la superficie tiene agujeros o bordes, el cubo puede caer y atravesar la zona de muerte.

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio6_8 : MonoBehaviour
{
    private Rigidbody rb;
    private float fuerza = 25f;
    private float h, v;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        h = Input.GetAxisRaw("Horizontal");
        v = Input.GetAxisRaw("Vertical");
    }

    void FixedUpdate()
    {
        Vector3 direccion = new Vector3(h, 0f, v).normalized;
        rb.AddForce(direccion * fuerza, ForceMode.Force);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("ZonaMuerte"))
        {
            Debug.Log("¡El cubo cayó en la zona de muerte! Destruyendo...");
            Destroy(gameObject);
        }
    }
}
