using UnityEngine;

public class Ejercicio2_3 : MonoBehaviour
{
    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        // Traslación en ejes locales X y Z a 5 u/s
        Vector3 movimiento = (transform.right * horizontal + transform.forward * vertical) * 5f * Time.deltaTime;
        transform.position += movimiento;
    }
}
