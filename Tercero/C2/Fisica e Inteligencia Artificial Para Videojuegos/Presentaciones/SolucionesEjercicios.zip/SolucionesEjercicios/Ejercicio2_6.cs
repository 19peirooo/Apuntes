using UnityEngine;

// Este script maneja DOS cubos:
// - Cubo A (el GameObject donde está el script): se mueve en Y global con teclas verticales, limitado a ±10.
// - Cubo B (asignado en el Inspector): parte de posición random, se mueve en un eje y velocidad random,
//   se detiene al recorrer 15 unidades.

public class Ejercicio2_6 : MonoBehaviour
{
    [Header("Cubo B - movimiento random")]
    [SerializeField] private GameObject cuboB;

    // --- Cubo B ---
    private Vector3 ejeRandom;
    private float velocidadRandom;
    private float distanciaRecorrida = 0f;
    private bool detenido = false;

    void Start()
    {
        // Cubo A en (0,0,0)
        transform.position = Vector3.zero;

        // Cubo B en posición random
        if (cuboB != null)
        {
            cuboB.transform.position = new Vector3(
                Random.Range(-10f, 10f),
                Random.Range(-10f, 10f),
                Random.Range(-10f, 10f)
            );

            // Eje unitario random
            ejeRandom = Random.onUnitSphere;

            // Velocidad random entre 3 y 6 u/s
            velocidadRandom = Random.Range(3f, 6f);
        }
    }

    void Update()
    {
        // --- Cubo A: movimiento en Y global con teclas verticales, limitado a ±10 ---
        float vertical = Input.GetAxis("Vertical");
        float nuevaY = transform.position.y + vertical * 5f * Time.deltaTime;
        nuevaY = Mathf.Clamp(nuevaY, -10f, 10f);
        transform.position = new Vector3(transform.position.x, nuevaY, transform.position.z);

        // --- Cubo B: movimiento en eje random hasta 15u ---
        if (cuboB != null && !detenido)
        {
            float paso = velocidadRandom * Time.deltaTime;
            cuboB.transform.position += ejeRandom * paso;
            distanciaRecorrida += paso;

            if (distanciaRecorrida >= 15f)
                detenido = true;
        }
    }
}
