using UnityEngine;

public class Ejercicio2_5 : MonoBehaviour
{
    private float sentido = 1f; // 1 = creciendo, -1 = encogiéndose
    private float velocidad = 2f;
    private float escalaMin = 1f;
    private float escalaMax = 10f;

    void Update()
    {
        transform.localScale += Vector3.one * sentido * velocidad * Time.deltaTime;

        if (transform.localScale.x >= escalaMax)
        {
            transform.localScale = Vector3.one * escalaMax;
            sentido = -1f;
        }
        else if (transform.localScale.x <= escalaMin)
        {
            transform.localScale = Vector3.one * escalaMin;
            sentido = 1f;
        }
    }
}
