using UnityEngine;

// ¿Hace falta FixedUpdate?
//
// CASO 1 - Fuerza en Start():
// No hace falta FixedUpdate. Start() se ejecuta una sola vez antes del primer frame
// y la física ya está inicializada. AddForce en Start() funciona correctamente porque
// solo se llama una vez; no hay riesgo de que se llame en momentos inconsistentes.
//
// CASO 2 - Fuerza al pulsar espacio (ForceMode.Impulse):
// Tampoco es estrictamente necesario el FixedUpdate para un IMPULSO puntual.
// Un impulso se aplica instantáneamente (modifica la velocidad en un solo paso),
// así que leer el Input en Update() y aplicar la fuerza allí es perfectamente válido.
// SÍ sería necesario FixedUpdate si aplicásemos una fuerza CONTINUA (ForceMode.Force
// o ForceMode.Acceleration) frame a frame, porque entonces el resultado dependería
// de la frecuencia de frames (variable), mientras que FixedUpdate tiene un timestep
// fijo y consistente con el motor de física.

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio5_2 : MonoBehaviour
{
    private Rigidbody rb;
    private bool fuerzaEspacioAplicada = false;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        // CASO 1: Fuerza impulso al iniciar el juego
        rb.AddForce(Vector3.right * 5f, ForceMode.Impulse);
        Debug.Log("Fuerza impulso aplicada en Start().");
    }

    void Update()
    {
        // CASO 2: Fuerza impulso al pulsar espacio (una sola vez)
        if (Input.GetKeyDown(KeyCode.Space) && !fuerzaEspacioAplicada)
        {
            rb.AddForce(Vector3.right * 5f, ForceMode.Impulse);
            fuerzaEspacioAplicada = true;
            Debug.Log("Fuerza impulso aplicada al pulsar espacio.");
        }
    }
}
