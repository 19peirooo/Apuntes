using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio3_5 : MonoBehaviour
{
    private float velocidadBase = 5f;
    private float velocidadActual;
    private float fuerzaSalto = 5f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        velocidadActual = velocidadBase;
    }

    void Update()
    {
        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical   = Input.GetAxisRaw("Vertical");


        // --- Estado de velocidad ---
        // El agacharse precede al correr
        if (Input.GetKey(KeyCode.LeftControl))
        {
            velocidadActual = velocidadBase * 0.5f;
        }
        else if (Input.GetKey(KeyCode.LeftShift) && horizontal != 0f || vertical != 0f) //Si hay movimiento...
        {
            velocidadActual = velocidadBase * 2.5f; // +150% = 250% de la base
        }
        else
        {
            velocidadActual = velocidadBase;
        }

        // --- Movimiento ---
        Vector3 movimiento = (transform.right * horizontal + transform.forward * vertical).normalized;
        rb.linearVelocity = movimiento * velocidadActual; //Velocidad lineal basada en los inputs y en la velocidadActual

        // --- Salto ---
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(Vector3.up * fuerzaSalto, ForceMode.Impulse);
        }
    }
}
