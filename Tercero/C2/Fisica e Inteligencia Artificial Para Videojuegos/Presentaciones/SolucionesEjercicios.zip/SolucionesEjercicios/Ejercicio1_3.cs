using UnityEngine;

public class Ejercicio1_3 : MonoBehaviour
{
    void Start()
    {
        float randomZ = Random.Range(0f, 360f);
        transform.rotation = Quaternion.Euler(0f, 0f, randomZ);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.D))
            transform.eulerAngles += new Vector3(0, 0, 15f);
        else if (Input.GetKeyDown(KeyCode.A))
            transform.eulerAngles += new Vector3(0, 0, -15f);
    }
}
