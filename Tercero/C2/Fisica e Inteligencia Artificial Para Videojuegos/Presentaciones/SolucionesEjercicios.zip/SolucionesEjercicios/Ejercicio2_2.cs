using UnityEngine;

// PREGUNTA: ¿Por qué realiza un comportamiento extraño?
// El cubo rota en su eje X local a 45°/s. Como el eje local X cambia con la rotación,
// cuando el cubo se inclina, su "adelante" local (Z local) también se inclina,
// por lo que la traslación describe una trayectoria curva/circular en lugar de recta.
// Es el acoplamiento entre rotación y traslación local: al rotar el objeto, su espacio
// local rota con él, y la traslación siempre sigue ese espacio local transformado.

// SOLUCIÓN: Si queremos que avance recto (en Z global) mientras rota en X local,
// basta con usar Space.World en la traslación:
// transform.Translate(Vector3.forward * 3f * Time.deltaTime, Space.World);

public class Ejercicio2_2 : MonoBehaviour
{
    void Update()
    {
        // Rotación automática en eje X local a 45°/s
        transform.Rotate(Vector3.right * 45f * Time.deltaTime, Space.Self);

        // Traslación en eje Z LOCAL (comportamiento "extraño": sigue al eje local rotado)
        transform.Translate(Vector3.forward * 3f * Time.deltaTime, Space.Self);

        // SOLUCIÓN (descomentar para corregir el comportamiento):
        // transform.Translate(Vector3.forward * 3f * Time.deltaTime, Space.World);
    }
}
