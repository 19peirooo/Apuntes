using UnityEngine;

// INSTRUCCIONES DE ESCENA:
// - Esfera con Rigidbody dinámico. Este script va en la ESFERA.
// - Zona de lava: un cubo aplanado con Collider marcado como "Is Trigger".
//   Asignarle el Tag "Lava" (créalo en Tag Manager).
//   Puedes quitarle el MeshRenderer o dejarlo semitransparente para visualizarla.

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio6_6 : MonoBehaviour
{
    private Rigidbody rb;
    private float fuerzaNormal = 10f;
    private float fuerzaActual;

    private float h, v;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        fuerzaActual = fuerzaNormal;
    }

    void Update()
    {
        h = Input.GetAxisRaw("Horizontal");
        v = Input.GetAxisRaw("Vertical");
    }

    void FixedUpdate()
    {
        Vector3 direccion = new Vector3(h, 0f, v).normalized;
        rb.AddForce(direccion * fuerzaActual, ForceMode.Force);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Lava"))
        {
            fuerzaActual = fuerzaNormal * 0.5f;
            Debug.Log("Entrando en la lava. Fuerza reducida a: " + fuerzaActual);
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Lava"))
        {
            fuerzaActual = fuerzaNormal;
            Debug.Log("Saliendo de la lava. Fuerza restaurada a: " + fuerzaActual);
        }
    }
}
