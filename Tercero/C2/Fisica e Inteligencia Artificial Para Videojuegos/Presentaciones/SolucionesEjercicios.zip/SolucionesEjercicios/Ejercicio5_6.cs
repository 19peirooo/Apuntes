using UnityEngine;

// ============================================================================================
// EJERCICIO 4_6 — Cuatro configuraciones de colisión entre dos esferas
//
// INSTRUCCIONES DE ESCENA:
// - Crea una plataforma (cubo estirado) sin Rigidbody (estático).
// - Crea Esfera A y Esfera B sobre la plataforma, separadas en Z.
//   Cada sub-apartado requiere una configuración distinta de sus Rigidbodies.
// - Asigna este script a un GameObject vacío "Manejador" y arrastra las esferas al Inspector.
// ============================================================================================

public class Ejercicio5_6 : MonoBehaviour
{
    [Header("Referencias")]
    [SerializeField] private GameObject esferaA;
    [SerializeField] private GameObject esferaB;

    [Header("Selecciona el sub-apartado (1-4)")]
    [SerializeField] private int subApartado = 1;

    private Rigidbody rbA;
    private Rigidbody rbB;

    // ========================================================================================
    // SUB-APARTADO 1:
    // Esfera A: CINEMÁTICO. Esfera B: DINÁMICO con masa infinita (masa muy alta, ej: 1e9).
    // Esfera A se traslada en Z con transform.position (cinemático = movido por código).
    //
    // ¿Qué ocurre?
    // La esfera A, al ser cinemática, NO es afectada por la física pero SÍ puede empujar
    // a objetos dinámicos. Cuando A choca con B, aplica una fuerza de contacto sobre B.
    // Aunque B tiene masa "infinita" (muy alta), la esfera A cinemática la empuja igualmente
    // porque los objetos cinemáticos generan colisiones de contacto con los dinámicos.
    // Con masa muy alta B se moverá muy poco o nada apreciable, pero técnicamente recibe el impulso.
    // ========================================================================================

    // ========================================================================================
    // SUB-APARTADO 2:
    // Esfera A: CINEMÁTICO. Esfera B: CINEMÁTICO.
    // Esfera A se traslada en Z con transform.position.
    //
    // ¿Qué ocurre?
    // DOS objetos cinemáticos NO colisionan entre sí físicamente: se atraviesan.
    // Los cinemáticos ignoran las fuerzas de colisión mutuas; la física solo detecta
    // el overlap pero no resuelve ningún contacto entre ellos. Para detectar el evento
    // habría que usar OnTrigger o que uno de los dos sea dinámico.
    // ========================================================================================

    // ========================================================================================
    // SUB-APARTADO 3:
    // Esfera A: DINÁMICO. Esfera B: DINÁMICO, masa 0.2.
    // Se aplica un impulso a A en dirección Z global.
    //
    // ¿Qué ocurre?
    // A recibe el impulso y se desplaza hacia B. Al chocar, como ambas son dinámicas,
    // el motor de física calcula una colisión elástica/inelástica real basada en sus masas.
    // Dado que B tiene masa baja (0.2), al recibir el impacto de A saldrá disparada con
    // mucha más velocidad (conservación del momento lineal: m·v = m'·v').
    // Es un comportamiento realista de billar: objeto pesado golpea a objeto ligero → el ligero sale muy rápido.
    // ========================================================================================

    // ========================================================================================
    // SUB-APARTADO 4:
    // Esfera A: DINÁMICO. Esfera B: CINEMÁTICO.
    // Se aplica un impulso a A en dirección Z global.
    //
    // ¿Qué ocurre?
    // A recibe el impulso y se mueve hacia B. Al chocar, B al ser cinemática actúa como
    // una pared inamovible: no se desplaza ni recibe fuerzas. A rebota (o se detiene) contra B
    // como si fuera un obstáculo estático. El objeto cinemático tiene, a efectos de colisión,
    // masa infinita para los objetos dinámicos que colisionan con él.
    // ========================================================================================

    void Start()
    {
        rbA = esferaA.GetComponent<Rigidbody>();
        rbB = esferaB.GetComponent<Rigidbody>();

        switch (subApartado)
        {
            case 1: ConfigurarApartado1(); break;
            case 2: ConfigurarApartado2(); break;
            case 3: ConfigurarApartado3(); break;
            case 4: ConfigurarApartado4(); break;
        }
    }

    void Update()
    {
        // Movimiento cinemático de A en los apartados 1 y 2
        if (subApartado == 1 || subApartado == 2)
        {
            esferaA.transform.position += Vector3.forward * 2f * Time.deltaTime;
        }
    }

    // --- Configuraciones ---

    void ConfigurarApartado1()
    {
        rbA.isKinematic = true;
        rbB.isKinematic = false;
        rbB.mass = 1e9f; // masa "infinita"
        Debug.Log("Apartado 1: A cinemática, B dinámica con masa infinita.");
    }

    void ConfigurarApartado2()
    {
        rbA.isKinematic = true;
        rbB.isKinematic = true;
        Debug.Log("Apartado 2: A cinemática, B cinemática. Se atravesarán.");
    }

    void ConfigurarApartado3()
    {
        rbA.isKinematic = false;
        rbB.isKinematic = false;
        rbA.mass = 1f;
        rbB.mass = 0.2f;
        rbA.AddForce(Vector3.forward * 10f, ForceMode.Impulse);
        Debug.Log("Apartado 3: A dinámica, B dinámica (masa 0.2). Impulso aplicado a A.");
    }

    void ConfigurarApartado4()
    {
        rbA.isKinematic = false;
        rbB.isKinematic = true;
        rbA.AddForce(Vector3.forward * 10f, ForceMode.Impulse);
        Debug.Log("Apartado 4: A dinámica, B cinemática. A rebotará contra B como pared.");
    }
}
