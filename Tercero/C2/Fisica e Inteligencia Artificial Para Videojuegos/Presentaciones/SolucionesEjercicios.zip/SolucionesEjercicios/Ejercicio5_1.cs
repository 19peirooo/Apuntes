using UnityEngine;

// ¿Por qué cae al estar en dinámico?
// Cuando el Rigidbody está en modo DINÁMICO, queda sujeto a las fuerzas físicas del motor,
// entre ellas la GRAVEDAD. Unity aplica una aceleración constante hacia abajo (9.81 m/s²
// por defecto) sobre cualquier cuerpo dinámico que no esté apoyado en una superficie.
// En modo CINEMÁTICO, el objeto es movido exclusivamente por código (Transform o MovePosition),
// la física no le aplica ninguna fuerza, por eso permanece suspendido en el aire.

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio5_1 : MonoBehaviour
{
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        // Comenzamos en cinemático: el cubo flota sin caer
        rb.isKinematic = true;
        Debug.Log("Estado inicial: CINEMÁTICO");
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.isKinematic = !rb.isKinematic;
            string estado = rb.isKinematic ? "CINEMÁTICO" : "DINÁMICO";
            Debug.Log("Estado cambiado a: " + estado);
        }
    }
}
