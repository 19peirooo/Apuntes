using UnityEngine;

// INSTRUCCIONES DE ESCENA:
// - Esfera con Rigidbody CINEMÁTICO. Marcar "Is Trigger" en su Collider.
// - Cubo en escena, quieto, con Collider normal (sin trigger).
// - Este script va en la ESFERA.

public class Ejercicio6_1 : MonoBehaviour
{
    private float velocidad = 5f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 movimiento = new Vector3(h, 0f, v) * velocidad * Time.deltaTime;
        transform.position += movimiento;
    }

    void OnTriggerEnter(Collider other)
    {
        // En cuanto la esfera comienza a atravesar el cubo, lo destruye
        Destroy(other.gameObject);
    }
}
