using UnityEngine;

// INSTRUCCIONES DE ESCENA: las mismas que en Ejercicio4_4.
// Sustituye el script Ejercicio4_4 por este en el CañonPivote.

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio5_5 : MonoBehaviour
{
    [Header("Referencia a la bola")]
    [SerializeField] private GameObject bola;

    [Header("Parámetros de rotación")]
    [SerializeField] private float velocidadRotacion = 60f;

    [Header("Parámetros de disparo")]
    [SerializeField] private float velocidadCarga = 0.5f;   // unidades acumuladas por segundo
    [SerializeField] private float fuerzaMaxima = 20f;

    private Rigidbody rbCanon;
    private Rigidbody rbBola;
    private float fuerzaAcumulada = 0f;
    private bool cargando = false;

    void Start()
    {
        rbCanon = GetComponent<Rigidbody>();
        rbCanon.isKinematic = true;

        if (bola != null)
        {
            rbBola = bola.GetComponent<Rigidbody>();
            rbBola.isKinematic = true; // La bola empieza cinemática emparentada al cañón
        }
    }

    void Update()
    {
        // --- Rotación del cañón ---
        float horizontal = Input.GetAxis("Horizontal");
        transform.Rotate(0f, 0f, -horizontal * velocidadRotacion * Time.deltaTime, Space.Self);

        // --- Carga del disparo ---
        if (Input.GetKey(KeyCode.Space) && rbBola.isKinematic)
        {
            fuerzaAcumulada += velocidadCarga * Time.deltaTime;
            fuerzaAcumulada = Mathf.Min(fuerzaAcumulada, fuerzaMaxima);
            cargando = true;
            Debug.Log("Cargando disparo... Fuerza: " + fuerzaAcumulada.ToString("F2"));
        }

        // --- Disparo al soltar espacio ---
        if (Input.GetKeyUp(KeyCode.Space) && cargando)
        {
            // Desemparentar la bola del cañón
            bola.transform.SetParent(null);

            // Pasar a dinámico
            rbBola.isKinematic = false;

            // Dirección de disparo: Z local del cañón (boca del cañón)
            Vector3 direccionDisparo = transform.forward;
            rbBola.AddForce(direccionDisparo * fuerzaAcumulada, ForceMode.Impulse);

            Debug.Log("¡Disparo! Fuerza: " + fuerzaAcumulada.ToString("F2"));

            fuerzaAcumulada = 0f;
            cargando = false;
        }
    }
}
