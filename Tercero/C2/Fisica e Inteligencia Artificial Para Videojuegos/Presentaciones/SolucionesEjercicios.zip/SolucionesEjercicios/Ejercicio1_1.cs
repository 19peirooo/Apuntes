using UnityEngine;

public class Ejercicio1_1 : MonoBehaviour
{
    void Start()
    {
        transform.position = new Vector3(5f, 3f, 5f);
    }
}
