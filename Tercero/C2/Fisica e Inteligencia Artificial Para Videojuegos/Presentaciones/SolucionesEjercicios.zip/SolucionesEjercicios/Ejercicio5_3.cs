using UnityEngine;

// ¿En qué casos hace falta FixedUpdate?
// La fuerza CONTINUA de movimiento (ForceMode.Force) DEBE aplicarse en FixedUpdate.
// El motor de física de Unity se actualiza en pasos de tiempo fijos (Time.fixedDeltaTime,
// 0.02s por defecto). Si aplicamos fuerzas continuas en Update(), que varía con los FPS,
// el resultado físico sería inconsistente: a más FPS más fuerza acumulada, a menos FPS menos.
// FixedUpdate garantiza que la fuerza se aplica siempre el mismo número de veces por segundo,
// independientemente de los fotogramas.
//
// El IMPULSO del salto (ForceMode.Impulse) podría ponerse en Update() porque es puntual.
//
// ¿Por qué sigue moviéndose la esfera al soltar las teclas?
// Porque el Rigidbody tiene INERCIA. Newton: un cuerpo en movimiento tiende a seguir moviéndose.
// Al dejar de aplicar fuerza, la esfera conserva la velocidad acumulada. Solo el rozamiento
// (Angular/Linear Drag del Rigidbody) o una superficie con fricción la frenará gradualmente.
// Si quisieras un frenado más brusco, habría que aumentar el Drag en el Inspector o
// aplicar una fuerza opuesta al movimiento cuando no se pulsa nada.

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio5_3 : MonoBehaviour
{
    private Rigidbody rb;
    private float fuerzaMovimiento = 5f;
    private float fuerzaSalto = 10f;

    private float horizontal;
    private float vertical;
    private bool saltar;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        // Leemos el input en Update (más responsivo)
        horizontal = Input.GetAxisRaw("Horizontal");
        vertical   = Input.GetAxisRaw("Vertical");

        if (Input.GetKeyDown(KeyCode.Space))
            saltar = true;
    }

    void FixedUpdate()
    {
        // Fuerza continua de movimiento en X y Z global
        Vector3 direccion = new Vector3(horizontal, 0f, vertical).normalized;
        rb.AddForce(direccion * fuerzaMovimiento, ForceMode.Force);

        // Impulso de salto
        if (saltar)
        {
            rb.AddForce(Vector3.up * fuerzaSalto, ForceMode.Impulse);
            saltar = false;
        }
    }
}
