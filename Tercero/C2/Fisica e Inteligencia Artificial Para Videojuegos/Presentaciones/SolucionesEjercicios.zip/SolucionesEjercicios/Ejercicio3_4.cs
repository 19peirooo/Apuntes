using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio3_4 : MonoBehaviour
{
    private float fuerzaSalto = 0f;
    private float cargaMaxima = 300f;
    private float velocidadCarga = 100f; // unidades por segundo que se carga

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        // Cargar mientras se mantiene espacio
        if (Input.GetKey(KeyCode.Space))
        {
            fuerzaSalto += velocidadCarga * Time.deltaTime;
            fuerzaSalto = Mathf.Min(fuerzaSalto, cargaMaxima);
            Debug.Log("Cargando salto... FuerzaSalto: " + fuerzaSalto.ToString());
        }

        // Saltar al soltar el espacio
        if (Input.GetKeyUp(KeyCode.Space))
        {
            Debug.Log("¡Salto! Fuerza aplicada: " + fuerzaSalto.ToString());
            rb.AddForce(Vector3.up * fuerzaSalto, ForceMode.Impulse);
            fuerzaSalto = 0f;
        }
    }
}
