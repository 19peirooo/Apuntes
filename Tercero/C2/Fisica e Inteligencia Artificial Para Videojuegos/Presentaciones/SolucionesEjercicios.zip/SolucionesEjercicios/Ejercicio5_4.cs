using UnityEngine;

// INSTRUCCIONES DE ESCENA:
// 1. Crea un cubo con escala (0.5, 0.5, 2). Este es el cañón.
// 2. Para reposicionar el pivote al "pie": crea un GameObject vacío llamado "CañonPivote"
//    en la posición donde quieres el pie (p.ej. el extremo inferior del cubo), y emparenta
//    el cubo como hijo de ese pivote. Pon este script en "CañonPivote".
// 3. Crea una esfera con escala (0.3, 0.3, 0.3), añádele Rigidbody en modo Cinemático
//    y sitúala en la boca del cañón (extremo Z+ del cubo). Emparéntala al CañonPivote.
// 4. Mueve la cámara a una vista lateral (p.ej. posición X=5, Y=0, Z=0, mirando al cañón).

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio5_4 : MonoBehaviour
{
    [Header("Referencia a la bola")]
    [SerializeField] private GameObject bola;

    [Header("Parámetros de rotación")]
    [SerializeField] private float velocidadRotacion = 60f; // grados por segundo

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = true; // El cañón se mueve cinemáticamente
    }

    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");

        // Rotación cinemática en Z desde el pie del pivote
        transform.Rotate(0f, 0f, -horizontal * velocidadRotacion * Time.deltaTime, Space.Self);
    }
}
