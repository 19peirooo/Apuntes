using UnityEngine;

public class Ejercicio1_2 : MonoBehaviour
{
    private Vector3 initialPosition;

    void Start()
    {
        float x = Random.Range(-10f, 10f);
        float y = Random.Range(-10f, 10f);
        float z = Random.Range(-10f, 10f);
        initialPosition = new Vector3(x, y, z);
        transform.position = initialPosition;
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.W))
            transform.position = initialPosition + new Vector3(0f, 0f, 5f);
        else if (Input.GetKey(KeyCode.S))
            transform.position = initialPosition + new Vector3(0f, 0f, -5f);
        else if (Input.GetKey(KeyCode.D))
            transform.position = initialPosition + new Vector3(5f, 0f, 0f);
        else if (Input.GetKey(KeyCode.A))
            transform.position = initialPosition + new Vector3(-5f, 0f, 0f);
        else
            transform.position = initialPosition;
    }
}
