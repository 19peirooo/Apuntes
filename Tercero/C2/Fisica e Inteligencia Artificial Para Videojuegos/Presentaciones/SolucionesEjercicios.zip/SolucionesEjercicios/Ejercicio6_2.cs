using UnityEngine;

// INSTRUCCIONES DE ESCENA:
// - Esfera con Rigidbody CINEMÁTICO y Collider marcado como "Is Trigger".
// - Varios GameObjects en escena (cápsulas, esferas, cilindros...).
// - Los que deben destruirse han de tener el Tag "Cubo" (créalo en Tag Manager si no existe).
// - Este script va en la ESFERA.

public class Ejercicio6_2 : MonoBehaviour
{
    private float velocidad = 5f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 movimiento = new Vector3(h, 0f, v) * velocidad * Time.deltaTime;
        transform.position += movimiento;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Cubo"))
        {
            Destroy(other.gameObject);
        }
    }
}
