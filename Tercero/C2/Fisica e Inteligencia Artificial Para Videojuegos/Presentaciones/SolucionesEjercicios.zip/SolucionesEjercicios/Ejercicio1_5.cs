using UnityEngine;

public class Ejercicio1_5 : MonoBehaviour
{
    public GameObject cubo;
    public GameObject esfera;

    void Start()
    {
        // Posición random del cubo
        float x = Random.Range(-10f, 10f);
        float y = Random.Range(-10f, 10f);
        float z = Random.Range(-10f, 10f);
        Vector3 cuboPosicion = new Vector3(x, y, z);
        cubo.transform.position = cuboPosicion;

        // La esfera se coloca a 3 unidades en X respecto al cubo
        esfera.transform.position = cuboPosicion + new Vector3(3f, 0f, 0f);

        // El radio del SphereCollider de la esfera es igual a la coordenada Y del cubo
        SphereCollider sc = esfera.GetComponent<SphereCollider>();
		sc.radius = cuboPosicion.y;
    }
}
