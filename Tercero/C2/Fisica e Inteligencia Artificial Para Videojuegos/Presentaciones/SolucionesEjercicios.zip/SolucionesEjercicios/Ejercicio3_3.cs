using UnityEngine;

public class Ejercicio3_3 : MonoBehaviour
{
    private int capacidadMaxima = 40;
    private int balasActuales = 40;

    private float cadencia = 0.1f;       // segundos entre bala y bala
    private float tiempoUltimoBalazo = 0f;

    void Start()
    {
        Debug.Log("Metralleta lista. Balas: " + balasActuales + "/" + capacidadMaxima);
    }

    void Update()
    {
        // Disparo automático - mantener click izquierdo
        if (Input.GetMouseButton(0))
        {
            if (balasActuales > 0)
            {
                if (Time.time >= tiempoUltimoBalazo + cadencia)
                {
                    balasActuales--;
                    tiempoUltimoBalazo = Time.time;
                    Debug.Log("¡Disparo! Balas restantes: " + balasActuales + "/" + capacidadMaxima);
                }
            }
            else
            {
                Debug.Log("Sin balas. ¡Recarga!");
            }
        }

        // Recarga - click derecho
        if (Input.GetMouseButtonDown(1))
        {
            if (balasActuales < capacidadMaxima)
            {
                balasActuales = capacidadMaxima;
                Debug.Log("Recargando... Balas: " + balasActuales + "/" + capacidadMaxima);
            }
            else
            {
                Debug.Log("La metralleta ya está llena. No necesitas recargar.");
            }
        }
    }
}
