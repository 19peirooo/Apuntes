using UnityEngine;

public class Ejercicio2_1 : MonoBehaviour
{
    void Update()
    {
        // Traslación en eje Z global positivo a 2 u/s
        transform.position += Vector3.forward * 2f * Time.deltaTime;

        // Rotación en eje X local a 90º/s según eje horizontal
        float horizontal = Input.GetAxis("Horizontal");
        transform.Rotate(Vector3.right * horizontal * 90f * Time.deltaTime, Space.Self);
    }
}
