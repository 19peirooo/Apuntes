using UnityEngine;

public class Ejercicio3_1 : MonoBehaviour
{
    private int contador = 0;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            contador++;
            Debug.Log("Click izquierdo. Contador: " + contador);
        }

        if (Input.GetMouseButtonDown(1))
        {
            if (contador > 0)
            {
                contador--;
                Debug.Log("Click derecho. Contador: " + contador);
            }
            else
            {
                Debug.Log("Click derecho. El contador ya está en 0, no puede bajar más.");
            }
        }
    }
}
