using UnityEngine;

public class Ejercicio2_4 : MonoBehaviour
{
    private Vector3 direccion;

    void Start()
    {
        // Dirección inicial: eje X local positivo
        direccion = transform.right;
    }

    void Update()
    {
        float horizontal = Input.GetAxisRaw("Horizontal");
        float vertical = Input.GetAxisRaw("Vertical");

        // Cambio de dirección según tecla pulsada (basta pulsarla una vez)
        if (horizontal > 0f)
            direccion = transform.right;
        else if (horizontal < 0f)
            direccion = -transform.right;
        else if (vertical > 0f)
            direccion = transform.forward;
        else if (vertical < 0f)
            direccion = -transform.forward;

        // Movimiento continuo en la dirección actual a 3 u/s
        transform.position += direccion * 3f * Time.deltaTime;
    }
}
