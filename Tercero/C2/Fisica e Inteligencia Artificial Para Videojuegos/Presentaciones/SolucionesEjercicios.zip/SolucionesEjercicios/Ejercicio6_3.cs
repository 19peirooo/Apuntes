using UnityEngine;

// ¿Por qué no funciona OnCollisionEnter con la esfera cinemática?
//
// Los objetos CINEMÁTICOS están fuera del sistema de resolución de colisiones de Unity.
// OnCollisionEnter solo se dispara cuando DOS objetos dinámicos colisionan, o cuando
// un dinámico choca contra un estático. Un Rigidbody cinemático NO genera eventos
// de colisión (OnCollisionEnter/Stay/Exit) porque el motor de física no calcula
// respuestas de fuerza para él; lo mueve directamente por código.
//
// La alternativa correcta para un cinemático es usar el COLLIDER COMO TRIGGER
// (marcar "Is Trigger") y usar OnTriggerEnter, como en los ejercicios anteriores.
// Con trigger, Unity sí notifica la superposición aunque el objeto sea cinemático.

public class Ejercicio6_3 : MonoBehaviour
{
    private float velocidad = 5f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 movimiento = new Vector3(h, 0f, v) * velocidad * Time.deltaTime;
        transform.position += movimiento;
    }

    // Este método NO se ejecutará mientras la esfera sea cinemática sin trigger.
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Cubo"))
        {
            Destroy(collision.gameObject);
            Debug.Log("Colisión detectada — esto solo funciona si la esfera es DINÁMICA.");
        }
    }
}
