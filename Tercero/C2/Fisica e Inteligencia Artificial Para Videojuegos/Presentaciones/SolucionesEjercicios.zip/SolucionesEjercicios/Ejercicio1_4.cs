using UnityEngine;

public class Ejercicio1_4 : MonoBehaviour
{
    private Vector3 originalScale = new Vector3(1f, 1f, 1f);

    void Start()
    {
        transform.localScale = originalScale;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Vector3 newScale = transform.localScale + new Vector3(1f, 1f, 1f);

            if (newScale.x > 10f)
                transform.localScale = originalScale;
            else
                transform.localScale = newScale;
        }
    }
}
