using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Ejercicio6_5 : MonoBehaviour
{
    private Rigidbody rb;
    private float fuerza = 20f;
    private float h, v;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = false;
    }

    void Update()
    {
        h = Input.GetAxisRaw("Horizontal");
        v = Input.GetAxisRaw("Vertical");
    }

    void FixedUpdate()
    {
        Vector3 direccion = new Vector3(h, 0f, v).normalized;
        rb.AddForce(direccion * fuerza, ForceMode.Force);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Cubo"))
        {
            Destroy(collision.gameObject);  // destruye el cubo
            Destroy(gameObject);            // destruye la propia esfera
        }
    }
}
