import json

import sys, os, base64, datetime, hashlib, hmac 

bucket = "p3twitterbucketvpeiro"
bucketUrl = "https://p3twitterbucketvpeiro.s3.us-east-1.amazonaws.com/"
region = 'us-east-1'
service = 's3'

t = datetime.datetime.utcnow()
amzDate = t.strftime('%Y%m%dT%H%M%SZ')
dateStamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope
    
# Key derivation functions. See:
# http://docs.aws.amazon.com/general/latest/gr/signature-v4-examples.html#signature-v4-examples-python
def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning




def lambda_handler(event, context):
    # TODO implement
    #aws_access_key_id=event["queryStringParameters"]["ak"];
    #aws_secret_access_key=event["queryStringParameters"]["sk"];
    #aws_session_token=event["queryStringParameters"]["st"];
    aws_access_key_id="ASIAVRUVWQ5AP2PGF26F"
    aws_secret_access_key="2JS3M6Q9MBxMBwELyTqwmlZqrmagexrrbZ4cU0D7"
    aws_session_token="IQoJb3JpZ2luX2VjEKH//////////wEaCXVzLXdlc3QtMiJHMEUCICU8kBmSZttsEBY/uUdK/YgbeqGZknXjuG3XAQmDg5ThAiEAjJ2uAzoZIHKgAbwm57kWj2rJn3I8eFPRcfxXpaWzYSAqtQIIahAAGgwzODE0OTIyOTk1ODQiDNLUstyj0/LOyvvS3CqSAvjtFpsmgICQzfV1YTHldXubJUeZh6QAO8qzomeH55I3vWC5oIPw1uVgAcZYcESNFvjBdf/ek17X8w60ZKB7CPAvkRfQrLOr2ef1jGe0SJXaecPP7EzvKWQ3anJDuJljCm4ukaorLeeKNzETonF45C5SGGaVsK1AV4koI1FKQCAkSq9wLJk4mcmVhc2xaUlTThTJpFYxc2cXFBKEzAAZGXuzAHWV9xnPYUMiN6kJ6i2Jl3OrdjuHnRRxI9M1VgZYQvwAgNbKJ1ONAfLuz3VDcfobqhPnOhOsniwuYDps32LzXo/rKCxzC8olQMHKK4J5RYX7oEsFBzxH5qL0+nuu9bzmNKBrSMiEnJCm6SFZa1B8gTYw4pWGygY6nQFP3bYzPP3mfCA/J0OUX3DlK8nyMkMtoUy6IQ9A6yudih31WOQJN1vl7/DyiXOywl4ww248k7gFdGY78nJutbk7iAxbJdTb8Bdf0B33iT3MYNOHOYSUUhwx7aOiR5JYC8dI7fNMD+/2B+6PvPrcwJi+GjZcZWy+Qc8wZNW0KK4dct/DHJKGB9fNDvQlEKH9NDPyHkVfj6GDMHUMOXbl"
    stringToSign= b""
    
       
    policy = """{"expiration": "2026-12-30T12:00:00.000Z",
    "conditions": [
    {"bucket": \"""" + bucket +"""\"},
    ["starts-with", "$key", ""],
    {"acl": "public-read"},
    {"success_action_redirect": \""""+ bucketUrl+"""success.html"},
        {"x-amz-credential": \""""+ aws_access_key_id+"/"+dateStamp+"/"+region+"""/s3/aws4_request"},
        {"x-amz-algorithm": "AWS4-HMAC-SHA256"},
        {"x-amz-date": \""""+amzDate+"""\" },
        {"x-amz-security-token": \"""" + aws_session_token +"""\"  }
      ]
    }"""

    
    stringToSign=base64.b64encode(bytes((policy).encode("utf-8")))

    
    signing_key = getSignatureKey(aws_secret_access_key, dateStamp, region, service)
    signature = hmac.new(signing_key, stringToSign, hashlib.sha256).hexdigest()
    
    #print(dateStamp)
    #print(signature)
    print(policy)
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body':json.dumps({ 'stringSigned' :  signature , 'stringToSign' : stringToSign.decode('utf-8') , 'xAmzCredential' : aws_access_key_id+"/"+dateStamp+"/"+region+ "/s3/aws4_request" , 'dateStamp' : dateStamp , 'amzDate' : amzDate , 'securityToken' : aws_session_token })
    }

