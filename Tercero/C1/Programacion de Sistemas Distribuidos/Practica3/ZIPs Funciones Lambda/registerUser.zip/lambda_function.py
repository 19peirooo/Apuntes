import json
import pymysql

rds_host = "rds-p3-twitterdb.crkeqmmwm3ew.us-east-1.rds.amazonaws.com"
db_user = "admin"
db_pass = "12345678"
db_name = "twitterDB"

def lambda_handler(event, context):

    # Extraer parámetros
    params = event.get('queryStringParameters') or {}
    username = params.get('username')
    password = params.get('password')

    if not username or not password:
        return {
            "statusCode": 200,
            "headers": { "Access-Control-Allow-Origin": "*" },
            "body": "KO"
        }

    try:
        conn = pymysql.connect(host=rds_host, user=db_user, passwd=db_pass, db=db_name, connect_timeout=5)
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM users WHERE username = %s", (username,))
            result = cur.fetchone()
            if result[0] > 0:
                return {
                    "statusCode": 200,
                    "headers": { "Access-Control-Allow-Origin": "*" },
                    "body": "EXISTS"
                }
                
            cur.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, password))
            conn.commit()
    except Exception as e:
        print(e)
        return {
            'statusCode': 200,
            'headers': { "Access-Control-Allow-Origin": "*" },
            'body': "KO"
        }

    return {
        'statusCode': 200,
        'headers': { "Access-Control-Allow-Origin": "*" },
        'body': "OK"
    }
