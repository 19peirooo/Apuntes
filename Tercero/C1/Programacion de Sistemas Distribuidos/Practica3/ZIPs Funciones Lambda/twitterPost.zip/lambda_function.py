import sys
import logging
import pymysql
import json
import base64
from urllib.parse import parse_qs

rds_host = "rds-p3-twitterdb.crkeqmmwm3ew.us-east-1.rds.amazonaws.com" #Cambiar por tu punto de enlace

username = "admin"
password ="12345678" #Cambiar por tu contraseña
dbname = "twitterDB"

bucketUrl = "https://p3twitterbucketvpeiro.s3.us-east-1.amazonaws.com/"

def lambda_handler(event , context):
    print(json.dumps(event));
    
    user="err";
    comment="err";
    attachment="err";
    user=event["queryStringParameters"]["user"];
    comment=event["queryStringParameters"]["comment"];
    attachment=bucketUrl+event["queryStringParameters"]["attachment"];
        
    print(user);
  
    try:
        conn = pymysql.connect(rds_host, user=username, passwd=password, db=dbname, connect_timeout=10, port=3306)
        print(1);
        with conn.cursor() as cur:
            cur.execute("insert into posts values('"+user+"','"+comment+"','"+attachment+"')");
            print(2);
            conn.commit();
            print(3);
            cur.close();
    except pymysql.MySQLError as e:    
        print (e)
    conn.close();
    print(4);
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body' : 'OK'    }
