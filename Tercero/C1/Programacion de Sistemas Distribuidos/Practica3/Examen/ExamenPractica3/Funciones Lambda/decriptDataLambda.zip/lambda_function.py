import sys
import logging
import pymysql
import json
import pyaes

rds_host = "100.49.36.156"

username = "victor.peiro"
password ="614749"
dbname = "victor.peiro"

def decryptData(encodedIn):
    k = "04121983baa3fccf9e5e46d8ca8c82fe".encode('utf-8');
    iv = "eb254c7008121983".encode('utf-8');
    aes_decryptor = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(k, iv));
    decodedPadded = aes_decryptor.feed(bytes.fromhex(encodedIn));
    decodedPadded += aes_decryptor.feed();
    padding = decodedPadded[-1];
    decoded = decodedPadded[:-padding];
    return decoded.decode('utf-8');


def lambda_handler(event , context):
    #Leer variable "encryptedData" de "queryStringParameters"
    params = event['queryStringParameters']
    encryptedData = params['encryptedData']
    #Ejecutar función decryptData con el dato leído, y guardar el resultado en una variable
    decryptedData = decryptData(encryptedData)
    #retornar en el cuerpo de la respuesta (campo body) la variable con el dato descifrado
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        #TODO
        #añadir en el campo "body" el dato descifrado
        'body' : json.dumps({"res":decryptedData})
    }

