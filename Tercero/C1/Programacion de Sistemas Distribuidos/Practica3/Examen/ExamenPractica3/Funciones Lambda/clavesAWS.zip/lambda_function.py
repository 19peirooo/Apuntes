import json

import sys, os, base64, datetime, hashlib, hmac 

bucket = "examenvpeiro"
bucketUrl = "https://examenvpeiro.s3.us-east-1.amazonaws.com/"
region = 'us-east-1'
service = 's3'

t = datetime.datetime.utcnow()
amzDate = t.strftime('%Y%m%dT%H%M%SZ')
dateStamp = t.strftime('%Y%m%d') # Date w/o time, used in credential scope
    
# Key derivation functions. See:
# http://docs.aws.amazon.com/general/latest/gr/signature-v4-examples.html#signature-v4-examples-python
def sign(key, msg):
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()

def getSignatureKey(key, dateStamp, regionName, serviceName):
    kDate = sign(('AWS4' + key).encode('utf-8'), dateStamp)
    kRegion = sign(kDate, regionName)
    kService = sign(kRegion, serviceName)
    kSigning = sign(kService, 'aws4_request')
    return kSigning




def lambda_handler(event, context):
    # TODO implement
    #aws_access_key_id=event["queryStringParameters"]["ak"];
    #aws_secret_access_key=event["queryStringParameters"]["sk"];
    #aws_session_token=event["queryStringParameters"]["st"];
    aws_access_key_id="ASIAVRUVWQ5ACAIKMFC7"
    aws_secret_access_key="Io5mRe76fbSb47v5gYYu4eZooXHp1HCmpp5mkKWY"
    aws_session_token="IQoJb3JpZ2luX2VjELL//////////wEaCXVzLXdlc3QtMiJIMEYCIQCnNfenrauYnfj/eqd6aKb7mK3gcX1gU1ZVkDBalCvPqwIhAP17u7jItd9iqk8QAYHIXUAZ3PeBnMW+0twn8iaKgU/iKrUCCHsQABoMMzgxNDkyMjk5NTg0Igx0kBjWed5PwozDOJgqkgJdXM9ey4f/P/kuSoJHBO4nLoeNw1CKFdHYKpkd1iU9o/xUYhiKEcmLwKOIb2ilPNVxCZxt+lIDG5LILC99BxsVaCpze0XsCJNJcBVREVkW7GSluDmxCo2xbDko29tK9813ToizroZq1n0aLt4CjxXFFKGKKtbWUFse3wJv18LxSSR96T4gWi8Saakg5uwlNRlCTbLRLa5c0MQP3mTdvrFvJzFfjgfPG7ahyftI77mK7jHd2W9CkxD/C0fS92tgF/ZeFbamfluQ5HtkUYfSRdOevBdbXe656ytxgtuIPTl2XnYhd4J00oFGKQ9HCqhOe7BkX/obV74GEhcekkQY8fUpzq5c/qsdR88lBJFbHrAHsxFyMMyEisoGOpwBOGL65Xou/oX5sODuM05gtS/YarYGPNFLvxZezLGyysZnaKluw+M7jnK/m1sqemEZ3Q7VKJ6GpXH2+pQwqG9VmfvNOBtXlTvIKeTLsNXS/WHEewm3Bk/yiQ5TFTRbTNvLwudt0V7e4PmRfFSnf5RfzJVagZXFS6GtSaPUX4/bPyxrlCJKQQEv2AfcNftgTtoYMGo2dnwcu+2oAF4f"
    stringToSign= b""
    
       
    policy = """{"expiration": "2026-12-30T12:00:00.000Z",
    "conditions": [
    {"bucket": \"""" + bucket +"""\"},
    ["starts-with", "$key", ""],
    {"acl": "public-read"},
    {"success_action_redirect": \""""+ bucketUrl+"""success.html"},
        {"x-amz-credential": \""""+ aws_access_key_id+"/"+dateStamp+"/"+region+"""/s3/aws4_request"},
        {"x-amz-algorithm": "AWS4-HMAC-SHA256"},
        {"x-amz-date": \""""+amzDate+"""\" },
        {"x-amz-security-token": \"""" + aws_session_token +"""\"  }
      ]
    }"""

    
    stringToSign=base64.b64encode(bytes((policy).encode("utf-8")))

    
    signing_key = getSignatureKey(aws_secret_access_key, dateStamp, region, service)
    signature = hmac.new(signing_key, stringToSign, hashlib.sha256).hexdigest()
    
    #print(dateStamp)
    #print(signature)
    print(policy)
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body':json.dumps({ 'stringSigned' :  signature , 'stringToSign' : stringToSign.decode('utf-8') , 'xAmzCredential' : aws_access_key_id+"/"+dateStamp+"/"+region+ "/s3/aws4_request" , 'dateStamp' : dateStamp , 'amzDate' : amzDate , 'securityToken' : aws_session_token })
    }

